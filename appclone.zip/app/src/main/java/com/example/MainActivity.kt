package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppTab
import com.example.data.model.DhikrItem
import com.example.data.seed.AuthenticAdhkarData
import com.example.notifications.AdhanPlaybackService
import com.example.notifications.NotificationHelper
import com.example.ui.components.AddCustomDeedDialog
import com.example.ui.components.AdhanNowPlayingBanner
import com.example.ui.components.AdhkariBottomBar
import com.example.ui.components.AdhkariToastBanner
import com.example.ui.components.AdhkariTopHeader
import com.example.ui.components.ConfirmResetDialog
import com.example.ui.components.FreeTasbihDialog
import com.example.ui.components.LocationSelectionDialog
import com.example.ui.components.SqlInspectorDialog
import com.example.ui.components.SourceDetailDialog
import com.example.ui.components.WeightsEditorDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MoreScreen
import com.example.ui.screens.PrayersScreen
import com.example.ui.screens.ReaderScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WorshipScreen
import com.example.ui.theme.AdhkariTheme
import com.example.ui.theme.LocalAdhkariColors
import com.example.util.FeedbackHelper
import com.example.viewmodel.AdhkariViewModel
import com.example.widget.AdhkariWidgetUpdater
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {

    private val adhkariViewModel: AdhkariViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.ensureChannel(this)
        AdhanPlaybackService.ensureAdhanChannel(this)
        handleNavigationIntent(intent)

        setContent {
            AdhkariRootApp(viewModel = adhkariViewModel)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNavigationIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        AdhkariWidgetUpdater.updateAllWidgetsAsync(this)
    }

    private fun handleNavigationIntent(intent: Intent?) {
        if (intent == null) return
        val tabRoute = intent.getStringExtra(AdhkariWidgetUpdater.EXTRA_OPEN_TAB)
            ?: intent.getStringExtra(AdhanPlaybackService.EXTRA_OPEN_TAB_KEY)
        val catId = intent.getStringExtra(AdhkariWidgetUpdater.EXTRA_OPEN_CATEGORY)

        if (!catId.isNullOrBlank()) {
            adhkariViewModel.openCategoryReader(catId)
        } else if (!tabRoute.isNullOrBlank()) {
            val targetTab = AppTab.entries.firstOrNull { it.route == tabRoute }
            if (targetTab != null) {
                adhkariViewModel.switchTab(targetTab)
            }
        }
    }
}

@Composable
fun AdhkariRootApp(viewModel: AdhkariViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showLocationDialog by remember { mutableStateOf(false) }
    var sourceDetailDhikr by remember { mutableStateOf<DhikrItem?>(null) }
    var showResetConfirm by remember { mutableStateOf(false) }
    var showFreeTasbihDialog by remember { mutableStateOf(false) }
    var showSqlInspector by remember { mutableStateOf(false) }
    var showAddCustomDeed by remember { mutableStateOf(false) }
    var showWeightsEditor by remember { mutableStateOf(false) }

    // SAF Launchers (no broad storage permissions needed)
    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = viewModel.buildBackupJson()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                    viewModel.showToast("تم تصدير النسخة الاحتياطية بنجاح ✓")
                } catch (_: Throwable) {
                    viewModel.showToast("تعذر حفظ ملف النسخة الاحتياطية")
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val content = context.contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    }
                    if (!content.isNullOrBlank()) {
                        viewModel.restoreBackupJson(content)
                    } else {
                        viewModel.showToast("الملف المختار فارغ")
                    }
                } catch (_: Throwable) {
                    viewModel.showToast("تعذر قراءة ملف النسخة الاحتياطية")
                }
            }
        }
    }

    val exportSqlLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/sql")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val sql = viewModel.getCompleteSqlScript()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(sql.toByteArray(Charsets.UTF_8))
                    }
                    viewModel.showToast("تم تصدير ملف قاعدة البيانات adhkari_db.sql ✓")
                } catch (_: Throwable) {
                    viewModel.showToast("تعذر تصدير ملف SQL")
                }
            }
        }
    }

    // SAF Custom Adhan Audio Picker (zero storage permission required)
    val customAdhanAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
            }
            val displayName = resolveDisplayName(context, uri) ?: "صوت أذان مخصص"
            viewModel.setCustomAdhanAudio(uri.toString(), displayName)
        }
    }

    // Coarse location runtime permission launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.detectLocationFromDevice()
        } else {
            viewModel.setGpsStatusMessage("لم يتم منح إذن الموقع، يمكنك اختيار مدينتك يدوياً من القائمة.")
        }
    }

    // Notification runtime permission launcher (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            NotificationHelper.showNotification(
                context = context,
                id = 999,
                title = "🔔 تذكير أذكاري",
                body = "الإشعارات مفعّلة وتعمل بنجاح على جهازك ✓"
            )
            FeedbackHelper.trigger(
                context,
                uiState.prefs.vibrationEnabled,
                uiState.prefs.soundEnabled,
                true
            )
            viewModel.showToast("تم تفعيل وإرسال إشعار تجريبي بنجاح ✓")
        } else {
            viewModel.showToast("يرجى السماح بإذن الإشعارات لتنبيهات الأذكار والصلوات")
        }
    }

    val pinPrayerWidgetAction: () -> Unit = {
        val ok = AdhkariWidgetUpdater.requestPinPrayerWidget(context)
        if (!ok) {
            viewModel.showToast("لإضافة الودجيت: اضغط مطولاً على الشاشة الرئيسية ← ودجيت ← أذكاري")
        } else {
            viewModel.showToast("تم إرسال طلب إضافة ودجيت المواقيت للشاشة الرئيسية ✓")
        }
    }

    val pinCompactWidgetAction: () -> Unit = {
        val ok = AdhkariWidgetUpdater.requestPinCompactWidget(context)
        if (!ok) {
            viewModel.showToast("لإضافة الودجيت: اضغط مطولاً على الشاشة الرئيسية ← ودجيت ← أذكاري")
        } else {
            viewModel.showToast("تم إرسال طلب إضافة الودجيت المصغّر للشاشة الرئيسية ✓")
        }
    }

    // Auto-hide toast banner
    LaunchedEffect(uiState.nav.toastTick) {
        if (uiState.nav.toastMessage != null) {
            delay(2800L)
            viewModel.clearToast()
        }
    }

    // Back button behavior for top-level sub-tabs
    BackHandler(enabled = uiState.nav.currentTab != AppTab.HOME) {
        viewModel.switchTab(AppTab.HOME)
    }

    AdhkariTheme(themeMode = uiState.prefs.themeMode) {
        val colors = LocalAdhkariColors.current
        val currentTab = uiState.nav.currentTab
        val headerSubtitle = when (currentTab) {
            AppTab.HOME -> "رفيقك اليومي للذكر الموثق"
            AppTab.READER -> AuthenticAdhkarData.CATEGORIES_META
                .firstOrNull { it.id == uiState.nav.currentCategory }
                ?.title ?: "الأذكار الموثقة"
            AppTab.WORSHIP -> "متابعة العبادة والإحصائيات"
            AppTab.PRAYERS -> "مواقيت الصلاة (${uiState.prefs.location.shortName})"
            AppTab.MORE -> "كل الأذكار والبحث والمسبحة"
            AppTab.SETTINGS -> "الإعدادات والتنبيهات"
        }

        Scaffold(
            containerColor = colors.bgPrimary,
            topBar = {
                AdhkariTopHeader(
                    title = "أذكاري",
                    subtitle = headerSubtitle,
                    showBack = currentTab != AppTab.HOME,
                    isDark = colors.isDark,
                    onBackClick = { viewModel.switchTab(AppTab.HOME) },
                    onSearchClick = { viewModel.switchTab(AppTab.MORE) },
                    onThemeToggleClick = { viewModel.cycleTheme() },
                    onSettingsClick = { viewModel.switchTab(AppTab.SETTINGS) }
                )
            },
            bottomBar = {
                AdhkariBottomBar(
                    currentTab = currentTab,
                    currentCategory = uiState.nav.currentCategory,
                    onSelectTab = { viewModel.switchTab(it) },
                    onOpenCategory = { viewModel.openCategoryReader(it) }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(colors.bgPrimary)
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    AppTab.HOME -> HomeScreen(
                        uiState = uiState,
                        onOpenLocation = { showLocationDialog = true },
                        onOpenCategory = { viewModel.openCategoryReader(it) },
                        onOpenPostPrayer = { viewModel.openPostPrayer(it) },
                        onOpenWorship = { viewModel.switchTab(AppTab.WORSHIP) },
                        onOpenMore = { viewModel.switchTab(AppTab.MORE) },
                        onOpenPrayers = { viewModel.switchTab(AppTab.PRAYERS) }
                    )

                    AppTab.READER -> ReaderScreen(
                        uiState = uiState,
                        onSelectPostPrayerTab = { viewModel.selectPostPrayerTab(it) },
                        onChangeTasbihVariant = { viewModel.changeTasbihVariant(it) },
                        onIncrement = { viewModel.incrementSequentialDhikr() },
                        onDecrement = { viewModel.decrementSequentialDhikr() },
                        onRequestResetSingle = { showResetConfirm = true },
                        onNavigateItem = { delta -> viewModel.navigateSeqIndex(delta) },
                        onOpenSourceDetail = { dhikr -> sourceDetailDhikr = dhikr }
                    )

                    AppTab.WORSHIP -> WorshipScreen(
                        uiState = uiState,
                        onSelectSubTab = { viewModel.setWorshipSubTab(it) },
                        onSelectDate = { viewModel.selectWorshipDate(it) },
                        onTogglePrayer = { dk, pk -> viewModel.toggleWorshipPrayer(dk, pk) },
                        onQuickCompleteAdhkar = { dk, catId -> viewModel.quickCompleteAdhkarCategory(dk, catId) },
                        onOpenAdhkarCategory = { catId -> viewModel.openCategoryReader(catId) },
                        onToggleQuran = { dk -> viewModel.toggleWorshipQuran(dk) },
                        onToggleNawafil = { dk, id -> viewModel.toggleWorshipNawafil(dk, id) },
                        onToggleRawatib = { dk, id -> viewModel.toggleWorshipRawatib(dk, id) },
                        onToggleCustom = { dk, id -> viewModel.toggleWorshipCustom(dk, id) },
                        onDeleteCustomDeed = { id -> viewModel.deleteCustomDeed(id) },
                        onOpenAddCustomDeed = { showAddCustomDeed = true },
                        onToggleExcuse = { dk, enabled -> viewModel.toggleExcuseMode(dk, enabled) },
                        onOpenWeightsEditor = { showWeightsEditor = true }
                    )

                    AppTab.PRAYERS -> PrayersScreen(
                        uiState = uiState,
                        onOpenLocation = { showLocationDialog = true },
                        onOpenPostPrayer = { pk -> viewModel.openPostPrayer(pk) },
                        onUpdateCalculation = { method, asr, offsets ->
                            viewModel.updatePrayerCalculation(method, asr, offsets)
                        },
                        onResetOffsets = { viewModel.resetPrayerOffsets() },
                        onToggleAdhanEnabled = { viewModel.setAdhanEnabled(it) },
                        onSelectAdhanVoice = { viewModel.setAdhanVoice(it) },
                        onToggleAlarmChannel = { viewModel.setAdhanAlarmChannel(it) },
                        onTogglePrayerAdhan = { pk -> viewModel.togglePrayerAdhan(pk) },
                        onPickCustomAdhanAudio = { customAdhanAudioLauncher.launch(arrayOf("audio/*")) },
                        onPreviewAdhan = { viewModel.previewAdhan() },
                        onStopAdhan = { viewModel.stopAdhan() },
                        onPinPrayerWidget = pinPrayerWidgetAction,
                        onPinCompactWidget = pinCompactWidgetAction
                    )

                    AppTab.MORE -> MoreScreen(
                        uiState = uiState,
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onOpenCategory = { viewModel.openCategoryReader(it) },
                        onOpenFreeTasbih = { showFreeTasbihDialog = true }
                    )

                    AppTab.SETTINGS -> SettingsScreen(
                        uiState = uiState,
                        onSetThemeMode = { viewModel.setThemeMode(it) },
                        onSetFontSize = { viewModel.setFontSize(it) },
                        onToggleVibration = { viewModel.setVibrationEnabled(it) },
                        onToggleSound = { viewModel.setSoundEnabled(it) },
                        onToggleAutoAdvance = { viewModel.setAutoAdvance(it) },
                        onToggleReadOnly = { viewModel.setReadOnlyMode(it) },
                        onTestNotification = {
                            if (Build.VERSION.SDK_INT >= 33) {
                                val granted = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.POST_NOTIFICATIONS
                                ) == PackageManager.PERMISSION_GRANTED
                                if (granted) {
                                    NotificationHelper.showNotification(
                                        context = context,
                                        id = 999,
                                        title = "🔔 تذكير أذكاري",
                                        body = "إشعار تجريبي: نظام التنبيهات يعمل بنجاح ✓"
                                    )
                                    FeedbackHelper.trigger(
                                        context,
                                        uiState.prefs.vibrationEnabled,
                                        uiState.prefs.soundEnabled,
                                        true
                                    )
                                    viewModel.showToast("تم إرسال الإشعار التجريبي بنجاح ✓")
                                } else {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            } else {
                                NotificationHelper.showNotification(
                                    context = context,
                                    id = 999,
                                    title = "🔔 تذكير أذكاري",
                                    body = "إشعار تجريبي: نظام التنبيهات يعمل بنجاح ✓"
                                )
                                FeedbackHelper.trigger(
                                    context,
                                    uiState.prefs.vibrationEnabled,
                                    uiState.prefs.soundEnabled,
                                    true
                                )
                                viewModel.showToast("تم إرسال الإشعار التجريبي بنجاح ✓")
                            }
                        },
                        onToggleAlarm = { alarm, enabled -> viewModel.toggleAlarm(alarm, enabled) },
                        onUpdateAlarmTime = { alarm, time -> viewModel.updateAlarmTime(alarm, time) },
                        onOpenSqlInspector = { showSqlInspector = true },
                        onExportBackup = {
                            exportBackupLauncher.launch("adhkari_backup_${uiState.todayDateKey}.json")
                        },
                        onImportBackup = {
                            importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                        },
                        onPreviewAdhan = { viewModel.previewAdhan() },
                        onStopAdhan = { viewModel.stopAdhan() },
                        onPinPrayerWidget = pinPrayerWidgetAction
                    )
                }

                AdhanNowPlayingBanner(
                    visible = uiState.adhanPlayback.isPlaying,
                    prayerTitle = uiState.adhanPlayback.prayerTitle,
                    voiceName = uiState.adhanPlayback.voiceName,
                    onStopClick = { viewModel.stopAdhan() },
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )

                AdhkariToastBanner(
                    message = uiState.nav.toastMessage,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                )
            }
        }

        // Dialogs & Modals
        if (showLocationDialog) {
            LocationSelectionDialog(
                currentLocation = uiState.prefs.location,
                gpsStatusMessage = uiState.nav.gpsStatusMessage,
                onRequestGps = {
                    val hasCoarse = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                    if (hasCoarse) {
                        viewModel.detectLocationFromDevice()
                    } else {
                        locationPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                    }
                },
                onSaveLocation = { loc -> viewModel.saveLocation(loc) },
                onDismiss = { showLocationDialog = false }
            )
        }

        sourceDetailDhikr?.let { dhikr ->
            SourceDetailDialog(
                dhikr = dhikr,
                onDismiss = { sourceDetailDhikr = null }
            )
        }

        if (showResetConfirm) {
            ConfirmResetDialog(
                title = "تأكيد إعادة الضبط",
                message = "هل أنت متأكد من تصفير عداد هذا الذكر؟",
                onConfirm = { viewModel.resetCurrentDhikr() },
                onDismiss = { showResetConfirm = false }
            )
        }

        if (showFreeTasbihDialog) {
            FreeTasbihDialog(
                state = uiState.prefs.freeTasbih,
                onPhraseChange = { viewModel.updateFreeTasbihPhrase(it) },
                onIncrement = { viewModel.incrementFreeTasbih() },
                onReset = { viewModel.resetFreeTasbih() },
                onDismiss = { showFreeTasbihDialog = false }
            )
        }

        if (showAddCustomDeed) {
            AddCustomDeedDialog(
                onAdd = { title, sub -> viewModel.addCustomDeed(title, sub) },
                onDismiss = { showAddCustomDeed = false }
            )
        }

        if (showWeightsEditor) {
            WeightsEditorDialog(
                currentWeights = uiState.prefs.worshipWeights,
                onSave = { weights -> viewModel.saveWorshipWeights(weights) },
                onDismiss = { showWeightsEditor = false }
            )
        }

        if (showSqlInspector) {
            SqlInspectorDialog(
                sqlScript = viewModel.getCompleteSqlScript(),
                adhkarPreview = viewModel.getAdhkarJsonPreview(),
                loadProgressSnapshot = { viewModel.getProgressSnapshotJson() },
                onDownloadSql = { exportSqlLauncher.launch("adhkari_db.sql") },
                onDismiss = { showSqlInspector = false }
            )
        }
    }
}

private fun resolveDisplayName(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else {
                null
            }
        }
    } catch (_: Throwable) {
        null
    }
}
