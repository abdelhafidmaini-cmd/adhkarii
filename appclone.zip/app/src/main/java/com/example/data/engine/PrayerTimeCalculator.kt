package com.example.data.engine

import android.icu.util.IslamicCalendar
import android.icu.util.ULocale
import com.example.data.model.DailyPrayerTimes
import com.example.data.model.LocationSettings
import com.example.data.model.NextPrayerInfo
import com.example.data.model.PrayerKey
import com.example.data.model.PrayerTimeEntry
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

object PrayerTimeCalculator {

    private fun dtr(deg: Double): Double = (deg * PI) / 180.0
    private fun rtd(rad: Double): Double = (rad * 180.0) / PI
    private fun fixAngle(a: Double): Double = a - 360.0 * floor(a / 360.0)
    private fun fixHour(h: Double): Double = h - 24.0 * floor(h / 24.0)

    private fun julianDate(yearIn: Int, monthIn: Int, day: Int): Double {
        var year = yearIn
        var month = monthIn
        if (month <= 2) {
            year -= 1
            month += 12
        }
        val a = floor(year / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (year + 4716)) + floor(30.6001 * (month + 1)) + day + b - 1524.5
    }

    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(dtr(g)) + 0.020 * sin(dtr(2.0 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = rtd(atan2(cos(dtr(e)) * sin(dtr(l)), cos(dtr(l)))) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = rtd(asin(sin(dtr(e)) * sin(dtr(l))))
        return decl to eqt
    }

    fun computePrayerTimesForDate(cal: Calendar, loc: LocationSettings): DailyPrayerTimes {
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val lat = loc.lat
        val lng = loc.lng
        val tz = loc.tz
        val method = loc.method
        val asrFactor = loc.asrJuristic.shadowFactor
        val offsets = loc.offsets

        val jd = julianDate(year, month, day) - lng / (15.0 * 24.0)
        val (decl, eqt) = sunPosition(jd + 0.5)
        val dhuhrNoon = fixHour(12.0 - eqt + tz - lng / 15.0)

        fun sunAngleTime(angle: Double, isCCW: Boolean): Double {
            val num = -sin(dtr(angle)) - sin(dtr(lat)) * sin(dtr(decl))
            val den = cos(dtr(lat)) * cos(dtr(decl))
            val ratio = (num / den).coerceIn(-1.0, 1.0)
            val diff = rtd(acos(ratio)) / 15.0
            return dhuhrNoon + if (isCCW) -diff else diff
        }

        fun asrTime(factor: Int): Double {
            val angle = -rtd(atan(1.0 / (factor + tan(dtr(abs(lat - decl))))))
            return sunAngleTime(angle, false)
        }

        val rawFajr = sunAngleTime(method.fajrAngle, true) + offsets.fajr / 60.0
        val rawSunrise = sunAngleTime(0.833, true) + offsets.sunrise / 60.0
        val rawDhuhr = dhuhrNoon + (2.0 / 60.0) + offsets.dhuhr / 60.0
        val rawAsr = asrTime(asrFactor) + offsets.asr / 60.0
        val rawMaghrib = sunAngleTime(0.833, false) + offsets.maghrib / 60.0
        val rawIsha = (if (method.ishaMinutes > 0) {
            rawMaghrib + method.ishaMinutes / 60.0
        } else {
            sunAngleTime(method.ishaAngle, false)
        }) + offsets.isha / 60.0

        fun buildEntry(key: PrayerKey, decHours: Double): PrayerTimeEntry {
            val hNorm = fixHour(decHours + 0.5 / 60.0)
            val hrs = floor(hNorm).toInt()
            val mins = floor((hNorm - hrs) * 60.0).toInt()
            val str = String.format(Locale.US, "%02d:%02d", hrs, mins)
            return PrayerTimeEntry(
                key = key,
                timeStr = str,
                totalMinutes = hrs * 60 + mins,
                hours = hrs,
                minutes = mins
            )
        }

        return DailyPrayerTimes(
            fajr = buildEntry(PrayerKey.FAJR, rawFajr),
            sunrise = buildEntry(PrayerKey.SUNRISE, rawSunrise),
            dhuhr = buildEntry(PrayerKey.DHUHR, rawDhuhr),
            asr = buildEntry(PrayerKey.ASR, rawAsr),
            maghrib = buildEntry(PrayerKey.MAGHRIB, rawMaghrib),
            isha = buildEntry(PrayerKey.ISHA, rawIsha)
        )
    }

    fun getNextPrayerInfo(now: Calendar, loc: LocationSettings): NextPrayerInfo {
        val todayTimes = computePrayerTimesForDate(now, loc)
        val currentSeconds =
            now.get(Calendar.HOUR_OF_DAY) * 3600L +
                now.get(Calendar.MINUTE) * 60L +
                now.get(Calendar.SECOND)

        val order = PrayerKey.fiveObligatory
        for (key in order) {
            val entry = todayTimes.byKey(key)
            val pSeconds = entry.totalMinutes * 60L
            if (pSeconds > currentSeconds) {
                return NextPrayerInfo(
                    next = entry,
                    diffSeconds = pSeconds - currentSeconds,
                    todayTimes = todayTimes,
                    windowHint = windowHintFor(key)
                )
            }
        }

        val tomorrow = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
        val tomorrowTimes = computePrayerTimesForDate(tomorrow, loc)
        val fajrNext = tomorrowTimes.fajr
        val diffSec = (24L * 3600L - currentSeconds) + fajrNext.totalMinutes * 60L
        return NextPrayerInfo(
            next = fajrNext,
            diffSeconds = diffSec,
            todayTimes = todayTimes,
            windowHint = windowHintFor(PrayerKey.FAJR)
        )
    }

    private fun windowHintFor(key: PrayerKey): String = when (key) {
        PrayerKey.FAJR -> "(وقت السحر والتهجد)"
        PrayerKey.DHUHR -> "(فترة الصباح والضحى)"
        PrayerKey.ASR -> "(بعد صلاة الظهر)"
        PrayerKey.MAGHRIB -> "(فترة المساء بعد العصر)"
        PrayerKey.ISHA -> "(بعد صلاة المغرب)"
        PrayerKey.SUNRISE -> ""
    }

    fun formatCountdown(sec: Long): String {
        val s = sec.coerceAtLeast(0L)
        val hrs = s / 3600L
        val mins = (s % 3600L) / 60L
        val secs = s % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
    }

    fun dateKeyOf(cal: Calendar = Calendar.getInstance()): String {
        return String.format(
            Locale.US,
            "%04d-%02d-%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun calendarFromDateKey(dateKey: String): Calendar {
        val parts = dateKey.split("-")
        val cal = Calendar.getInstance()
        if (parts.size == 3) {
            cal.set(Calendar.YEAR, parts[0].toIntOrNull() ?: cal.get(Calendar.YEAR))
            cal.set(Calendar.MONTH, (parts[1].toIntOrNull() ?: 1) - 1)
            cal.set(Calendar.DAY_OF_MONTH, parts[2].toIntOrNull() ?: 1)
        }
        return cal
    }

    private val HIJRI_MONTHS = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private val GREG_MONTHS = arrayOf(
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    )

    private val ARABIC_WEEKDAYS = mapOf(
        Calendar.SUNDAY to "الأحد",
        Calendar.MONDAY to "الاثنين",
        Calendar.TUESDAY to "الثلاثاء",
        Calendar.WEDNESDAY to "الأربعاء",
        Calendar.THURSDAY to "الخميس",
        Calendar.FRIDAY to "الجمعة",
        Calendar.SATURDAY to "السبت"
    )

    val ARABIC_WEEKDAYS_SHORT = mapOf(
        Calendar.SUNDAY to "أحد",
        Calendar.MONDAY to "إثنين",
        Calendar.TUESDAY to "ثلاثاء",
        Calendar.WEDNESDAY to "أربعاء",
        Calendar.THURSDAY to "خميس",
        Calendar.FRIDAY to "جمعة",
        Calendar.SATURDAY to "سبت"
    )

    fun weekdayName(cal: Calendar): String = ARABIC_WEEKDAYS[cal.get(Calendar.DAY_OF_WEEK)] ?: ""

    fun formatHijriLong(cal: Calendar = Calendar.getInstance()): String {
        return try {
            val ic = IslamicCalendar(ULocale("ar_SA@calendar=islamic-umalqura"))
            ic.timeInMillis = cal.timeInMillis
            val day = ic.get(IslamicCalendar.DAY_OF_MONTH)
            val month = HIJRI_MONTHS.getOrElse(ic.get(IslamicCalendar.MONTH)) { "" }
            val year = ic.get(IslamicCalendar.YEAR)
            "${weekdayName(cal)} $day $month $year هـ"
        } catch (_: Throwable) {
            SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(cal.timeInMillis))
        }
    }

    fun formatHijriShort(cal: Calendar): String {
        return try {
            val ic = IslamicCalendar(ULocale("ar_SA@calendar=islamic-umalqura"))
            ic.timeInMillis = cal.timeInMillis
            val day = ic.get(IslamicCalendar.DAY_OF_MONTH)
            val month = HIJRI_MONTHS.getOrElse(ic.get(IslamicCalendar.MONTH)) { "" }
            "$day $month"
        } catch (_: Throwable) {
            ""
        }
    }

    fun formatGregorianLong(cal: Calendar = Calendar.getInstance()): String {
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = GREG_MONTHS.getOrElse(cal.get(Calendar.MONTH)) { "" }
        val year = cal.get(Calendar.YEAR)
        return "$day $month $year م"
    }

    fun formatGregorianShort(cal: Calendar): String {
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = GREG_MONTHS.getOrElse(cal.get(Calendar.MONTH)) { "" }
        return "$day $month"
    }

    fun stripArabicTashkeel(input: String): String {
        return input.replace(Regex("[\u064B-\u065F\u0670]"), "")
    }
}
