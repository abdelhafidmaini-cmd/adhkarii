package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AdhkariDao {

    @Query("SELECT * FROM daily_progress")
    fun observeAllProgress(): Flow<List<ProgressEntity>>

    @Query("SELECT * FROM daily_progress")
    suspend fun getAllProgressOnce(): List<ProgressEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(entry: ProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgressList(entries: List<ProgressEntity>)

    @Query("DELETE FROM daily_progress")
    suspend fun clearAllProgress()

    @Query("SELECT * FROM daily_totals")
    fun observeAllTotals(): Flow<List<DailyTotalEntity>>

    @Query("SELECT * FROM daily_totals WHERE dateKey = :dateKey")
    suspend fun getTotalForDate(dateKey: String): DailyTotalEntity?

    @Query("SELECT * FROM daily_totals")
    suspend fun getAllTotalsOnce(): List<DailyTotalEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTotal(total: DailyTotalEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTotals(totals: List<DailyTotalEntity>)

    @Query("DELETE FROM daily_totals")
    suspend fun clearAllTotals()

    @Query("SELECT * FROM worship_logs")
    fun observeAllWorshipLogs(): Flow<List<WorshipLogEntity>>

    @Query("SELECT * FROM worship_logs WHERE dateKey = :dateKey")
    suspend fun getWorshipLogForDate(dateKey: String): WorshipLogEntity?

    @Query("SELECT * FROM worship_logs")
    suspend fun getAllWorshipLogsOnce(): List<WorshipLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorshipLog(log: WorshipLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorshipLogs(logs: List<WorshipLogEntity>)

    @Query("DELETE FROM worship_logs")
    suspend fun clearAllWorshipLogs()

    @Query("SELECT * FROM custom_deeds ORDER BY sortOrder ASC")
    fun observeCustomDeeds(): Flow<List<CustomDeedEntity>>

    @Query("SELECT * FROM custom_deeds ORDER BY sortOrder ASC")
    suspend fun getCustomDeedsOnce(): List<CustomDeedEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomDeed(deed: CustomDeedEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomDeeds(deeds: List<CustomDeedEntity>)

    @Query("DELETE FROM custom_deeds WHERE id = :id")
    suspend fun deleteCustomDeed(id: String)

    @Query("DELETE FROM custom_deeds")
    suspend fun clearCustomDeeds()

    @Query("SELECT * FROM alarms ORDER BY sortOrder ASC")
    fun observeAlarms(): Flow<List<AlarmEntity>>

    @Query("SELECT * FROM alarms ORDER BY sortOrder ASC")
    suspend fun getAlarmsOnce(): List<AlarmEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlarm(alarm: AlarmEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlarms(alarms: List<AlarmEntity>)

    @Query("SELECT * FROM settings")
    fun observeSettings(): Flow<List<SettingEntity>>

    @Query("SELECT * FROM settings")
    suspend fun getSettingsOnce(): List<SettingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSetting(setting: SettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettings(settings: List<SettingEntity>)

    @Query("DELETE FROM settings")
    suspend fun clearSettings()
}
