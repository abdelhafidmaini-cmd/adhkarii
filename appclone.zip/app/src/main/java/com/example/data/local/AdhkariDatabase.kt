package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProgressEntity::class,
        DailyTotalEntity::class,
        WorshipLogEntity::class,
        CustomDeedEntity::class,
        AlarmEntity::class,
        SettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AdhkariDatabase : RoomDatabase() {
    abstract fun adhkariDao(): AdhkariDao

    companion object {
        @Volatile
        private var INSTANCE: AdhkariDatabase? = null

        fun getInstance(context: Context): AdhkariDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AdhkariDatabase::class.java,
                    "adhkari_sqlite.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
