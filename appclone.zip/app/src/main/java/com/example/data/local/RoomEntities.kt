package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_progress",
    primaryKeys = ["dateKey", "counterKey"]
)
data class ProgressEntity(
    val dateKey: String,
    val counterKey: String,
    val currentCount: Int,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_totals")
data class DailyTotalEntity(
    @PrimaryKey val dateKey: String,
    val totalTasbihat: Int
)

@Entity(tableName = "worship_logs")
data class WorshipLogEntity(
    @PrimaryKey val dateKey: String,
    val prayersMask: Int = 0, // Bitmask for fajr(1), dhuhr(2), asr(4), maghrib(8), isha(16)
    val quran: Boolean = false,
    val quranPages: Int = 0,
    val rawatibIdsCsv: String = "",
    val nawafilIdsCsv: String = "",
    val customIdsCsv: String = "",
    val excuse: Boolean = false
)

@Entity(tableName = "custom_deeds")
data class CustomDeedEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sub: String,
    val sortOrder: Int = 0
)

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val enabled: Boolean,
    val timeValue: String,
    val alarmType: String,
    val sortOrder: Int = 0
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
