package com.example.data.model

enum class AppTab(val route: String) {
    HOME("home"),
    READER("reader"),
    WORSHIP("worship"),
    PRAYERS("prayers"),
    MORE("more"),
    SETTINGS("settings")
}

enum class ThemeMode(val key: String) {
    LIGHT("light"),
    DARK("dark"),
    AUTO("auto");

    companion object {
        fun fromKey(key: String?): ThemeMode =
            entries.firstOrNull { it.key == key } ?: LIGHT
    }
}

enum class WorshipSubTab(val key: String) {
    TRACK("track"),
    STATS("stats")
}

enum class PrayerKey(val key: String, val arabicName: String) {
    FAJR("fajr", "الفجر"),
    SUNRISE("sunrise", "الشروق"),
    DHUHR("dhuhr", "الظهر"),
    ASR("asr", "العصر"),
    MAGHRIB("maghrib", "المغرب"),
    ISHA("isha", "العشاء");

    companion object {
        val fiveObligatory = listOf(FAJR, DHUHR, ASR, MAGHRIB, ISHA)
        val allSix = listOf(FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA)
    }
}

enum class CalculationMethod(
    val key: String,
    val arabicName: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaMinutes: Int
) {
    ALGERIA("ALGERIA", "وزارة الشؤون الدينية والأوقاف الجزائرية", 18.0, 17.0, 0),
    MWL("MWL", "رابطة العالم الإسلامي (MWL)", 18.0, 17.0, 0),
    MAKKAH("MAKKAH", "تقويم أم القرى - مكة المكرمة", 18.5, 0.0, 90),
    EGYPT("EGYPT", "الهيئة المصرية العامة للمساحة", 19.5, 17.5, 0),
    KARACHI("KARACHI", "جامعة العلوم الإسلامية بكراتشي", 18.0, 18.0, 0),
    ISNA("ISNA", "الجمعية الإسلامية لأمريكا الشمالية (ISNA)", 15.0, 15.0, 0);

    companion object {
        fun fromKey(key: String?): CalculationMethod =
            entries.firstOrNull { it.key == key } ?: ALGERIA
    }
}

enum class AsrJuristic(val key: String, val arabicName: String, val shadowFactor: Int) {
    STANDARD("STANDARD", "الجمهور (المالكي، الشافعي، الحنبلي — ظل المثل)", 1),
    HANAFI("HANAFI", "المذهب الحنفي (ظل المثلين)", 2);

    companion object {
        fun fromKey(key: String?): AsrJuristic =
            entries.firstOrNull { it.key == key } ?: STANDARD
    }
}

enum class TasbihVariant(val key: String, val label: String) {
    MUSLIM_597("muslim_597", "الرواية 1: 33 تسبيحة، 33 تحميدة، 33 تكبيرة + تمام المائة (مسلم 597)"),
    MUSLIM_596("muslim_596", "الرواية 2: 33 تسبيحة، 33 تحميدة، 34 تكبيرة (مسلم 596)"),
    BUKHARI_843("bukhari_843", "الرواية 3: سبحان الله والحمد لله والله أكبر معاً 33 مرة (البخاري 843 ومسلم 595)"),
    ABUDAWUD_5065("abudawud_5065", "الرواية 4: 10 تسبيحات، 10 تحميدات، 10 تكبيرات (أبو داود 5065 والترمذي 3410)");

    companion object {
        fun fromKey(key: String?): TasbihVariant =
            entries.firstOrNull { it.key == key } ?: MUSLIM_597
    }
}

data class CategoryMeta(
    val id: String,
    val title: String,
    val emoji: String,
    val timeHint: String,
    val desc: String
)

data class DhikrItem(
    val id: String,
    val categoryId: String,
    val subCategory: String,
    val variantGroup: String = "common",
    val text: String,
    val targetCount: Int,
    val sourceType: String,
    val bookName: String,
    val hadithOrAyahNumber: String,
    val authenticityGrade: String,
    val narrationNotes: String,
    val referenceUrl: String
)

data class CityPreset(
    val country: String,
    val name: String,
    val shortName: String,
    val lat: Double,
    val lng: Double,
    val tz: Double,
    val method: CalculationMethod
)

data class PrayerOffsets(
    val fajr: Int = 0,
    val sunrise: Int = 0,
    val dhuhr: Int = 0,
    val asr: Int = 0,
    val maghrib: Int = 0,
    val isha: Int = 0
)

data class LocationSettings(
    val country: String = "الجزائر",
    val cityName: String = "تينركوك، ولاية أدرار",
    val shortName: String = "تينركوك، أدرار",
    val lat: Double = 29.2667,
    val lng: Double = 0.6333,
    val tz: Double = 1.0,
    val method: CalculationMethod = CalculationMethod.ALGERIA,
    val asrJuristic: AsrJuristic = AsrJuristic.STANDARD,
    val offsets: PrayerOffsets = PrayerOffsets()
)

data class PrayerTimeEntry(
    val key: PrayerKey,
    val timeStr: String,
    val totalMinutes: Int,
    val hours: Int,
    val minutes: Int
)

data class DailyPrayerTimes(
    val fajr: PrayerTimeEntry,
    val sunrise: PrayerTimeEntry,
    val dhuhr: PrayerTimeEntry,
    val asr: PrayerTimeEntry,
    val maghrib: PrayerTimeEntry,
    val isha: PrayerTimeEntry
) {
    fun byKey(key: PrayerKey): PrayerTimeEntry = when (key) {
        PrayerKey.FAJR -> fajr
        PrayerKey.SUNRISE -> sunrise
        PrayerKey.DHUHR -> dhuhr
        PrayerKey.ASR -> asr
        PrayerKey.MAGHRIB -> maghrib
        PrayerKey.ISHA -> isha
    }

    val allEntries: List<PrayerTimeEntry>
        get() = listOf(fajr, sunrise, dhuhr, asr, maghrib, isha)
}

data class NextPrayerInfo(
    val next: PrayerTimeEntry,
    val diffSeconds: Long,
    val todayTimes: DailyPrayerTimes,
    val windowHint: String
)

data class RawatibItem(
    val id: String,
    val title: String,
    val sub: String,
    val rakahs: Int
)

data class NawafilItem(
    val id: String,
    val title: String,
    val sub: String,
    val emoji: String
)

data class CustomDeed(
    val id: String,
    val title: String,
    val sub: String,
    val sortOrder: Int = 0
)

data class WorshipWeights(
    val prayers: Int = 50,
    val adhkar: Int = 14,
    val quran: Int = 12,
    val rawatib: Int = 12,
    val nawafil: Int = 12
)

data class DayWorshipRecord(
    val dateKey: String,
    val prayers: Map<PrayerKey, Boolean> = emptyMap(),
    val quran: Boolean = false,
    val quranPages: Int = 0,
    val rawatib: Set<String> = emptySet(),
    val nawafil: Set<String> = emptySet(),
    val custom: Set<String> = emptySet(),
    val excuse: Boolean = false
)

data class WorshipDayScore(
    val totalPercent: Int,
    val prayersDone: Int,
    val rawatibDone: Int,
    val nawafilDone: Int,
    val customDone: Int,
    val quranDone: Boolean,
    val morningPct: Int,
    val eveningPct: Int,
    val sleepPct: Int
)

data class CategoryProgressStats(
    val completed: Int,
    val total: Int,
    val percent: Int
)

data class CategoryStreak(
    val key: String,
    val label: String,
    val currentStreak: Int,
    val bestStreak: Int
)

data class AlarmConfig(
    val id: String,
    val title: String,
    val description: String,
    val enabled: Boolean,
    val timeValue: String,
    val alarmType: String, // "fixed_time" | "offset_min"
    val sortOrder: Int = 0
)

data class FreeTasbihState(
    val phrase: String = "سبحان الله وبحمده، سبحان الله العظيم",
    val current: Int = 0,
    val lifetime: Int = 0
)

enum class AdhanVoice(val key: String, val arabicName: String) {
    MAKKAH("makkah", "أذان الحرم (مقام الحجاز)"),
    FAJR_SERENE("fajr", "نداء الفجر الهادئ (مقام الصبا)"),
    TAKBIR("takbir", "تكبيرة وتنبيه لطيف"),
    CUSTOM("custom", "ملف صوتي مخصص من الجهاز");

    companion object {
        fun fromKey(key: String?): AdhanVoice =
            entries.firstOrNull { it.key == key } ?: MAKKAH
    }
}

data class AdhanSettings(
    val enabled: Boolean = true,
    val voice: AdhanVoice = AdhanVoice.MAKKAH,
    val customAudioUri: String = "",
    val customAudioName: String = "",
    val useAlarmChannel: Boolean = true,
    val perPrayerEnabled: Map<PrayerKey, Boolean> = mapOf(
        PrayerKey.FAJR to true,
        PrayerKey.DHUHR to true,
        PrayerKey.ASR to true,
        PrayerKey.MAGHRIB to true,
        PrayerKey.ISHA to true
    )
) {
    fun isPrayerEnabled(key: PrayerKey): Boolean =
        enabled && (perPrayerEnabled[key] ?: true)
}

