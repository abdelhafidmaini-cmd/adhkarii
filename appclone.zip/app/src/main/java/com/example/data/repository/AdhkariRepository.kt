package com.example.data.repository

import com.example.data.engine.PrayerTimeCalculator
import com.example.data.local.AdhkariDao
import com.example.data.local.AlarmEntity
import com.example.data.local.CustomDeedEntity
import com.example.data.local.DailyTotalEntity
import com.example.data.local.ProgressEntity
import com.example.data.local.SettingEntity
import com.example.data.local.WorshipLogEntity
import com.example.data.model.AdhanSettings
import com.example.data.model.AdhanVoice
import com.example.data.model.AlarmConfig
import com.example.data.model.AsrJuristic
import com.example.data.model.CalculationMethod
import com.example.data.model.CustomDeed
import com.example.data.model.DayWorshipRecord
import com.example.data.model.FreeTasbihState
import com.example.data.model.LocationSettings
import com.example.data.model.PrayerKey
import com.example.data.model.PrayerOffsets
import com.example.data.model.TasbihVariant
import com.example.data.model.ThemeMode
import com.example.data.model.WorshipWeights
import com.example.data.seed.AuthenticAdhkarData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

data class AppPreferencesBundle(
    val themeMode: ThemeMode = ThemeMode.LIGHT,
    val fontSize: Int = 22,
    val vibrationEnabled: Boolean = true,
    val soundEnabled: Boolean = false,
    val autoAdvance: Boolean = true,
    val readOnlyMode: Boolean = false,
    val tasbihVariant: TasbihVariant = TasbihVariant.MUSLIM_597,
    val currentPostPrayerTab: PrayerKey = PrayerKey.FAJR,
    val location: LocationSettings = LocationSettings(),
    val freeTasbih: FreeTasbihState = FreeTasbihState(),
    val worshipWeights: WorshipWeights = WorshipWeights(),
    val adhan: AdhanSettings = AdhanSettings()
)

class AdhkariRepository(private val dao: AdhkariDao) {

    suspend fun ensureSeeded() {
        if (dao.getAlarmsOnce().isEmpty()) {
            dao.upsertAlarms(
                AuthenticAdhkarData.DEFAULT_ALARMS.map {
                    AlarmEntity(
                        id = it.id,
                        title = it.title,
                        description = it.description,
                        enabled = it.enabled,
                        timeValue = it.timeValue,
                        alarmType = it.alarmType,
                        sortOrder = it.sortOrder
                    )
                }
            )
        }
        val settings = dao.getSettingsOnce().associate { it.key to it.value }
        if (!settings.containsKey("seeded_custom_deeds")) {
            dao.upsertCustomDeeds(
                AuthenticAdhkarData.DEFAULT_CUSTOM_DEEDS.map {
                    CustomDeedEntity(it.id, it.title, it.sub, it.sortOrder)
                }
            )
            dao.upsertSetting(SettingEntity("seeded_custom_deeds", "true"))
        }
    }

    val progressFlow: Flow<Map<String, Map<String, Int>>> = dao.observeAllProgress().map { list ->
        val grouped = mutableMapOf<String, MutableMap<String, Int>>()
        for (item in list) {
            val dayMap = grouped.getOrPut(item.dateKey) { mutableMapOf() }
            dayMap[item.counterKey] = item.currentCount
        }
        grouped
    }

    val dailyTotalsFlow: Flow<Map<String, Int>> = dao.observeAllTotals().map { list ->
        list.associate { it.dateKey to it.totalTasbihat }
    }

    val worshipLogsFlow: Flow<Map<String, DayWorshipRecord>> = dao.observeAllWorshipLogs().map { list ->
        list.associate { entity -> entity.dateKey to entity.toDomain() }
    }

    val customDeedsFlow: Flow<List<CustomDeed>> = dao.observeCustomDeeds().map { list ->
        list.map { CustomDeed(it.id, it.title, it.sub, it.sortOrder) }
    }

    val alarmsFlow: Flow<List<AlarmConfig>> = dao.observeAlarms().map { list ->
        list.map {
            AlarmConfig(
                id = it.id,
                title = it.title,
                description = it.description,
                enabled = it.enabled,
                timeValue = it.timeValue,
                alarmType = it.alarmType,
                sortOrder = it.sortOrder
            )
        }
    }

    val preferencesFlow: Flow<AppPreferencesBundle> = dao.observeSettings().map { list ->
        val map = list.associate { it.key to it.value }
        parsePreferences(map)
    }

    suspend fun getPreferencesOnce(): AppPreferencesBundle {
        val map = dao.getSettingsOnce().associate { it.key to it.value }
        return parsePreferences(map)
    }

    suspend fun getAlarmsOnce(): List<AlarmConfig> {
        return dao.getAlarmsOnce().map {
            AlarmConfig(it.id, it.title, it.description, it.enabled, it.timeValue, it.alarmType, it.sortOrder)
        }
    }

    suspend fun setDhikrCount(
        dateKey: String,
        counterKey: String,
        prevCount: Int,
        targetCount: Int,
        newCount: Int
    ): Int {
        val clamped = newCount.coerceIn(0, targetCount)
        dao.upsertProgress(
            ProgressEntity(
                dateKey = dateKey,
                counterKey = counterKey,
                currentCount = clamped,
                updatedAt = System.currentTimeMillis()
            )
        )
        val delta = clamped - prevCount
        val existingTotal = dao.getTotalForDate(dateKey)?.totalTasbihat ?: 0
        dao.upsertTotal(
            DailyTotalEntity(
                dateKey = dateKey,
                totalTasbihat = (existingTotal + delta).coerceAtLeast(0)
            )
        )
        return clamped
    }

    suspend fun setCategoryProgressBatch(
        dateKey: String,
        updates: List<Triple<String, Int, Int>> // counterKey, prevCount, newCount
    ) {
        if (updates.isEmpty()) return
        val entities = updates.map { (counterKey, _, newCount) ->
            ProgressEntity(dateKey, counterKey, newCount, System.currentTimeMillis())
        }
        dao.upsertProgressList(entities)
        val totalDelta = updates.sumOf { (_, prevCount, newCount) -> newCount - prevCount }
        val existingTotal = dao.getTotalForDate(dateKey)?.totalTasbihat ?: 0
        dao.upsertTotal(
            DailyTotalEntity(dateKey, (existingTotal + totalDelta).coerceAtLeast(0))
        )
    }

    suspend fun saveWorshipLog(record: DayWorshipRecord) {
        dao.upsertWorshipLog(record.toEntity())
    }

    suspend fun addCustomDeed(title: String, sub: String) {
        val existing = dao.getCustomDeedsOnce()
        val nextOrder = (existing.maxOfOrNull { it.sortOrder } ?: -1) + 1
        val deed = CustomDeedEntity(
            id = "cd_${System.currentTimeMillis()}",
            title = title.trim(),
            sub = sub.trim().ifEmpty { "عبادة يومية مخصصة" },
            sortOrder = nextOrder
        )
        dao.upsertCustomDeed(deed)
    }

    suspend fun deleteCustomDeed(id: String) {
        dao.deleteCustomDeed(id)
    }

    suspend fun updateAlarm(alarm: AlarmConfig) {
        dao.upsertAlarm(
            AlarmEntity(
                id = alarm.id,
                title = alarm.title,
                description = alarm.description,
                enabled = alarm.enabled,
                timeValue = alarm.timeValue,
                alarmType = alarm.alarmType,
                sortOrder = alarm.sortOrder
            )
        )
    }

    suspend fun saveSetting(key: String, value: String) {
        dao.upsertSetting(SettingEntity(key, value))
    }

    suspend fun saveLocation(loc: LocationSettings) {
        dao.upsertSettings(
            listOf(
                SettingEntity("loc_country", loc.country),
                SettingEntity("loc_city_name", loc.cityName),
                SettingEntity("loc_short_name", loc.shortName),
                SettingEntity("loc_lat", loc.lat.toString()),
                SettingEntity("loc_lng", loc.lng.toString()),
                SettingEntity("loc_tz", loc.tz.toString()),
                SettingEntity("loc_method", loc.method.key),
                SettingEntity("loc_asr", loc.asrJuristic.key),
                SettingEntity("loc_off_fajr", loc.offsets.fajr.toString()),
                SettingEntity("loc_off_sunrise", loc.offsets.sunrise.toString()),
                SettingEntity("loc_off_dhuhr", loc.offsets.dhuhr.toString()),
                SettingEntity("loc_off_asr", loc.offsets.asr.toString()),
                SettingEntity("loc_off_maghrib", loc.offsets.maghrib.toString()),
                SettingEntity("loc_off_isha", loc.offsets.isha.toString())
            )
        )
    }

    suspend fun saveFreeTasbih(state: FreeTasbihState) {
        dao.upsertSettings(
            listOf(
                SettingEntity("free_tasbih_phrase", state.phrase),
                SettingEntity("free_tasbih_current", state.current.toString()),
                SettingEntity("free_tasbih_lifetime", state.lifetime.toString())
            )
        )
    }

    suspend fun saveWorshipWeights(weights: WorshipWeights) {
        dao.upsertSettings(
            listOf(
                SettingEntity("w_prayers", weights.prayers.toString()),
                SettingEntity("w_adhkar", weights.adhkar.toString()),
                SettingEntity("w_quran", weights.quran.toString()),
                SettingEntity("w_rawatib", weights.rawatib.toString()),
                SettingEntity("w_nawafil", weights.nawafil.toString())
            )
        )
    }

    suspend fun saveAdhanSettings(adhan: AdhanSettings) {
        dao.upsertSettings(
            listOf(
                SettingEntity("adhan_enabled", adhan.enabled.toString()),
                SettingEntity("adhan_voice", adhan.voice.key),
                SettingEntity("adhan_custom_uri", adhan.customAudioUri),
                SettingEntity("adhan_custom_name", adhan.customAudioName),
                SettingEntity("adhan_alarm_channel", adhan.useAlarmChannel.toString()),
                SettingEntity("adhan_p_fajr", (adhan.perPrayerEnabled[PrayerKey.FAJR] ?: true).toString()),
                SettingEntity("adhan_p_dhuhr", (adhan.perPrayerEnabled[PrayerKey.DHUHR] ?: true).toString()),
                SettingEntity("adhan_p_asr", (adhan.perPrayerEnabled[PrayerKey.ASR] ?: true).toString()),
                SettingEntity("adhan_p_maghrib", (adhan.perPrayerEnabled[PrayerKey.MAGHRIB] ?: true).toString()),
                SettingEntity("adhan_p_isha", (adhan.perPrayerEnabled[PrayerKey.ISHA] ?: true).toString())
            )
        )
    }

    suspend fun exportBackupJson(): String {
        val progress = dao.getAllProgressOnce()
        val totals = dao.getAllTotalsOnce()
        val worship = dao.getAllWorshipLogsOnce()
        val customDeeds = dao.getCustomDeedsOnce()
        val alarms = dao.getAlarmsOnce()
        val settings = dao.getSettingsOnce()

        val root = JSONObject()
        root.put("app", "Adhkari")
        root.put("version", "1.0.0")
        root.put("exportedAt", System.currentTimeMillis())

        val progressArr = JSONArray()
        progress.forEach {
            progressArr.put(JSONObject().apply {
                put("dateKey", it.dateKey)
                put("counterKey", it.counterKey)
                put("currentCount", it.currentCount)
            })
        }
        root.put("dailyProgress", progressArr)

        val totalsArr = JSONArray()
        totals.forEach {
            totalsArr.put(JSONObject().apply {
                put("dateKey", it.dateKey)
                put("totalTasbihat", it.totalTasbihat)
            })
        }
        root.put("dailyTotals", totalsArr)

        val worshipArr = JSONArray()
        worship.forEach {
            worshipArr.put(JSONObject().apply {
                put("dateKey", it.dateKey)
                put("prayersMask", it.prayersMask)
                put("quran", it.quran)
                put("quranPages", it.quranPages)
                put("rawatibIdsCsv", it.rawatibIdsCsv)
                put("nawafilIdsCsv", it.nawafilIdsCsv)
                put("customIdsCsv", it.customIdsCsv)
                put("excuse", it.excuse)
            })
        }
        root.put("worshipLogs", worshipArr)

        val deedsArr = JSONArray()
        customDeeds.forEach {
            deedsArr.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("sub", it.sub)
                put("sortOrder", it.sortOrder)
            })
        }
        root.put("customDeeds", deedsArr)

        val alarmsArr = JSONArray()
        alarms.forEach {
            alarmsArr.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("description", it.description)
                put("enabled", it.enabled)
                put("timeValue", it.timeValue)
                put("alarmType", it.alarmType)
                put("sortOrder", it.sortOrder)
            })
        }
        root.put("alarms", alarmsArr)

        val settingsObj = JSONObject()
        settings.forEach { settingsObj.put(it.key, it.value) }
        root.put("settings", settingsObj)

        return root.toString(2)
    }

    suspend fun importBackupJson(jsonText: String): Boolean {
        return try {
            val root = JSONObject(jsonText)
            if (root.optString("app") != "Adhkari") return false

            val progressList = mutableListOf<ProgressEntity>()
            root.optJSONArray("dailyProgress")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    progressList.add(
                        ProgressEntity(
                            dateKey = obj.getString("dateKey"),
                            counterKey = obj.getString("counterKey"),
                            currentCount = obj.getInt("currentCount")
                        )
                    )
                }
            }

            val totalsList = mutableListOf<DailyTotalEntity>()
            root.optJSONArray("dailyTotals")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    totalsList.add(DailyTotalEntity(obj.getString("dateKey"), obj.getInt("totalTasbihat")))
                }
            }

            val worshipList = mutableListOf<WorshipLogEntity>()
            root.optJSONArray("worshipLogs")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    worshipList.add(
                        WorshipLogEntity(
                            dateKey = obj.getString("dateKey"),
                            prayersMask = obj.optInt("prayersMask", 0),
                            quran = obj.optBoolean("quran", false),
                            quranPages = obj.optInt("quranPages", 0),
                            rawatibIdsCsv = obj.optString("rawatibIdsCsv", ""),
                            nawafilIdsCsv = obj.optString("nawafilIdsCsv", ""),
                            customIdsCsv = obj.optString("customIdsCsv", ""),
                            excuse = obj.optBoolean("excuse", false)
                        )
                    )
                }
            }

            val deedsList = mutableListOf<CustomDeedEntity>()
            root.optJSONArray("customDeeds")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    deedsList.add(
                        CustomDeedEntity(
                            id = obj.getString("id"),
                            title = obj.getString("title"),
                            sub = obj.optString("sub", ""),
                            sortOrder = obj.optInt("sortOrder", i)
                        )
                    )
                }
            }

            val alarmsList = mutableListOf<AlarmEntity>()
            root.optJSONArray("alarms")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    alarmsList.add(
                        AlarmEntity(
                            id = obj.getString("id"),
                            title = obj.getString("title"),
                            description = obj.optString("description", ""),
                            enabled = obj.optBoolean("enabled", true),
                            timeValue = obj.getString("timeValue"),
                            alarmType = obj.getString("alarmType"),
                            sortOrder = obj.optInt("sortOrder", i)
                        )
                    )
                }
            }

            val settingsList = mutableListOf<SettingEntity>()
            root.optJSONObject("settings")?.let { obj ->
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    settingsList.add(SettingEntity(k, obj.getString(k)))
                }
            }

            dao.clearAllProgress()
            dao.clearAllTotals()
            dao.clearAllWorshipLogs()
            dao.clearCustomDeeds()
            dao.clearSettings()

            if (progressList.isNotEmpty()) dao.upsertProgressList(progressList)
            if (totalsList.isNotEmpty()) dao.upsertTotals(totalsList)
            if (worshipList.isNotEmpty()) dao.upsertWorshipLogs(worshipList)
            if (deedsList.isNotEmpty()) dao.upsertCustomDeeds(deedsList)
            if (alarmsList.isNotEmpty()) dao.upsertAlarms(alarmsList)
            if (settingsList.isNotEmpty()) dao.upsertSettings(settingsList)
            ensureSeeded()
            true
        } catch (_: Throwable) {
            false
        }
    }

    suspend fun getProgressSnapshotJson(): String {
        val todayKey = PrayerTimeCalculator.dateKeyOf()
        val progress = dao.getAllProgressOnce()
        val totals = dao.getAllTotalsOnce()
        val alarms = dao.getAlarmsOnce()
        val prefs = getPreferencesOnce()

        val root = JSONObject()
        root.put("todayDateKey", todayKey)
        root.put("progressRows", progress.size)
        root.put("totalsRows", totals.size)
        root.put("location", "${prefs.location.cityName} (${prefs.location.lat}, ${prefs.location.lng})")

        val progObj = JSONObject()
        progress.groupBy { it.dateKey }.forEach { (dk, list) ->
            val inner = JSONObject()
            list.forEach { inner.put(it.counterKey, it.currentCount) }
            progObj.put(dk, inner)
        }
        root.put("dailyProgress", progObj)

        val totObj = JSONObject()
        totals.forEach { totObj.put(it.dateKey, it.totalTasbihat) }
        root.put("dailyTotals", totObj)

        val alArr = JSONArray()
        alarms.forEach {
            alArr.put(JSONObject().apply {
                put("id", it.id)
                put("enabled", it.enabled)
                put("timeValue", it.timeValue)
            })
        }
        root.put("alarms", alArr)
        return root.toString(2)
    }

    fun generateAdhkarJsonPreview(): String {
        val arr = JSONArray()
        AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.take(15).forEach { d ->
            arr.put(JSONObject().apply {
                put("id", d.id)
                put("category_id", d.categoryId)
                put("sub_category", d.subCategory)
                put("target_count", d.targetCount)
                put("book_name", d.bookName)
                put("hadith_or_ayah_number", d.hadithOrAyahNumber)
                put("authenticity_grade", d.authenticityGrade)
            })
        }
        return "// عرض أول 15 سجل من إجمالي ${AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.size} ذكراً موثقاً:\n" +
            arr.toString(2)
    }

    fun generateCompleteSqlScript(): String {
        val ddl = """
-- ============================================================================
-- قاعدة بيانات تطبيق "أذكاري" (Adhkari SQLite Database Schema & Seed Data)
-- ============================================================================
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    icon TEXT,
    time_hint TEXT,
    description TEXT
);

CREATE TABLE IF NOT EXISTS adhkar (
    id TEXT PRIMARY KEY,
    category_id TEXT NOT NULL,
    sub_category TEXT,
    variant_group TEXT DEFAULT 'common',
    text TEXT NOT NULL,
    target_count INTEGER NOT NULL DEFAULT 1,
    source_type TEXT NOT NULL,
    book_name TEXT NOT NULL,
    hadith_or_ayah_number TEXT NOT NULL,
    authenticity_grade TEXT NOT NULL,
    narration_notes TEXT,
    reference_url TEXT,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS daily_progress (
    dateKey TEXT NOT NULL,
    counterKey TEXT NOT NULL,
    currentCount INTEGER NOT NULL DEFAULT 0,
    updatedAt INTEGER NOT NULL,
    PRIMARY KEY (dateKey, counterKey)
);

CREATE TABLE IF NOT EXISTS worship_logs (
    dateKey TEXT PRIMARY KEY,
    prayersMask INTEGER NOT NULL DEFAULT 0,
    quran INTEGER NOT NULL DEFAULT 0,
    quranPages INTEGER NOT NULL DEFAULT 0,
    rawatibIdsCsv TEXT,
    nawafilIdsCsv TEXT,
    customIdsCsv TEXT,
    excuse INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS alarms (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    timeValue TEXT NOT NULL,
    alarmType TEXT NOT NULL,
    sortOrder INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
""".trimIndent()

        fun esc(s: String): String = s.replace("'", "''")
        val catInserts = AuthenticAdhkarData.CATEGORIES_META.joinToString("\n") { c ->
            "INSERT OR REPLACE INTO categories VALUES ('${esc(c.id)}', '${esc(c.title)}', '${esc(c.emoji)}', '${esc(c.timeHint)}', '${esc(c.desc)}');"
        }
        val adhkarInserts = AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.joinToString("\n") { d ->
            "INSERT OR REPLACE INTO adhkar VALUES ('${esc(d.id)}', '${esc(d.categoryId)}', '${esc(d.subCategory)}', '${esc(d.variantGroup)}', '${esc(d.text)}', ${d.targetCount}, '${esc(d.sourceType)}', '${esc(d.bookName)}', '${esc(d.hadithOrAyahNumber)}', '${esc(d.authenticityGrade)}', '${esc(d.narrationNotes)}', '${esc(d.referenceUrl)}');"
        }

        return "$ddl\n\n-- التصنيفات:\n$catInserts\n\n-- الأذكار الموثقة (${AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.size} ذكراً):\n$adhkarInserts\n"
    }

    private fun parsePreferences(map: Map<String, String>): AppPreferencesBundle {
        val offsets = PrayerOffsets(
            fajr = map["loc_off_fajr"]?.toIntOrNull() ?: 0,
            sunrise = map["loc_off_sunrise"]?.toIntOrNull() ?: 0,
            dhuhr = map["loc_off_dhuhr"]?.toIntOrNull() ?: 0,
            asr = map["loc_off_asr"]?.toIntOrNull() ?: 0,
            maghrib = map["loc_off_maghrib"]?.toIntOrNull() ?: 0,
            isha = map["loc_off_isha"]?.toIntOrNull() ?: 0
        )
        val location = LocationSettings(
            country = map["loc_country"] ?: "الجزائر",
            cityName = map["loc_city_name"] ?: "تينركوك، ولاية أدرار",
            shortName = map["loc_short_name"] ?: "تينركوك، أدرار",
            lat = map["loc_lat"]?.toDoubleOrNull() ?: 29.2667,
            lng = map["loc_lng"]?.toDoubleOrNull() ?: 0.6333,
            tz = map["loc_tz"]?.toDoubleOrNull() ?: 1.0,
            method = CalculationMethod.fromKey(map["loc_method"]),
            asrJuristic = AsrJuristic.fromKey(map["loc_asr"]),
            offsets = offsets
        )
        val freeTasbih = FreeTasbihState(
            phrase = map["free_tasbih_phrase"] ?: "سبحان الله وبحمده، سبحان الله العظيم",
            current = map["free_tasbih_current"]?.toIntOrNull() ?: 0,
            lifetime = map["free_tasbih_lifetime"]?.toIntOrNull() ?: 0
        )
        val weights = WorshipWeights(
            prayers = map["w_prayers"]?.toIntOrNull() ?: 50,
            adhkar = map["w_adhkar"]?.toIntOrNull() ?: 14,
            quran = map["w_quran"]?.toIntOrNull() ?: 12,
            rawatib = map["w_rawatib"]?.toIntOrNull() ?: 12,
            nawafil = map["w_nawafil"]?.toIntOrNull() ?: 12
        )
        val adhan = AdhanSettings(
            enabled = map["adhan_enabled"]?.toBooleanStrictOrNull() ?: true,
            voice = AdhanVoice.fromKey(map["adhan_voice"]),
            customAudioUri = map["adhan_custom_uri"] ?: "",
            customAudioName = map["adhan_custom_name"] ?: "",
            useAlarmChannel = map["adhan_alarm_channel"]?.toBooleanStrictOrNull() ?: true,
            perPrayerEnabled = mapOf(
                PrayerKey.FAJR to (map["adhan_p_fajr"]?.toBooleanStrictOrNull() ?: true),
                PrayerKey.DHUHR to (map["adhan_p_dhuhr"]?.toBooleanStrictOrNull() ?: true),
                PrayerKey.ASR to (map["adhan_p_asr"]?.toBooleanStrictOrNull() ?: true),
                PrayerKey.MAGHRIB to (map["adhan_p_maghrib"]?.toBooleanStrictOrNull() ?: true),
                PrayerKey.ISHA to (map["adhan_p_isha"]?.toBooleanStrictOrNull() ?: true)
            )
        )
        return AppPreferencesBundle(
            themeMode = ThemeMode.fromKey(map["theme_mode"]),
            fontSize = map["font_size"]?.toIntOrNull() ?: 22,
            vibrationEnabled = map["vibration_enabled"]?.toBooleanStrictOrNull() ?: true,
            soundEnabled = map["sound_enabled"]?.toBooleanStrictOrNull() ?: false,
            autoAdvance = map["auto_advance"]?.toBooleanStrictOrNull() ?: true,
            readOnlyMode = map["read_only_mode"]?.toBooleanStrictOrNull() ?: false,
            tasbihVariant = TasbihVariant.fromKey(map["tasbih_variant"]),
            currentPostPrayerTab = PrayerKey.fiveObligatory.firstOrNull { it.key == map["post_prayer_tab"] } ?: PrayerKey.FAJR,
            location = location,
            freeTasbih = freeTasbih,
            worshipWeights = weights,
            adhan = adhan
        )
    }

    private fun WorshipLogEntity.toDomain(): DayWorshipRecord {
        val pMap = mapOf(
            PrayerKey.FAJR to ((prayersMask and 1) != 0),
            PrayerKey.DHUHR to ((prayersMask and 2) != 0),
            PrayerKey.ASR to ((prayersMask and 4) != 0),
            PrayerKey.MAGHRIB to ((prayersMask and 8) != 0),
            PrayerKey.ISHA to ((prayersMask and 16) != 0)
        )
        return DayWorshipRecord(
            dateKey = dateKey,
            prayers = pMap,
            quran = quran,
            quranPages = quranPages,
            rawatib = rawatibIdsCsv.split(",").filter { it.isNotBlank() }.toSet(),
            nawafil = nawafilIdsCsv.split(",").filter { it.isNotBlank() }.toSet(),
            custom = customIdsCsv.split(",").filter { it.isNotBlank() }.toSet(),
            excuse = excuse
        )
    }

    private fun DayWorshipRecord.toEntity(): WorshipLogEntity {
        var mask = 0
        if (prayers[PrayerKey.FAJR] == true) mask = mask or 1
        if (prayers[PrayerKey.DHUHR] == true) mask = mask or 2
        if (prayers[PrayerKey.ASR] == true) mask = mask or 4
        if (prayers[PrayerKey.MAGHRIB] == true) mask = mask or 8
        if (prayers[PrayerKey.ISHA] == true) mask = mask or 16
        return WorshipLogEntity(
            dateKey = dateKey,
            prayersMask = mask,
            quran = quran,
            quranPages = quranPages,
            rawatibIdsCsv = rawatib.joinToString(","),
            nawafilIdsCsv = nawafil.joinToString(","),
            customIdsCsv = custom.joinToString(","),
            excuse = excuse
        )
    }
}
