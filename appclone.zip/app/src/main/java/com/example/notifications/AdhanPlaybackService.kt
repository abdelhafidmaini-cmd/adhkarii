package com.example.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AdhkariDatabase
import com.example.data.model.AdhanSettings
import com.example.data.model.AdhanVoice
import com.example.data.model.PrayerKey
import com.example.data.repository.AdhkariRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AdhanPlaybackStatus(
    val isPlaying: Boolean = false,
    val prayerKey: PrayerKey? = null,
    val prayerTitle: String = "",
    val voiceName: String = "",
    val isPreview: Boolean = false
)

class AdhanPlaybackService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var playbackJob: Job? = null
    private var mediaPlayer: MediaPlayer? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_PLAY
        if (action == ACTION_STOP) {
            stopPlaybackAndService()
            return START_NOT_STICKY
        }

        val prayerKeyStr = intent?.getStringExtra(EXTRA_PRAYER_KEY)
        val prayerKey = PrayerKey.fiveObligatory.firstOrNull { it.key == prayerKeyStr }
        val isPreview = intent?.getBooleanExtra(EXTRA_IS_PREVIEW, false) ?: false
        val locationName = intent?.getStringExtra(EXTRA_LOCATION_NAME) ?: ""
        val prayerTitle = when {
            isPreview -> "معاينة صوت الأذان"
            prayerKey != null -> "صلاة ${prayerKey.arabicName}"
            else -> "الأذان"
        }

        ensureAdhanChannel(this)
        val notification = buildNotification(prayerTitle, locationName, isPreview)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                ADHAN_NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(ADHAN_NOTIF_ID, notification)
        }

        playbackJob?.cancel()
        playbackJob = serviceScope.launch {
            val prefs = try {
                val repo = AdhkariRepository(AdhkariDatabase.getInstance(applicationContext).adhkariDao())
                repo.getPreferencesOnce().adhan
            } catch (_: Throwable) {
                AdhanSettings()
            }

            startAudioPlayback(prefs, prayerKey, prayerTitle, isPreview)
        }

        return START_NOT_STICKY
    }

    private fun startAudioPlayback(
        adhan: AdhanSettings,
        prayerKey: PrayerKey?,
        prayerTitle: String,
        isPreview: Boolean
    ) {
        releasePlayerOnly()

        val usage = if (adhan.useAlarmChannel) {
            AudioAttributes.USAGE_ALARM
        } else {
            AudioAttributes.USAGE_MEDIA
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        requestFocus(attrs)

        val effectiveVoice = if (!isPreview && prayerKey == PrayerKey.FAJR && adhan.voice == AdhanVoice.MAKKAH) {
            AdhanVoice.FAJR_SERENE
        } else {
            adhan.voice
        }

        val mp = MediaPlayer().apply {
            setAudioAttributes(attrs)
        }

        var loaded = false
        if (effectiveVoice == AdhanVoice.CUSTOM && adhan.customAudioUri.isNotBlank()) {
            try {
                mp.setDataSource(applicationContext, Uri.parse(adhan.customAudioUri))
                mp.prepare()
                loaded = true
            } catch (_: Throwable) {
                mp.reset()
                mp.setAudioAttributes(attrs)
            }
        }

        if (!loaded) {
            val rawRes = when (effectiveVoice) {
                AdhanVoice.FAJR_SERENE -> R.raw.adhan_fajr
                AdhanVoice.TAKBIR -> R.raw.adhan_takbir
                AdhanVoice.MAKKAH, AdhanVoice.CUSTOM -> R.raw.adhan_makkah
            }
            try {
                val afd = resources.openRawResourceFd(rawRes)
                if (afd != null) {
                    mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                    mp.prepare()
                    loaded = true
                }
            } catch (_: Throwable) {
            }
        }

        if (!loaded) {
            mp.release()
            stopPlaybackAndService()
            return
        }

        mp.setOnCompletionListener {
            stopPlaybackAndService()
        }
        mp.setOnErrorListener { _, _, _ ->
            stopPlaybackAndService()
            true
        }

        mediaPlayer = mp
        _playbackStatus.value = AdhanPlaybackStatus(
            isPlaying = true,
            prayerKey = prayerKey,
            prayerTitle = prayerTitle,
            voiceName = effectiveVoice.arabicName,
            isPreview = isPreview
        )
        mp.start()
    }

    @Suppress("DEPRECATION")
    private fun requestFocus(attrs: AudioAttributes) {
        val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        audioManager = am
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setWillPauseWhenDucked(false)
                .build()
            focusRequest = req
            am.requestAudioFocus(req)
        } else {
            am.requestAudioFocus(
                null,
                if (attrs.usage == AudioAttributes.USAGE_ALARM) AudioManager.STREAM_ALARM else AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun abandonFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
            focusRequest = null
        } else {
            am.abandonAudioFocus(null)
        }
    }

    private fun releasePlayerOnly() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.stop()
                it.release()
            }
        } catch (_: Throwable) {
        }
        mediaPlayer = null
        abandonFocus()
    }

    private fun stopPlaybackAndService() {
        releasePlayerOnly()
        _playbackStatus.value = AdhanPlaybackStatus(isPlaying = false)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(prayerTitle: String, locationName: String, isPreview: Boolean): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_TAB_KEY, "prayers")
        }
        val openPi = PendingIntent.getActivity(
            this,
            510,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AdhanPlaybackService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPi = PendingIntent.getService(
            this,
            511,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isPreview) {
            "🕌 تجربة صوت الأذان — أذكاري"
        } else {
            "🕌 حان الآن وقت $prayerTitle"
        }
        val body = buildString {
            if (!isPreview && locationName.isNotBlank()) {
                append("حسب توقيت $locationName • ")
            }
            append("اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ وَالصَّلَاةِ الْقَائِمَةِ...")
        }

        return NotificationCompat.Builder(this, ADHAN_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openPi)
            .addAction(0, "⏹ إيقاف الأذان", stopPi)
            .build()
    }

    override fun onDestroy() {
        releasePlayerOnly()
        _playbackStatus.value = AdhanPlaybackStatus(isPlaying = false)
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ADHAN_CHANNEL_ID = "adhkari_adhan_playback"
        const val ADHAN_NOTIF_ID = 4100
        const val ACTION_PLAY = "com.example.action.PLAY_ADHAN"
        const val ACTION_STOP = "com.example.action.STOP_ADHAN"
        const val EXTRA_PRAYER_KEY = "extra_prayer_key"
        const val EXTRA_IS_PREVIEW = "extra_is_preview"
        const val EXTRA_LOCATION_NAME = "extra_location_name"
        const val EXTRA_OPEN_TAB_KEY = "extra_open_tab"

        private val _playbackStatus = MutableStateFlow(AdhanPlaybackStatus())
        val playbackStatus: StateFlow<AdhanPlaybackStatus> = _playbackStatus.asStateFlow()

        fun ensureAdhanChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
                if (nm.getNotificationChannel(ADHAN_CHANNEL_ID) == null) {
                    val ch = NotificationChannel(
                        ADHAN_CHANNEL_ID,
                        "تشغيل صوت الأذان",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "إشعار مستمر أثناء رفع الأذان مع زر الإيقاف الفوري"
                        setSound(null, null)
                        enableVibration(true)
                    }
                    nm.createNotificationChannel(ch)
                }
            }
        }

        fun startAdhan(
            context: Context,
            prayerKey: PrayerKey?,
            locationName: String = "",
            isPreview: Boolean = false
        ) {
            ensureAdhanChannel(context)
            val intent = Intent(context, AdhanPlaybackService::class.java).apply {
                action = ACTION_PLAY
                putExtra(EXTRA_PRAYER_KEY, prayerKey?.key)
                putExtra(EXTRA_LOCATION_NAME, locationName)
                putExtra(EXTRA_IS_PREVIEW, isPreview)
            }
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Throwable) {
            }
        }

        fun stopAdhan(context: Context) {
            val intent = Intent(context, AdhanPlaybackService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                context.startService(intent)
            } catch (_: Throwable) {
            }
        }
    }
}
