package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.AdhkariDatabase
import com.example.data.model.PrayerKey
import com.example.data.repository.AdhkariRepository
import com.example.widget.AdhkariWidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "تطبيق أذكاري"
        val body = intent.getStringExtra(EXTRA_BODY) ?: "حان موعد الذكر!"
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, 2001)
        val isAdhan = intent.getBooleanExtra(EXTRA_IS_ADHAN, false)
        val prayerKeyStr = intent.getStringExtra(EXTRA_PRAYER_KEY)
        val locationName = intent.getStringExtra(EXTRA_LOCATION_NAME) ?: ""
        val prayerKey = PrayerKey.fiveObligatory.firstOrNull { it.key == prayerKeyStr }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = AdhkariRepository(AdhkariDatabase.getInstance(context).adhkariDao())
                val alarms = repo.getAlarmsOnce()
                val prefs = repo.getPreferencesOnce()

                val shouldPlayAdhanAudio = isAdhan &&
                    prefs.adhan.enabled &&
                    (prayerKey == null || prefs.adhan.isPrayerEnabled(prayerKey))

                if (shouldPlayAdhanAudio) {
                    AdhanPlaybackService.startAdhan(
                        context = context.applicationContext,
                        prayerKey = prayerKey,
                        locationName = locationName.ifBlank { prefs.location.shortName },
                        isPreview = false
                    )
                } else {
                    NotificationHelper.showNotification(context, notifId, title, body)
                }

                AlarmScheduler.scheduleAllAlarms(context, alarms, prefs.location, prefs.adhan)
                AdhkariWidgetUpdater.updateAllWidgets(context.applicationContext)
            } catch (_: Throwable) {
                if (isAdhan) {
                    AdhanPlaybackService.startAdhan(context.applicationContext, prayerKey, locationName, false)
                } else {
                    NotificationHelper.showNotification(context, notifId, title, body)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_BODY = "extra_body"
        const val EXTRA_NOTIF_ID = "extra_notif_id"
        const val EXTRA_IS_ADHAN = "extra_is_adhan"
        const val EXTRA_PRAYER_KEY = "extra_prayer_key"
        const val EXTRA_LOCATION_NAME = "extra_location_name"
    }
}
