package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.model.AdhanSettings
import com.example.data.model.AlarmConfig
import com.example.data.model.LocationSettings
import com.example.data.model.PrayerKey
import java.util.Calendar

object AlarmScheduler {

    fun scheduleAllAlarms(
        context: Context,
        alarms: List<AlarmConfig>,
        location: LocationSettings,
        adhanSettings: AdhanSettings = AdhanSettings()
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = Calendar.getInstance()

        // Cancel existing request codes (100..160) before rescheduling
        for (req in 100..160) {
            val pi = buildPendingIntent(context, req, "", "", false, null, "")
            alarmManager.cancel(pi)
        }

        var nextReqCode = 100
        var prayerEntryScheduled = false

        alarms.forEach { alarm ->
            val isPrayerEntryAlarm = alarm.id == "alarm_prayer_entry"
            val shouldSchedule = alarm.enabled || (isPrayerEntryAlarm && adhanSettings.enabled)
            if (!shouldSchedule) return@forEach

            if (isPrayerEntryAlarm) {
                prayerEntryScheduled = true
            }

            if (alarm.alarmType == "fixed_time") {
                val parts = alarm.timeValue.split(":")
                val hr = parts.getOrNull(0)?.toIntOrNull() ?: return@forEach
                val min = parts.getOrNull(1)?.toIntOrNull() ?: return@forEach

                val target = (now.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, hr)
                    set(Calendar.MINUTE, min)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= now.timeInMillis) {
                        add(Calendar.DAY_OF_MONTH, 1)
                    }
                }
                scheduleSingle(
                    alarmManager = alarmManager,
                    context = context,
                    requestCode = nextReqCode++,
                    triggerAtMillis = target.timeInMillis,
                    title = "تطبيق أذكاري",
                    body = "حان الآن موعد ${alarm.title}",
                    isAdhan = false,
                    prayerKey = null,
                    locationName = location.shortName
                )
            } else {
                val offsetMin = alarm.timeValue.toIntOrNull() ?: 0
                val todayTimes = PrayerTimeCalculator.computePrayerTimesForDate(now, location)
                val tomorrow = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
                val tomorrowTimes = PrayerTimeCalculator.computePrayerTimesForDate(tomorrow, location)

                PrayerKey.fiveObligatory.forEach { pKey ->
                    val entryToday = todayTimes.byKey(pKey)
                    val deltaMin = when (alarm.id) {
                        "alarm_before_prayer" -> -offsetMin
                        "alarm_after_prayer" -> offsetMin
                        else -> 0
                    }

                    val target = (now.clone() as Calendar).apply {
                        set(Calendar.HOUR_OF_DAY, entryToday.hours)
                        set(Calendar.MINUTE, entryToday.minutes)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                        add(Calendar.MINUTE, deltaMin)
                    }

                    if (target.timeInMillis <= now.timeInMillis) {
                        val entryTomorrow = tomorrowTimes.byKey(pKey)
                        target.timeInMillis = tomorrow.timeInMillis
                        target.set(Calendar.HOUR_OF_DAY, entryTomorrow.hours)
                        target.set(Calendar.MINUTE, entryTomorrow.minutes)
                        target.set(Calendar.SECOND, 0)
                        target.set(Calendar.MILLISECOND, 0)
                        target.add(Calendar.MINUTE, deltaMin)
                    }

                    val body = when (alarm.id) {
                        "alarm_before_prayer" -> "متبقي $offsetMin دقيقة على صلاة ${pKey.arabicName}"
                        "alarm_after_prayer" -> "تذكير بأذكار بعد صلاة ${pKey.arabicName}"
                        else -> "حان الآن وقت صلاة ${pKey.arabicName} حسب توقيت ${location.shortName}"
                    }

                    scheduleSingle(
                        alarmManager = alarmManager,
                        context = context,
                        requestCode = nextReqCode++,
                        triggerAtMillis = target.timeInMillis,
                        title = if (isPrayerEntryAlarm) "🕌 صلاة ${pKey.arabicName}" else "تطبيق أذكاري",
                        body = body,
                        isAdhan = isPrayerEntryAlarm,
                        prayerKey = pKey.key,
                        locationName = location.shortName
                    )
                }
            }
        }

        // Guarantee prayer-entry scheduling whenever Adhan is enabled even before alarms list finishes seeding
        if (!prayerEntryScheduled && adhanSettings.enabled) {
            val todayTimes = PrayerTimeCalculator.computePrayerTimesForDate(now, location)
            val tomorrow = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
            val tomorrowTimes = PrayerTimeCalculator.computePrayerTimesForDate(tomorrow, location)
            PrayerKey.fiveObligatory.forEach { pKey ->
                val entryToday = todayTimes.byKey(pKey)
                val target = (now.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, entryToday.hours)
                    set(Calendar.MINUTE, entryToday.minutes)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (target.timeInMillis <= now.timeInMillis) {
                    val entryTomorrow = tomorrowTimes.byKey(pKey)
                    target.timeInMillis = tomorrow.timeInMillis
                    target.set(Calendar.HOUR_OF_DAY, entryTomorrow.hours)
                    target.set(Calendar.MINUTE, entryTomorrow.minutes)
                    target.set(Calendar.SECOND, 0)
                    target.set(Calendar.MILLISECOND, 0)
                }
                scheduleSingle(
                    alarmManager = alarmManager,
                    context = context,
                    requestCode = nextReqCode++,
                    triggerAtMillis = target.timeInMillis,
                    title = "🕌 صلاة ${pKey.arabicName}",
                    body = "حان الآن وقت صلاة ${pKey.arabicName} حسب توقيت ${location.shortName}",
                    isAdhan = true,
                    prayerKey = pKey.key,
                    locationName = location.shortName
                )
            }
        }
    }

    private fun scheduleSingle(
        alarmManager: AlarmManager,
        context: Context,
        requestCode: Int,
        triggerAtMillis: Long,
        title: String,
        body: String,
        isAdhan: Boolean,
        prayerKey: String?,
        locationName: String
    ) {
        val pi = buildPendingIntent(context, requestCode, title, body, isAdhan, prayerKey, locationName)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    private fun buildPendingIntent(
        context: Context,
        requestCode: Int,
        title: String,
        body: String,
        isAdhan: Boolean,
        prayerKey: String?,
        locationName: String
    ): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(AlarmReceiver.EXTRA_TITLE, title)
            putExtra(AlarmReceiver.EXTRA_BODY, body)
            putExtra(AlarmReceiver.EXTRA_NOTIF_ID, 2000 + requestCode)
            putExtra(AlarmReceiver.EXTRA_IS_ADHAN, isAdhan)
            putExtra(AlarmReceiver.EXTRA_PRAYER_KEY, prayerKey)
            putExtra(AlarmReceiver.EXTRA_LOCATION_NAME, locationName)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
