package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.AdhkariDatabase
import com.example.data.repository.AdhkariRepository
import com.example.widget.AdhkariWidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = AdhkariRepository(AdhkariDatabase.getInstance(context).adhkariDao())
                repo.ensureSeeded()
                val alarms = repo.getAlarmsOnce()
                val prefs = repo.getPreferencesOnce()
                AlarmScheduler.scheduleAllAlarms(context, alarms, prefs.location, prefs.adhan)
                AdhkariWidgetUpdater.updateAllWidgets(context.applicationContext)
            } catch (_: Throwable) {
            } finally {
                pendingResult.finish()
            }
        }
    }
}
