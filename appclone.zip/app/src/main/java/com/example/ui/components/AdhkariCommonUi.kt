package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppTab
import com.example.ui.theme.AmberStar
import com.example.ui.theme.LocalAdhkariColors

@Composable
fun AdhkariTopHeader(
    title: String,
    subtitle: String,
    showBack: Boolean,
    isDark: Boolean,
    onBackClick: () -> Unit,
    onSearchClick: () -> Unit,
    onThemeToggleClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.bgPrimary)
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                if (showBack) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("btn_header_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = colors.textPrimary
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                }
                CrescentEmblem(modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 19.sp),
                        color = colors.accentPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier.testTag("btn_quick_search")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "البحث في الأذكار",
                        tint = colors.textPrimary
                    )
                }
                IconButton(
                    onClick = onThemeToggleClick,
                    modifier = Modifier.testTag("btn_quick_theme")
                ) {
                    Icon(
                        imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "تغيير المظهر",
                        tint = if (isDark) colors.accentPrimary else colors.goldAccent
                    )
                }
                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier.testTag("btn_header_settings")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات",
                        tint = colors.textPrimary
                    )
                }
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.borderColor)
                .padding(top = 1.dp)
        )
    }
}

@Composable
fun CrescentEmblem(modifier: Modifier = Modifier) {
    val colors = LocalAdhkariColors.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.linearGradient(
                    listOf(colors.heroStart, colors.heroMid, colors.heroEnd)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(22.dp)) {
            val w = size.width
            val h = size.height
            // Crescent + Star stylized
            val starPath = Path().apply {
                moveTo(w * 0.50f, h * 0.08f)
                lineTo(w * 0.40f, h * 0.27f)
                lineTo(w * 0.21f, h * 0.37f)
                lineTo(w * 0.40f, h * 0.47f)
                lineTo(w * 0.50f, h * 0.66f)
                lineTo(w * 0.60f, h * 0.47f)
                lineTo(w * 0.79f, h * 0.37f)
                lineTo(w * 0.60f, h * 0.27f)
                close()
            }
            drawPath(starPath, color = AmberStar)
            drawArc(
                color = AmberStar,
                startAngle = 25f,
                sweepAngle = 215f,
                useCenter = false,
                topLeft = Offset(w * 0.14f, h * 0.30f),
                size = Size(w * 0.72f, h * 0.62f),
                style = Stroke(width = w * 0.13f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun AdhkariBottomBar(
    currentTab: AppTab,
    currentCategory: String,
    onSelectTab: (AppTab) -> Unit,
    onOpenCategory: (String) -> Unit
) {
    val colors = LocalAdhkariColors.current
    val activeKey = when {
        currentTab == AppTab.HOME -> "home"
        currentTab == AppTab.READER && currentCategory == "morning" -> "morning"
        currentTab == AppTab.READER && currentCategory == "evening" -> "evening"
        currentTab == AppTab.WORSHIP -> "worship"
        currentTab == AppTab.PRAYERS -> "prayers"
        else -> "more"
    }

    Surface(
        color = colors.bgCard,
        tonalElevation = 4.dp,
        shadowElevation = 8.dp,
        border = BorderStroke(1.dp, colors.borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            BottomNavTabItem(
                label = "الرئيسية",
                icon = Icons.Default.Home,
                selected = activeKey == "home",
                tag = "nav_home",
                modifier = Modifier.weight(1f),
                onClick = { onSelectTab(AppTab.HOME) }
            )
            BottomNavTabItem(
                label = "الصباح",
                icon = Icons.Default.WbSunny,
                selected = activeKey == "morning",
                tag = "nav_morning",
                modifier = Modifier.weight(1f),
                onClick = { onOpenCategory("morning") }
            )
            BottomNavTabItem(
                label = "المساء",
                icon = Icons.Default.NightsStay,
                selected = activeKey == "evening",
                tag = "nav_evening",
                modifier = Modifier.weight(1f),
                onClick = { onOpenCategory("evening") }
            )
            BottomNavTabItem(
                label = "عباداتي",
                icon = Icons.Default.CheckCircle,
                selected = activeKey == "worship",
                tag = "nav_worship",
                modifier = Modifier.weight(1f),
                onClick = { onSelectTab(AppTab.WORSHIP) }
            )
            BottomNavTabItem(
                label = "الصلاة",
                icon = Icons.Default.Schedule,
                selected = activeKey == "prayers",
                tag = "nav_prayers",
                modifier = Modifier.weight(1f),
                onClick = { onSelectTab(AppTab.PRAYERS) }
            )
            BottomNavTabItem(
                label = "المزيد",
                icon = Icons.Default.GridView,
                selected = activeKey == "more",
                tag = "nav_more",
                modifier = Modifier.weight(1f),
                onClick = { onSelectTab(AppTab.MORE) }
            )
        }
    }
}

@Composable
private fun BottomNavTabItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    tag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) colors.accentLight else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
            .testTag(tag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) colors.accentPrimary else colors.textSecondary,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Bold,
            color = if (selected) colors.accentPrimary else colors.textSecondary,
            maxLines = 1
        )
    }
}

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    borderColor: Color? = null,
    backgroundColor: Color? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = LocalAdhkariColors.current
    val shape = RoundedCornerShape(18.dp)
    val baseModifier = modifier
        .clip(shape)
        .background(backgroundColor ?: colors.bgCard)
        .border(1.dp, borderColor ?: colors.borderColor, shape)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }

    Column(modifier = baseModifier, content = content)
}

@Composable
fun HeroGradientBox(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = LocalAdhkariColors.current
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(colors.heroStart, colors.heroMid, colors.heroEnd)
                )
            )
            .let {
                if (colors.isDark) it.border(1.dp, Color(0xFF145337), shape) else it
            },
        content = content
    )
}

@Composable
fun CircularProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 5.dp,
    activeColor: Color? = null,
    trackColor: Color? = null
) {
    val colors = LocalAdhkariColors.current
    val fg = activeColor ?: colors.accentPrimary
    val bg = trackColor ?: colors.textPrimary.copy(alpha = 0.12f)
    Canvas(modifier = modifier) {
        val strokePx = strokeWidth.toPx()
        val inset = strokePx / 2f
        val arcSize = Size(size.width - strokePx, size.height - strokePx)
        drawArc(
            color = bg,
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = arcSize,
            style = Stroke(width = strokePx, cap = StrokeCap.Round)
        )
        drawArc(
            color = fg,
            startAngle = -90f,
            sweepAngle = 360f * progress.coerceIn(0f, 1f),
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = arcSize,
            style = Stroke(width = strokePx, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun AdhkariToastBanner(
    message: String?,
    modifier: Modifier = Modifier
) {
    val colors = LocalAdhkariColors.current
    AnimatedVisibility(
        visible = message != null,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut() + slideOutVertically { it / 2 },
        modifier = modifier
    ) {
        Surface(
            color = colors.accentPrimary,
            shape = RoundedCornerShape(16.dp),
            shadowElevation = 6.dp
        ) {
            Text(
                text = message ?: "",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun AdhanNowPlayingBanner(
    visible: Boolean,
    prayerTitle: String,
    voiceName: String,
    onStopClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalAdhkariColors.current
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically { -it / 2 },
        exit = fadeOut() + slideOutVertically { -it / 2 },
        modifier = modifier
    ) {
        Surface(
            color = colors.heroStart,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, AmberStar.copy(alpha = 0.7f)),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "🕌 يرفع الآن الأذان — $prayerTitle",
                        color = AmberStar,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = voiceName,
                        color = Color(0xFFD1FAE5),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(8.dp))
                Surface(
                    color = Color(0xFFDC2626),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onStopClick)
                        .testTag("btn_banner_stop_adhan")
                ) {
                    Text(
                        text = "⏹ إيقاف الأذان",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}

