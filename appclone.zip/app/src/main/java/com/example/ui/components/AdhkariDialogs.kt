package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DhikrItem
import com.example.data.model.FreeTasbihState
import com.example.data.model.LocationSettings
import com.example.data.model.WorshipWeights
import com.example.data.seed.AuthenticAdhkarData
import com.example.ui.theme.AmberBadge
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.DangerRed
import com.example.ui.theme.LocalAdhkariColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationSelectionDialog(
    currentLocation: LocationSettings,
    gpsStatusMessage: String,
    onRequestGps: () -> Unit,
    onSaveLocation: (LocationSettings) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    val countries = AuthenticAdhkarData.CITIES_BY_COUNTRY.keys.toList()
    var selectedCountry by remember {
        mutableStateOf(
            if (AuthenticAdhkarData.CITIES_BY_COUNTRY.containsKey(currentLocation.country)) {
                currentLocation.country
            } else {
                countries.first()
            }
        )
    }
    val cities = AuthenticAdhkarData.CITIES_BY_COUNTRY[selectedCountry].orEmpty()
    var selectedCity by remember(selectedCountry) {
        mutableStateOf(
            cities.firstOrNull { it.name == currentLocation.cityName } ?: cities.first()
        )
    }
    var latText by remember { mutableStateOf(currentLocation.lat.toString()) }
    var lngText by remember { mutableStateOf(currentLocation.lng.toString()) }
    var tzText by remember { mutableStateOf(currentLocation.tz.toString()) }
    var countryExpanded by remember { mutableStateOf(false) }
    var cityExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        AppCard(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إعداد الموقع ومواقيت الصلاة",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.accentPrimary
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = colors.textPrimary)
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.bgSecondary)
                        .border(1.dp, colors.borderColor, RoundedCornerShape(14.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "التحديد التلقائي عبر نظام الموقع (GPS):",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textPrimary
                    )
                    Button(
                        onClick = onRequestGps,
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("btn_detect_gps")
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("تحديد موقعي الحالي تلقائياً (بإذن المستخدم)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (gpsStatusMessage.isNotBlank()) {
                        Text(gpsStatusMessage, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                    }
                }

                Text(
                    text = "أو اختيار الدولة والولاية والمدينة يدوياً (يعمل دون إنترنت):",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textPrimary
                )

                ExposedDropdownMenuBox(expanded = countryExpanded, onExpandedChange = { countryExpanded = it }) {
                    OutlinedTextField(
                        value = selectedCountry,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("الدولة") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = countryExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = countryExpanded, onDismissRequest = { countryExpanded = false }) {
                        countries.forEach { country ->
                            DropdownMenuItem(
                                text = { Text(country) },
                                onClick = {
                                    selectedCountry = country
                                    val firstCity = AuthenticAdhkarData.CITIES_BY_COUNTRY[country]?.firstOrNull()
                                    if (firstCity != null) {
                                        selectedCity = firstCity
                                        latText = firstCity.lat.toString()
                                        lngText = firstCity.lng.toString()
                                        tzText = firstCity.tz.toString()
                                    }
                                    countryExpanded = false
                                }
                            )
                        }
                    }
                }

                ExposedDropdownMenuBox(expanded = cityExpanded, onExpandedChange = { cityExpanded = it }) {
                    OutlinedTextField(
                        value = selectedCity.name,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("الولاية / المدينة") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = cityExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = cityExpanded, onDismissRequest = { cityExpanded = false }) {
                        cities.forEach { city ->
                            DropdownMenuItem(
                                text = { Text(city.name) },
                                onClick = {
                                    selectedCity = city
                                    latText = city.lat.toString()
                                    lngText = city.lng.toString()
                                    tzText = city.tz.toString()
                                    cityExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = latText,
                        onValueChange = { latText = it },
                        label = { Text("خط العرض") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = lngText,
                        onValueChange = { lngText = it },
                        label = { Text("خط الطول") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = tzText,
                        onValueChange = { tzText = it },
                        label = { Text("UTC") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(0.8f),
                        singleLine = true
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Button(
                        onClick = {
                            onSaveLocation(
                                currentLocation.copy(
                                    country = selectedCountry,
                                    cityName = selectedCity.name,
                                    shortName = selectedCity.shortName,
                                    lat = latText.toDoubleOrNull() ?: selectedCity.lat,
                                    lng = lngText.toDoubleOrNull() ?: selectedCity.lng,
                                    tz = tzText.toDoubleOrNull() ?: selectedCity.tz,
                                    method = selectedCity.method
                                )
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("btn_save_location")
                    ) {
                        Text("حفظ وتحديث المواقيت", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun SourceDetailDialog(
    dhikr: DhikrItem,
    onDismiss: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "توثيق الذكر وتخريج الحديث",
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.accentPrimary
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = colors.textPrimary)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.bgSecondary)
                        .border(1.dp, colors.borderColor, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = dhikr.text,
                        fontFamily = AmiriFontFamily,
                        fontSize = 18.sp,
                        lineHeight = 32.sp,
                        color = colors.textPrimary
                    )
                }

                SourceDetailRow("الباب / التصنيف:", dhikr.subCategory)
                SourceDetailRow("العدد الثابت:", "${dhikr.targetCount} ${if (dhikr.targetCount == 1) "مرة" else "مرات"}")
                SourceDetailRow("المصدر والكتاب:", dhikr.bookName)
                SourceDetailRow("رقم الحديث / موضع الآية:", dhikr.hadithOrAyahNumber)
                SourceDetailRow("درجة الصحة والحكم الحديثي:", dhikr.authenticityGrade)
                SourceDetailRow("بيان الرواية والفضل:", dhikr.narrationNotes)

                Text(
                    text = "مراجعة التخريج في المصدر العلمي الموثق ↗",
                    color = colors.accentPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textDecoration = TextDecoration.Underline,
                    modifier = Modifier
                        .clickable {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(dhikr.referenceUrl))
                                context.startActivity(intent)
                            } catch (_: Throwable) {
                            }
                        }
                        .padding(vertical = 4.dp)
                )

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("إغلاق", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SourceDetailRow(label: String, value: String) {
    val colors = LocalAdhkariColors.current
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = colors.accentPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(value, color = colors.textPrimary, fontSize = 13.sp, lineHeight = 20.sp)
    }
}

@Composable
fun ConfirmResetDialog(
    title: String,
    message: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    Dialog(onDismissRequest = onDismiss) {
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(AmberBadge.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = AmberBadge)
                }
                Text(title, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Text(
                    message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary,
                    textAlign = TextAlign.Center
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = colors.textPrimary)
                    }
                    Button(
                        onClick = {
                            onConfirm()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("btn_confirm_reset")
                    ) {
                        Text("نعم، إعادة ضبط", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FreeTasbihDialog(
    state: FreeTasbihState,
    onPhraseChange: (String) -> Unit,
    onIncrement: () -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    val phrases = listOf(
        "سبحان الله وبحمده، سبحان الله العظيم",
        "أستغفر الله وأتوب إليه",
        "لا حول ولا قوة إلا بالله",
        "اللهم صل وسلم على نبينا محمد",
        "سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر"
    )
    var expanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("المسبحة الإلكترونية", style = MaterialTheme.typography.titleMedium, color = colors.accentPrimary)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = colors.textPrimary)
                    }
                }

                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = state.phrase,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        phrases.forEach { p ->
                            DropdownMenuItem(
                                text = { Text(p, fontSize = 13.sp) },
                                onClick = {
                                    onPhraseChange(p)
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .size(176.dp)
                        .clip(CircleShape)
                        .background(colors.accentLight)
                        .border(8.dp, colors.accentPrimary, CircleShape)
                        .clickable(onClick = onIncrement)
                        .testTag("btn_free_tasbih_tap"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = state.current.toString(),
                            fontSize = 40.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.accentPrimary
                        )
                        Text("اضغط للتسبيح", fontSize = 12.sp, color = colors.textSecondary)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مجموع التسبيحات الكلي: ${state.lifetime}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    TextButton(onClick = onReset) {
                        Text("تصفير العداد", color = DangerRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AddCustomDeedDialog(
    onAdd: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    var title by remember { mutableStateOf("") }
    var sub by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("إضافة عبادة أو ورد يومي", style = MaterialTheme.typography.titleMedium, color = colors.accentPrimary)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = colors.textPrimary)
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم العبادة / الطاعة") },
                    placeholder = { Text("مثال: صدقة يومية، صلة رحم، استغفار 100 مرة...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = sub,
                    onValueChange = { sub = it },
                    label = { Text("وصف مختصر") },
                    placeholder = { Text("مثال: ولو بالقليل، قراءة تفسير صفحة...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("إلغاء", color = colors.textSecondary)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onAdd(title, sub)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("إضافة العبادة", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun WeightsEditorDialog(
    currentWeights: WorshipWeights,
    onSave: (WorshipWeights) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    var prayers by remember { mutableStateOf(currentWeights.prayers.toString()) }
    var adhkar by remember { mutableStateOf(currentWeights.adhkar.toString()) }
    var quran by remember { mutableStateOf(currentWeights.quran.toString()) }
    var rawatib by remember { mutableStateOf(currentWeights.rawatib.toString()) }
    var nawafil by remember { mutableStateOf(currentWeights.nawafil.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تعديل أوزان حساب الإنجاز اليومي", style = MaterialTheme.typography.titleMedium, color = colors.goldAccent)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = colors.textPrimary)
                    }
                }
                Text("حدد النسبة المئوية لكل قسم في حساب مؤشر إنجازك اليومي:", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)

                WeightInputRow("الصلوات المفروضة (%):", prayers) { prayers = it }
                WeightInputRow("الأذكار اليومية (%):", adhkar) { adhkar = it }
                WeightInputRow("القرآن الكريم (%):", quran) { quran = it }
                WeightInputRow("السنن الرواتب (%):", rawatib) { rawatib = it }
                WeightInputRow("عبادات يومية ونوافل (%):", nawafil) { nawafil = it }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        prayers = "50"; adhkar = "14"; quran = "12"; rawatib = "12"; nawafil = "12"
                    }) {
                        Text("الافتراضي", color = colors.textSecondary)
                    }
                    Button(
                        onClick = {
                            onSave(
                                WorshipWeights(
                                    prayers = (prayers.toIntOrNull() ?: 50).coerceAtLeast(0),
                                    adhkar = (adhkar.toIntOrNull() ?: 14).coerceAtLeast(0),
                                    quran = (quran.toIntOrNull() ?: 12).coerceAtLeast(0),
                                    rawatib = (rawatib.toIntOrNull() ?: 12).coerceAtLeast(0),
                                    nawafil = (nawafil.toIntOrNull() ?: 12).coerceAtLeast(0)
                                )
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("حفظ الأوزان", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun WeightInputRow(label: String, value: String, onValueChange: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.width(86.dp)
        )
    }
}

@Composable
fun SqlInspectorDialog(
    sqlScript: String,
    adhkarPreview: String,
    loadProgressSnapshot: suspend () -> String,
    onDownloadSql: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    var selectedTab by remember { mutableStateOf("schema") }
    var progressSnapshot by remember { mutableStateOf("جاري التحميل...") }

    LaunchedEffect(selectedTab) {
        if (selectedTab == "progress") {
            progressSnapshot = loadProgressSnapshot()
        }
    }

    val previewText = when (selectedTab) {
        "schema" -> sqlScript
        "adhkar" -> adhkarPreview
        else -> progressSnapshot
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        AppCard(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("مستعرض قاعدة البيانات المحلية (SQLite)", style = MaterialTheme.typography.titleMedium, color = colors.accentPrimary)
                        Text("جداول منظمة للأذكار والتصنيفات والمصادر والتقدم اليومي", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = colors.textPrimary)
                    }
                }

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SqlTabButton("مخطط الجداول (DDL)", selectedTab == "schema") { selectedTab = "schema" }
                    SqlTabButton("جدول الأذكار", selectedTab == "adhkar") { selectedTab = "adhkar" }
                    SqlTabButton("جدول التقدم اليومي", selectedTab == "progress") { selectedTab = "progress" }
                    Button(
                        onClick = onDownloadSql,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberBadge),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تصدير adhkari_db.sql", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 200.dp, max = 360.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.bgSecondary)
                            .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                            .verticalScroll(rememberScrollState())
                            .horizontalScroll(rememberScrollState())
                            .padding(12.dp)
                    ) {
                        Text(
                            text = previewText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = colors.textPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SqlTabButton(text: String, selected: Boolean, onClick: () -> Unit) {
    val colors = LocalAdhkariColors.current
    Surface(
        color = if (selected) colors.accentPrimary else colors.bgCard,
        shape = RoundedCornerShape(10.dp),
        border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else colors.textPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        )
    }
}
