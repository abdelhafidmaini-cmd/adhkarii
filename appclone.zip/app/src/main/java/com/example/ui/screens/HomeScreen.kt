package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.model.PrayerKey
import com.example.ui.components.AppCard
import com.example.ui.components.CircularProgressRing
import com.example.ui.components.HeroGradientBox
import com.example.ui.theme.AmberStar
import com.example.ui.theme.IndigoEvening
import com.example.ui.theme.LocalAdhkariColors
import com.example.viewmodel.AdhkariUiState
import java.util.Calendar

@Composable
fun HomeScreen(
    uiState: AdhkariUiState,
    onOpenLocation: () -> Unit,
    onOpenCategory: (String) -> Unit,
    onOpenPostPrayer: (PrayerKey?) -> Unit,
    onOpenWorship: () -> Unit,
    onOpenMore: () -> Unit,
    onOpenPrayers: () -> Unit = {}
) {
    val colors = LocalAdhkariColors.current
    val nowCal = Calendar.getInstance().apply { timeInMillis = uiState.nowEpochMillis }
    val hijriDate = PrayerTimeCalculator.formatHijriLong(nowCal)
    val gregDate = PrayerTimeCalculator.formatGregorianLong(nowCal)
    val nextInfo = uiState.nextPrayerInfo

    val mStats = uiState.categoryStats("morning")
    val eStats = uiState.categoryStats("evening")
    val worshipScore = uiState.worshipDayScore(uiState.todayDateKey)
    val activeDays = uiState.activeCommitmentDays()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Date & City Pill
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = colors.goldAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "$hijriDate | $gregDate",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = colors.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(6.dp))
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(colors.accentLight)
                        .clickable(onClick = onOpenLocation)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("btn_home_location"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "تغيير الموقع",
                        tint = colors.accentPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = uiState.prefs.location.shortName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.accentPrimary
                    )
                }
            }
        }

        // 2. Next Prayer Hero Card
        HeroGradientBox(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "الصلاة القادمة",
                            fontSize = 12.sp,
                            color = Color(0xFFD1FAE5)
                        )
                        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = nextInfo.next.key.arabicName,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AmberStar
                            )
                            Text(
                                text = nextInfo.windowHint,
                                fontSize = 11.sp,
                                color = Color(0xCCD1FAE5)
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.14f))
                            .border(
                                1.dp,
                                if (uiState.prefs.adhan.enabled) AmberStar.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.15f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable(onClick = onOpenPrayers)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("btn_home_adhan_badge"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (uiState.prefs.adhan.enabled) "🔔 الأذان مفعّل" else "🔕 الأذان صامت",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.prefs.adhan.enabled) Color(0xFFFEF08A) else Color.White.copy(alpha = 0.8f)
                        )
                    }
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = nextInfo.next.timeStr,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color.Black.copy(alpha = 0.25f))
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("متبقي على الصلاة:", fontSize = 11.sp, color = Color(0xFFD1FAE5))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = PrayerTimeCalculator.formatCountdown(nextInfo.diffSeconds),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = AmberStar
                            )
                        }
                    }
                }

                // Mini Strip of Today's 5 Prayers
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.16f))
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PrayerKey.fiveObligatory.forEach { pKey ->
                        val entry = nextInfo.todayTimes.byKey(pKey)
                        val isNext = nextInfo.next.key == pKey
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isNext) Color(0x40FBBF24) else Color.Transparent)
                                .let {
                                    if (isNext) it.border(1.dp, AmberStar.copy(alpha = 0.45f), RoundedCornerShape(10.dp)) else it
                                }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = pKey.arabicName,
                                fontSize = 11.sp,
                                fontWeight = if (isNext) FontWeight.ExtraBold else FontWeight.Medium,
                                color = if (isNext) Color(0xFFFEF08A) else Color.White.copy(alpha = 0.85f)
                            )
                            Text(
                                text = entry.timeStr,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (isNext) Color(0xFFFEF08A) else Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        // 3. Morning & Evening Adhkar Status Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AdhkarTimeCard(
                title = "أذكار الصباح",
                completed = mStats.completed,
                total = mStats.total,
                percent = mStats.percent,
                icon = Icons.Default.WbSunny,
                iconBg = Color(0x26F59E0B),
                iconTint = Color(0xFFF59E0B),
                tag = "card_home_morning",
                modifier = Modifier.weight(1f),
                onClick = { onOpenCategory("morning") }
            )
            AdhkarTimeCard(
                title = "أذكار المساء",
                completed = eStats.completed,
                total = eStats.total,
                percent = eStats.percent,
                icon = Icons.Default.NightsStay,
                iconBg = Color(0x266366F1),
                iconTint = IndigoEvening,
                tag = "card_home_evening",
                modifier = Modifier.weight(1f),
                onClick = { onOpenCategory("evening") }
            )
        }

        // 4. Post-Prayer Adhkar Shortcut Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.accentLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🕌", fontSize = 18.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("أذكار بعد الصلاة المفروضة", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Text("مخصصة لكل صلاة مع تمييز الروايات الصحيحة", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { onOpenPostPrayer(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("btn_open_post_prayer")
                    ) {
                        Text("فتح الأذكار", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PrayerKey.fiveObligatory.forEach { pKey ->
                        val st = uiState.categoryStats("post_prayer", prayerKeyOverride = pKey)
                        val done = st.completed >= st.total && st.total > 0
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (done) colors.accentLight else Color.Transparent)
                                .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                                .clickable { onOpenPostPrayer(pKey) }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(pKey.arabicName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                            Text(
                                text = if (done) "مكتمل ✓" else "${st.completed}/${st.total}",
                                fontSize = 10.sp,
                                color = colors.accentPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 5. Daily Achievement & Worship Tracker Shortcut Card
        AppCard(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("card_home_worship"),
            onClick = onOpenWorship
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier.size(56.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressRing(
                            progress = worshipScore.totalPercent / 100f,
                            strokeWidth = 5.dp,
                            activeColor = colors.goldAccent,
                            modifier = Modifier.fillMaxSize()
                        )
                        Text(
                            text = "${worshipScore.totalPercent}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.textPrimary
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("متابعة العبادات وإنجاز اليوم 🔥", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                        Text(
                            text = "الصلوات (${worshipScore.prayersDone}/5) • الأذكار (${mStats.completed + eStats.completed}/${mStats.total + eStats.total}) • الرواتب والنوافل",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                        Text(
                            text = "أيام المحافظة على الذكر: $activeDays ${if (activeDays == 1) "يوم مبارك" else "أيام مباركة"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.goldAccent,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = onOpenWorship,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("السجل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 6. Quick Grid for Other Adhkar Categories
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("أقسام الأذكار والأدعية", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                Text(
                    text = "عرض الكل ←",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.accentPrimary,
                    modifier = Modifier
                        .clickable(onClick = onOpenMore)
                        .padding(4.dp)
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCategoryChip("🌙", "أذكار النوم", "12 ذكرا صحيحا", Modifier.weight(1f)) { onOpenCategory("sleep") }
                QuickCategoryChip("🌅", "أذكار الاستيقاظ", "3 أذكار صحيحة", Modifier.weight(1f)) { onOpenCategory("wakeup") }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCategoryChip("🏠", "أذكار المنزل", "3 أذكار صحيحة", Modifier.weight(1f)) { onOpenCategory("home") }
                QuickCategoryChip("🤲", "أدعية جامعة", "قرآنية ونبوية", Modifier.weight(1f)) { onOpenCategory("duas") }
            }
        }
    }
}

@Composable
private fun AdhkarTimeCard(
    title: String,
    completed: Int,
    total: Int,
    percent: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    iconTint: Color,
    tag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    val badgeText = when {
        completed == 0 -> "لم تبدأ بعد"
        completed >= total -> "تم إنجازها ✓"
        else -> "جاري ($percent%)"
    }

    AppCard(
        modifier = modifier.testTag(tag),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(colors.accentPrimary.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(badgeText, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = colors.accentPrimary)
                }
            }

            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = "$completed / $total",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.accentPrimary
                        )
                    }
                    Text("ذكراً موثقاً", fontSize = 11.sp, color = colors.textSecondary)
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (percent / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(999.dp)),
                    color = colors.accentPrimary,
                    trackColor = colors.textPrimary.copy(alpha = 0.08f)
                )
            }
        }
    }
}

@Composable
private fun QuickCategoryChip(
    emoji: String,
    title: String,
    sub: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    AppCard(modifier = modifier, onClick = onClick) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(colors.accentLight),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 16.sp)
            }
            Column {
                Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(sub, fontSize = 10.sp, color = colors.textSecondary, maxLines = 1)
            }
        }
    }
}
