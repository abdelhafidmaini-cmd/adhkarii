package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.seed.AuthenticAdhkarData
import com.example.ui.components.AppCard
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalAdhkariColors
import com.example.viewmodel.AdhkariUiState
import java.util.Calendar
import kotlin.math.roundToInt

@Composable
fun MoreScreen(
    uiState: AdhkariUiState,
    onSearchQueryChange: (String) -> Unit,
    onOpenCategory: (String) -> Unit,
    onOpenFreeTasbih: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    val query = uiState.nav.searchQuery.trim()
    val normQ = PrayerTimeCalculator.stripArabicTashkeel(query)

    val searchMatches = if (normQ.isBlank()) {
        emptyList()
    } else {
        AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter { item ->
            val haystack = PrayerTimeCalculator.stripArabicTashkeel(
                "${item.text} ${item.subCategory} ${item.bookName} ${item.hadithOrAyahNumber} ${item.narrationNotes}"
            )
            haystack.contains(normQ, ignoreCase = true)
        }
    }

    val todayMap = uiState.dailyProgress[uiState.todayDateKey].orEmpty()
    val completedTodayCount = todayMap.values.count { it > 0 }
    val lifetimeTasbihat = uiState.lifetimeTasbihat()
    val activeDays = uiState.activeCommitmentDays()

    val nowCal = Calendar.getInstance().apply { timeInMillis = uiState.nowEpochMillis }
    var activeInWeek = 0
    val last7Days = (6 downTo 0).map { i ->
        val dt = (nowCal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -i) }
        val dk = PrayerTimeCalculator.dateKeyOf(dt)
        val count = uiState.dailyProgress[dk]?.values?.count { it > 0 } ?: 0
        val isToday = i == 0
        if (count > 0 || isToday) activeInWeek++
        Triple(dt, count, isToday)
    }
    val weekRatePct = ((activeInWeek / 7.0) * 100.0).roundToInt().coerceAtMost(100)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Search Input Bar
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = uiState.nav.searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("ابحث في نص الذكر، اسم الكتاب، رقم الحديث، أو الفضل...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = colors.textSecondary) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح البحث", tint = colors.textSecondary)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_global_search")
                )

                if (query.isNotEmpty()) {
                    if (searchMatches.isEmpty()) {
                        Text(
                            text = "لم يتم العثور على ذكر مطابق لـ \"$query\"",
                            fontSize = 12.sp,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 360.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            searchMatches.forEach { item ->
                                val cat = AuthenticAdhkarData.CATEGORIES_META.firstOrNull { it.id == item.categoryId }
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(colors.bgSecondary)
                                        .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${cat?.title ?: ""} — ${item.subCategory}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.accentPrimary,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Button(
                                            onClick = { onOpenCategory(item.categoryId) },
                                            colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("فتح القسم", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text(
                                        text = item.text,
                                        fontFamily = AmiriFontFamily,
                                        fontSize = 15.sp,
                                        lineHeight = 26.sp,
                                        color = colors.textPrimary
                                    )
                                    Text(
                                        text = "المصدر: ${item.bookName} (${item.hadithOrAyahNumber}) — ${item.authenticityGrade}",
                                        fontSize = 11.sp,
                                        color = colors.textSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Standalone Free Electronic Tasbih Counter Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(colors.accentLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📿", fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("المسبحة الإلكترونية الحرة", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                        Text("عداد تسبيح مفتوح مع حفظ تلقائي وأهداف مخصصة", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                    }
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = onOpenFreeTasbih,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_open_free_tasbih")
                ) {
                    Text("فتح المسبحة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 3. Complete Categories Grid
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "جميع أبواب الأذكار والأدعية الصحيحة",
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            AuthenticAdhkarData.CATEGORIES_META.forEach { cat ->
                val st = uiState.categoryStats(cat.id)
                AppCard(
                    modifier = Modifier.fillMaxWidth().testTag("cat_row_${cat.id}"),
                    onClick = { onOpenCategory(cat.id) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(colors.accentLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(cat.emoji, fontSize = 18.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(cat.title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                Text(cat.desc, fontSize = 11.sp, color = colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text("${st.completed}/${st.total}", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = colors.accentPrimary)
                            }
                            Text("ذكر", fontSize = 10.sp, color = colors.textSecondary)
                        }
                    }
                }
            }
        }

        // 4. Achievement Log & Weekly Statistics Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("سجل الإنجاز والإحصائيات التشجيعية", style = MaterialTheme.typography.titleSmall, color = colors.accentPrimary)
                        Text("أحب الأعمال إلى الله أدومها وإن قل", fontSize = 11.sp, color = colors.textSecondary)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(colors.accentLight)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$activeDays ${if (activeDays == 1) "يوم التزام" else "أيام التزام"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.accentPrimary
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatKpiBox(completedTodayCount.toString(), "أذكار اليوم", Modifier.weight(1f))
                    StatKpiBox(lifetimeTasbihat.toString(), "مجموع التسبيحات", Modifier.weight(1f))
                    StatKpiBox("$weekRatePct%", "مؤشر الأسبوع", Modifier.weight(1f))
                }

                Text("سجل الأيام السبعة الأخيرة:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    last7Days.forEach { (dt, count, isToday) ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (count > 0) colors.accentLight else Color.Transparent)
                                .border(
                                    width = if (isToday) 1.5.dp else 1.dp,
                                    color = if (isToday) colors.accentPrimary else colors.borderColor,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = PrayerTimeCalculator.ARABIC_WEEKDAYS_SHORT[dt.get(Calendar.DAY_OF_WEEK)] ?: "",
                                fontSize = 10.sp,
                                color = colors.textSecondary
                            )
                            Text(
                                text = when {
                                    count > 0 -> "✓"
                                    isToday -> "اليوم"
                                    else -> "•"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = colors.accentPrimary,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                            Text(dt.get(Calendar.DAY_OF_MONTH).toString(), fontSize = 10.sp, color = colors.textSecondary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatKpiBox(value: String, label: String, modifier: Modifier = Modifier) {
    val colors = LocalAdhkariColors.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(colors.bgSecondary)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = colors.accentPrimary)
        Text(label, fontSize = 10.sp, color = colors.textSecondary)
    }
}
