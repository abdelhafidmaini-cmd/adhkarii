package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.model.AdhanVoice
import com.example.data.model.AsrJuristic
import com.example.data.model.CalculationMethod
import com.example.data.model.PrayerKey
import com.example.data.model.PrayerOffsets
import com.example.ui.components.AppCard
import com.example.ui.components.HeroGradientBox
import com.example.ui.theme.AmberStar
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalAdhkariColors
import com.example.viewmodel.AdhkariUiState
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrayersScreen(
    uiState: AdhkariUiState,
    onOpenLocation: () -> Unit,
    onOpenPostPrayer: (PrayerKey) -> Unit,
    onUpdateCalculation: (CalculationMethod, AsrJuristic, PrayerOffsets) -> Unit,
    onResetOffsets: () -> Unit,
    onToggleAdhanEnabled: (Boolean) -> Unit = {},
    onSelectAdhanVoice: (AdhanVoice) -> Unit = {},
    onToggleAlarmChannel: (Boolean) -> Unit = {},
    onTogglePrayerAdhan: (PrayerKey) -> Unit = {},
    onPickCustomAdhanAudio: () -> Unit = {},
    onPreviewAdhan: () -> Unit = {},
    onStopAdhan: () -> Unit = {},
    onPinPrayerWidget: () -> Unit = {},
    onPinCompactWidget: () -> Unit = {}
) {
    val colors = LocalAdhkariColors.current
    val loc = uiState.prefs.location
    val adhan = uiState.prefs.adhan
    val nowCal = Calendar.getInstance().apply { timeInMillis = uiState.nowEpochMillis }
    val hijriLong = PrayerTimeCalculator.formatHijriLong(nowCal)
    val gregLong = PrayerTimeCalculator.formatGregorianLong(nowCal)
    val nextInfo = uiState.nextPrayerInfo

    var methodExpanded by remember { mutableStateOf(false) }
    var asrExpanded by remember { mutableStateOf(false) }
    var voiceExpanded by remember { mutableStateOf(false) }
    var showAdhanSunnah by remember { mutableStateOf(false) }

    val prayerIcons = mapOf(
        PrayerKey.FAJR to "🌙",
        PrayerKey.SUNRISE to "🌅",
        PrayerKey.DHUHR to "☀️",
        PrayerKey.ASR to "🌤️",
        PrayerKey.MAGHRIB to "🌇",
        PrayerKey.ISHA to "🌌"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Location & Method Hero Card
        HeroGradientBox(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("مواقيت الصلاة المحلية (دون إنترنت)", fontSize = 11.sp, color = Color(0xFFD1FAE5))
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = AmberStar, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "${loc.cityName} — ${loc.country}",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                        Text(
                            text = "طريقة الحساب: ${loc.method.arabicName}",
                            fontSize = 11.sp,
                            color = Color(0xD9D1FAE5),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = onOpenLocation,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.16f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("btn_prayers_change_loc")
                    ) {
                        Text("تغيير الموقع", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.16f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("$hijriLong | $gregLong", fontSize = 11.sp, color = Color.White.copy(alpha = 0.9f), modifier = Modifier.weight(1f))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = String.format(Locale.US, "%.2f°N, %.2f°E", loc.lat, loc.lng),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFFFDE68A)
                        )
                    }
                }
            }
        }

        // 2. Prayer Times List Card (with per-prayer Adhan Sound Bell)
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(4.dp)) {
                PrayerKey.allSix.forEachIndexed { idx, pKey ->
                    val entry = nextInfo.todayTimes.byKey(pKey)
                    val isNext = nextInfo.next.key == pKey
                    val isAdhanOn = adhan.isPrayerEnabled(pKey)
                    if (isNext) {
                        HeroGradientBox(
                            cornerRadius = 14.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                        ) {
                            PrayerRowContent(
                                emoji = prayerIcons[pKey] ?: "🕌",
                                name = pKey.arabicName,
                                timeStr = entry.timeStr,
                                isNext = true,
                                isSunrise = pKey == PrayerKey.SUNRISE,
                                isAdhanOn = isAdhanOn,
                                onToggleAdhan = { onTogglePrayerAdhan(pKey) },
                                onOpenAdhkar = { onOpenPostPrayer(pKey) }
                            )
                        }
                    } else {
                        PrayerRowContent(
                            emoji = prayerIcons[pKey] ?: "🕌",
                            name = pKey.arabicName,
                            timeStr = entry.timeStr,
                            isNext = false,
                            isSunrise = pKey == PrayerKey.SUNRISE,
                            isAdhanOn = isAdhanOn,
                            onToggleAdhan = { onTogglePrayerAdhan(pKey) },
                            onOpenAdhkar = { onOpenPostPrayer(pKey) }
                        )
                    }
                    if (idx < PrayerKey.allSix.lastIndex && !isNext) {
                        HorizontalDivider(color = colors.borderColor)
                    }
                }
            }
        }

        // 3. Automatic Adhan Audio & Settings Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🕌 الأذان التلقائي عند دخول الوقت",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.accentPrimary
                        )
                        Text(
                            text = "يرفع الهاتف صوت الأذان تلقائياً عند دخول كل صلاة",
                            fontSize = 11.sp,
                            color = colors.textSecondary
                        )
                    }
                    Switch(
                        checked = adhan.enabled,
                        onCheckedChange = onToggleAdhanEnabled,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = colors.accentPrimary),
                        modifier = Modifier.testTag("switch_adhan_enabled")
                    )
                }

                // Voice Picker
                ExposedDropdownMenuBox(expanded = voiceExpanded, onExpandedChange = { voiceExpanded = it }) {
                    val voiceDisplay = if (adhan.voice == AdhanVoice.CUSTOM && adhan.customAudioName.isNotBlank()) {
                        "${adhan.voice.arabicName} (${adhan.customAudioName})"
                    } else {
                        adhan.voice.arabicName
                    }
                    OutlinedTextField(
                        value = voiceDisplay,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("صوت الأذان والمؤذن") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = voiceExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = voiceExpanded, onDismissRequest = { voiceExpanded = false }) {
                        AdhanVoice.entries.forEach { voice ->
                            DropdownMenuItem(
                                text = { Text(voice.arabicName, fontSize = 12.sp) },
                                onClick = {
                                    onSelectAdhanVoice(voice)
                                    voiceExpanded = false
                                }
                            )
                        }
                    }
                }

                // Play/Stop Preview + Custom File Picker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val playing = uiState.adhanPlayback.isPlaying
                    Button(
                        onClick = { if (playing) onStopAdhan() else onPreviewAdhan() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (playing) Color(0xFFDC2626) else colors.accentPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_preview_adhan")
                    ) {
                        Icon(
                            imageVector = if (playing) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (playing) "إيقاف الأذان" else "تجربة صوت الأذان",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onPickCustomAdhanAudio,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_pick_custom_adhan")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AudioFile,
                            contentDescription = null,
                            tint = colors.accentPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "ملف صوتي مخصص",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.accentPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Alarm Stream toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleAlarmChannel(!adhan.useAlarmChannel) },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("استخدام قناة صوت المنبّه", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                        Text("يسمح برفع صوت الأذان بمستوى صوت المنبه حتى عند خفض الوسائط", fontSize = 11.sp, color = colors.textSecondary)
                    }
                    Switch(
                        checked = adhan.useAlarmChannel,
                        onCheckedChange = onToggleAlarmChannel,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = colors.accentPrimary)
                    )
                }

                HorizontalDivider(color = colors.borderColor)

                // Sunnah of Adhan collapsible section
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAdhanSunnah = !showAdhanSunnah }
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📖 سنن إجابة المؤذن والدعاء بعد الأذان",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.goldAccent
                    )
                    Icon(
                        imageVector = if (showAdhanSunnah) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = colors.textSecondary
                    )
                }

                AnimatedVisibility(visible = showAdhanSunnah) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.bgSecondary)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "١) متابعة المؤذن في كل ما يقول إلا في «حي على الصلاة، حي على الفلاح» فيقول: «لا حول ولا قوة إلا بالله». (صحيح مسلم 385)",
                            fontSize = 11.sp,
                            color = colors.textPrimary,
                            lineHeight = 18.sp
                        )
                        Text(
                            text = "٢) الصلاة على النبي ﷺ ثم قول: «اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ، وَالصَّلَاةِ الْقَائِمَةِ، آتِ مُحَمَّدًا الْوَسِيلَةَ وَالْفَضِيلَةَ، وَابْعَثْهُ مَقَامًا مَحْمُودًا الَّذِي وَعَدْتَهُ». (صحيح البخاري 614)",
                            fontFamily = AmiriFontFamily,
                            fontSize = 14.sp,
                            color = colors.accentPrimary,
                            lineHeight = 24.sp
                        )
                    }
                }
            }
        }

        // 4. Home Screen Widgets Showcase & 1-Tap Pinning Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Widgets, contentDescription = null, tint = colors.accentPrimary, modifier = Modifier.size(20.dp))
                    Column {
                        Text(
                            text = "ودجيت الشاشة الرئيسية (Widgets)",
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.accentPrimary
                        )
                        Text(
                            text = "تابع مواقيت الصلاة والعد التنازلي ونسبة الأذكار من شاشة هاتفك الرئيسية",
                            fontSize = 11.sp,
                            color = colors.textSecondary
                        )
                    }
                }

                // Live Preview of the 4x2 Emerald Widget
                HeroGradientBox(cornerRadius = 18.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🌙 أذكاري", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFEF08A))
                            Text("📍 ${loc.shortName}", fontSize = 10.sp, color = Color(0xFFD1FAE5))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("الصلاة القادمة", fontSize = 10.sp, color = Color(0xFFA7F3D0))
                                Text(nextInfo.next.key.arabicName, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = AmberStar)
                            }
                            Text(
                                text = nextInfo.next.timeStr,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                color = Color.White
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            PrayerKey.fiveObligatory.forEach { pk ->
                                val isNext = pk == nextInfo.next.key
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isNext) Color(0x42FBBF24) else Color.White.copy(alpha = 0.14f))
                                        .padding(vertical = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(pk.arabicName, fontSize = 9.sp, color = if (isNext) Color(0xFFFEF08A) else Color(0xFFD1FAE5))
                                    Text(
                                        nextInfo.todayTimes.byKey(pk).timeStr,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isNext) Color(0xFFFEF08A) else Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onPinPrayerWidget,
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_pin_prayer_widget")
                    ) {
                        Text("📌 إضافة ودجيت المواقيت", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = onPinCompactWidget,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_pin_compact_widget")
                    ) {
                        Text("📌 الودجيت المصغّر", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = colors.accentPrimary, maxLines = 1)
                    }
                }
            }
        }

        // 5. Calculation Method & Manual Minute Offsets Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ضبط طريقة الحساب وفروق الدقائق اليدوية",
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.accentPrimary
                )

                ExposedDropdownMenuBox(expanded = methodExpanded, onExpandedChange = { methodExpanded = it }) {
                    OutlinedTextField(
                        value = loc.method.arabicName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("هيئة / طريقة الحساب") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = methodExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = methodExpanded, onDismissRequest = { methodExpanded = false }) {
                        CalculationMethod.entries.forEach { method ->
                            DropdownMenuItem(
                                text = { Text(method.arabicName, fontSize = 12.sp) },
                                onClick = {
                                    onUpdateCalculation(method, loc.asrJuristic, loc.offsets)
                                    methodExpanded = false
                                }
                            )
                        }
                    }
                }

                ExposedDropdownMenuBox(expanded = asrExpanded, onExpandedChange = { asrExpanded = it }) {
                    OutlinedTextField(
                        value = loc.asrJuristic.arabicName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("مذهب حساب وقت العصر") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = asrExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(expanded = asrExpanded, onDismissRequest = { asrExpanded = false }) {
                        AsrJuristic.entries.forEach { asr ->
                            DropdownMenuItem(
                                text = { Text(asr.arabicName, fontSize = 12.sp) },
                                onClick = {
                                    onUpdateCalculation(loc.method, asr, loc.offsets)
                                    asrExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تعديل فروق الدقائق يدوياً (دقيقة):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                    Text(
                        text = "تصفير الفروق",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.accentPrimary,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier.clickable(onClick = onResetOffsets)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OffsetField("الفجر", loc.offsets.fajr, Modifier.weight(1f)) { v ->
                        onUpdateCalculation(loc.method, loc.asrJuristic, loc.offsets.copy(fajr = v))
                    }
                    OffsetField("الشروق", loc.offsets.sunrise, Modifier.weight(1f)) { v ->
                        onUpdateCalculation(loc.method, loc.asrJuristic, loc.offsets.copy(sunrise = v))
                    }
                    OffsetField("الظهر", loc.offsets.dhuhr, Modifier.weight(1f)) { v ->
                        onUpdateCalculation(loc.method, loc.asrJuristic, loc.offsets.copy(dhuhr = v))
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OffsetField("العصر", loc.offsets.asr, Modifier.weight(1f)) { v ->
                        onUpdateCalculation(loc.method, loc.asrJuristic, loc.offsets.copy(asr = v))
                    }
                    OffsetField("المغرب", loc.offsets.maghrib, Modifier.weight(1f)) { v ->
                        onUpdateCalculation(loc.method, loc.asrJuristic, loc.offsets.copy(maghrib = v))
                    }
                    OffsetField("العشاء", loc.offsets.isha, Modifier.weight(1f)) { v ->
                        onUpdateCalculation(loc.method, loc.asrJuristic, loc.offsets.copy(isha = v))
                    }
                }
            }
        }
    }
}

@Composable
private fun PrayerRowContent(
    emoji: String,
    name: String,
    timeStr: String,
    isNext: Boolean,
    isSunrise: Boolean,
    isAdhanOn: Boolean,
    onToggleAdhan: () -> Unit,
    onOpenAdhkar: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(emoji, fontSize = 18.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isNext) Color.White else colors.textPrimary
                )
                if (isNext) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0x40FBBF24))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text("القادمة", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFEF08A))
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = timeStr,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = if (isNext) Color.White else colors.textPrimary
            )
            if (!isSunrise) {
                IconButton(
                    onClick = onToggleAdhan,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = if (isAdhanOn) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                        contentDescription = if (isAdhanOn) "كتم أذان $name" else "تفعيل أذان $name",
                        tint = when {
                            isNext && isAdhanOn -> AmberStar
                            isNext -> Color.White.copy(alpha = 0.55f)
                            isAdhanOn -> colors.accentPrimary
                            else -> colors.textSecondary.copy(alpha = 0.5f)
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isNext) Color.White.copy(alpha = 0.20f) else Color.Transparent)
                        .let {
                            if (!isNext) it.border(1.dp, colors.borderColor, RoundedCornerShape(10.dp)) else it
                        }
                        .clickable(onClick = onOpenAdhkar)
                        .padding(horizontal = 9.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "أذكارها",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isNext) Color.White else colors.textPrimary
                    )
                }
            } else {
                Text("وقت الشروق", fontSize = 11.sp, color = colors.textSecondary, modifier = Modifier.padding(horizontal = 6.dp))
            }
        }
    }
}

@Composable
private fun OffsetField(
    label: String,
    currentValue: Int,
    modifier: Modifier = Modifier,
    onValueChanged: (Int) -> Unit
) {
    val colors = LocalAdhkariColors.current
    var text by remember(currentValue) { mutableStateOf(currentValue.toString()) }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
        OutlinedTextField(
            value = text,
            onValueChange = { raw ->
                text = raw
                val parsed = raw.toIntOrNull()
                if (parsed != null && parsed in -30..30) {
                    onValueChanged(parsed)
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            textStyle = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
