package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DhikrItem
import com.example.data.model.PrayerKey
import com.example.data.model.TasbihVariant
import com.example.data.seed.AuthenticAdhkarData
import com.example.ui.components.AppCard
import com.example.ui.components.CircularProgressRing
import com.example.ui.components.HeroGradientBox
import com.example.ui.theme.AmberBadge
import com.example.ui.theme.AmberStar
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalAdhkariColors
import com.example.viewmodel.AdhkariUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    uiState: AdhkariUiState,
    onSelectPostPrayerTab: (PrayerKey) -> Unit,
    onChangeTasbihVariant: (TasbihVariant) -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onRequestResetSingle: () -> Unit,
    onNavigateItem: (Int) -> Unit,
    onOpenSourceDetail: (DhikrItem) -> Unit
) {
    val colors = LocalAdhkariColors.current
    val catId = uiState.nav.currentCategory
    val catMeta = AuthenticAdhkarData.CATEGORIES_META.firstOrNull { it.id == catId }
        ?: AuthenticAdhkarData.CATEGORIES_META.first()
    val adhkarList = uiState.activeAdhkarForCategory(catId)
    val stats = uiState.categoryStats(catId)

    val safeIndex = if (adhkarList.isEmpty()) 0 else uiState.nav.sequentialIndex.coerceIn(0, adhkarList.lastIndex)
    val item = adhkarList.getOrNull(safeIndex)

    var variantExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Compact Category Header Banner
        HeroGradientBox(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = catMeta.title,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = "${stats.completed} / ${stats.total}",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AmberStar
                            )
                        }
                        Text("مكتمل", fontSize = 12.sp, color = Color(0xFFD1FAE5))
                    }
                }

                // Post-Prayer Controls (5 Prayers + Narration Variant Selector)
                if (catId == "post_prayer") {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.16f))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.22f))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        PrayerKey.fiveObligatory.forEach { pKey ->
                            val isSelected = uiState.prefs.currentPostPrayerTab == pKey
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(if (isSelected) Color.White else Color.Transparent)
                                    .clickable { onSelectPostPrayerTab(pKey) }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = pKey.arabicName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Bold,
                                    color = if (isSelected) Color(0xFF064E3B) else Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }
                    }

                    ExposedDropdownMenuBox(
                        expanded = variantExpanded,
                        onExpandedChange = { variantExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = uiState.prefs.tasbihVariant.label,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = variantExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedTextColor = Color(0xFF064E3B),
                                unfocusedTextColor = Color(0xFF064E3B),
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = variantExpanded,
                            onDismissRequest = { variantExpanded = false }
                        ) {
                            TasbihVariant.entries.forEach { variant ->
                                DropdownMenuItem(
                                    text = { Text(variant.label, fontSize = 12.sp) },
                                    onClick = {
                                        onChangeTasbihVariant(variant)
                                        variantExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Active Dhikr Card
        if (item != null) {
            val currentCount = uiState.currentCountFor(item)
            val targetCount = item.targetCount
            val pct = if (targetCount > 0) ((currentCount.toFloat() / targetCount) * 100f).toInt().coerceIn(0, 100) else 100
            val fontSizeSp = uiState.prefs.fontSize.sp
            val lineHeightSp = (uiState.prefs.fontSize * 1.75f).sp

            AppCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Navigation between Dhikr items in category
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(colors.accentLight)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = item.subCategory,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.accentPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { onNavigateItem(-1) },
                                modifier = Modifier.size(34.dp).testTag("btn_prev_dhikr")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = "الذكر السابق",
                                    tint = colors.accentPrimary
                                )
                            }
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(
                                    text = "${safeIndex + 1}/${adhkarList.size}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textSecondary
                                )
                            }
                            IconButton(
                                onClick = { onNavigateItem(1) },
                                modifier = Modifier.size(34.dp).testTag("btn_next_dhikr")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                    contentDescription = "الذكر التالي",
                                    tint = colors.accentPrimary
                                )
                            }
                        }
                    }

                    // Grade Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(AmberBadge.copy(alpha = 0.14f))
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = item.authenticityGrade,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (colors.isDark) AmberStar else AmberBadge
                        )
                    }

                    HorizontalDivider(color = colors.borderColor)

                    // Dhikr Text (Amiri Font)
                    Text(
                        text = item.text,
                        fontFamily = AmiriFontFamily,
                        fontSize = fontSizeSp,
                        lineHeight = lineHeightSp,
                        color = colors.textPrimary,
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider(color = colors.borderColor)

                    // Large One-Handed Interactive Counter Section
                    if (!uiState.prefs.readOnlyMode) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(148.dp)
                                    .clip(CircleShape)
                                    .clickable(onClick = onIncrement)
                                    .testTag("ring_seq_counter"),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressRing(
                                    progress = if (targetCount > 0) currentCount.toFloat() / targetCount else 1f,
                                    strokeWidth = 10.dp,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = currentCount.toString(),
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = colors.accentPrimary
                                    )
                                    Text(
                                        text = "/ $targetCount ${if (targetCount == 1) "مرة" else "مرات"}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textSecondary
                                    )
                                    Text(
                                        text = "$pct% من العدد المطلوب",
                                        fontSize = 10.sp,
                                        color = colors.textSecondary
                                    )
                                }
                            }

                            val bigBtnText = when {
                                currentCount >= targetCount && safeIndex + 1 < adhkarList.size ->
                                    "اكتمل الذكر ✓ — اضغط للذكر التالي"
                                currentCount >= targetCount ->
                                    "اكتمل الذكر ✓ — تم إتمام القسم"
                                else -> "اضغط للتسبيح والزيادة (+1)"
                            }

                            Button(
                                onClick = onIncrement,
                                colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("btn_seq_big_tap")
                            ) {
                                Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(bigBtnText, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onDecrement,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f).testTag("btn_seq_undo")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = null, modifier = Modifier.size(16.dp), tint = colors.textPrimary)
                                    Spacer(Modifier.width(6.dp))
                                    Text("تراجع (-1)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                                }
                                OutlinedButton(
                                    onClick = onRequestResetSingle,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f).testTag("btn_seq_reset")
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = colors.textPrimary)
                                    Spacer(Modifier.width(6.dp))
                                    Text("إعادة ضبط", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                                }
                            }
                        }
                    }

                    // Source & Takhrij Box at the bottom
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(colors.bgSecondary)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "المصدر: ${item.bookName} — ${item.hadithOrAyahNumber}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.accentPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "تفاصيل الرواية والمصدر",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.accentPrimary,
                                textDecoration = TextDecoration.Underline,
                                modifier = Modifier
                                    .clickable { onOpenSourceDetail(item) }
                                    .testTag("btn_open_source_detail")
                            )
                        }
                        Text(
                            text = item.narrationNotes,
                            fontSize = 11.sp,
                            lineHeight = 18.sp,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        }
    }
}
