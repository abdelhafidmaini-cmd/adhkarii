package com.example.ui.screens

import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlarmConfig
import com.example.data.model.ThemeMode
import com.example.ui.components.AppCard
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.LocalAdhkariColors
import com.example.viewmodel.AdhkariUiState

@Composable
fun SettingsScreen(
    uiState: AdhkariUiState,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetFontSize: (Int) -> Unit,
    onToggleVibration: (Boolean) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleAutoAdvance: (Boolean) -> Unit,
    onToggleReadOnly: (Boolean) -> Unit,
    onTestNotification: () -> Unit,
    onToggleAlarm: (AlarmConfig, Boolean) -> Unit,
    onUpdateAlarmTime: (AlarmConfig, String) -> Unit,
    onOpenSqlInspector: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onPreviewAdhan: () -> Unit = {},
    onStopAdhan: () -> Unit = {},
    onPinPrayerWidget: () -> Unit = {}
) {
    val colors = LocalAdhkariColors.current
    val context = LocalContext.current
    val fs = uiState.prefs.fontSize
    val fsDesc = when {
        fs <= 20 -> "صغير"
        fs <= 24 -> "متوسط"
        fs <= 28 -> "كبير"
        else -> "كبير جداً"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Theme & Font Appearance Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("🎨 المظهر والخطوط", style = MaterialTheme.typography.titleSmall, color = colors.accentPrimary)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("وضع الألوان:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            ThemeMode.LIGHT to "فاتح عاجي",
                            ThemeMode.DARK to "داكن AMOLED",
                            ThemeMode.AUTO to "تلقائي"
                        ).forEach { (mode, label) ->
                            val selected = uiState.prefs.themeMode == mode
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(if (selected) colors.accentPrimary else Color.Transparent)
                                    .clickable { onSetThemeMode(mode) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .testTag("theme_btn_${mode.key}")
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected) Color.White else colors.textPrimary
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = colors.borderColor)

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("حجم خط الأذكار والقرآن (خط أميري):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                        Text("$fsDesc (${fs}sp)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.accentPrimary)
                    }
                    Slider(
                        value = fs.toFloat(),
                        onValueChange = { onSetFontSize(it.toInt()) },
                        valueRange = 18f..32f,
                        steps = 6,
                        colors = SliderDefaults.colors(
                            thumbColor = colors.accentPrimary,
                            activeTrackColor = colors.accentPrimary
                        )
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.bgSecondary)
                            .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "﴿ألا بذكر الله تطمئن القلوب﴾",
                            fontFamily = AmiriFontFamily,
                            fontSize = fs.sp,
                            lineHeight = (fs * 1.65f).sp,
                            color = colors.textPrimary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // 2. Sound & Vibration Feedback Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🔊 الصوت والاهتزاز والعداد", style = MaterialTheme.typography.titleSmall, color = colors.accentPrimary)

                SettingSwitchRow(
                    title = "اهتزاز خفيف عند التسبيح وعند إكمال الذكر",
                    sub = "يستخدم محرك اهتزاز أندرويد (Vibration)",
                    checked = uiState.prefs.vibrationEnabled,
                    onCheckedChange = onToggleVibration
                )
                HorizontalDivider(color = colors.borderColor)
                SettingSwitchRow(
                    title = "صوت نقرة هادئ عند الضغط على العداد",
                    sub = "لا يصدر أي صوت إلا بعد تفعيلك وإذنك",
                    checked = uiState.prefs.soundEnabled,
                    onCheckedChange = onToggleSound
                )
                HorizontalDivider(color = colors.borderColor)
                SettingSwitchRow(
                    title = "الانتقال التلقائي للذكر التالي عند إكمال العدد",
                    sub = "في وضع القراءة المتتابعة والعداد الكبير",
                    checked = uiState.prefs.autoAdvance,
                    onCheckedChange = onToggleAutoAdvance
                )
                HorizontalDivider(color = colors.borderColor)
                SettingSwitchRow(
                    title = "وضع القراءة الهادئة (إخفاء العداد)",
                    sub = "عرض نصوص الأذكار والتخريج فقط دون أزرار عدّ",
                    checked = uiState.prefs.readOnlyMode,
                    onCheckedChange = onToggleReadOnly
                )
            }
        }

        // 3. Notifications & Alarms Schedule Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🔔 التنبيهات وجدولة المنبهات", style = MaterialTheme.typography.titleSmall, color = colors.accentPrimary)
                    Button(
                        onClick = onTestNotification,
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_test_notification")
                    ) {
                        Text("فحص الإذن وتجربة التنبيه", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(
                    text = "تعمل التنبيهات عبر Android AlarmManager مع حفظ الجدولة بعد إعادة تشغيل الهاتف.",
                    fontSize = 11.sp,
                    color = colors.textSecondary
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val isAdhanPlaying = uiState.adhanPlayback.isPlaying
                    OutlinedButton(
                        onClick = { if (isAdhanPlaying) onStopAdhan() else onPreviewAdhan() },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (isAdhanPlaying) "⏹ إيقاف الأذان" else "🕌 تجربة صوت الأذان",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.accentPrimary
                        )
                    }
                    OutlinedButton(
                        onClick = onPinPrayerWidget,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "📌 إضافة ودجيت الشاشة",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.accentPrimary
                        )
                    }
                }

                uiState.alarms.forEachIndexed { idx, alarm ->
                    AlarmConfigRow(
                        alarm = alarm,
                        onToggle = { onToggleAlarm(alarm, it) },
                        onTimeChanged = { onUpdateAlarmTime(alarm, it) }
                    )
                    if (idx < uiState.alarms.lastIndex) {
                        HorizontalDivider(color = colors.borderColor)
                    }
                }
            }
        }

        // 4. Backup & Restore & SQLite Inspector Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("☁️ النسخ الاحتياطي واستعادة البيانات", style = MaterialTheme.typography.titleSmall, color = colors.accentPrimary)
                Text(
                    text = "بياناتك وتقدمك اليومي وإعداداتك محفوظة محلياً بالكامل في SQLite دون أي خادم خارجي. يمكنك تصدير نسخة احتياطية أو استعادتها في أي وقت:",
                    fontSize = 12.sp,
                    color = colors.textSecondary
                )
                OutlinedButton(
                    onClick = onOpenSqlInspector,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_open_sql_inspector")
                ) {
                    Icon(Icons.Default.Storage, contentDescription = null, tint = colors.accentPrimary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("قاعدة البيانات المحلية (SQLite)", fontWeight = FontWeight.Bold, color = colors.accentPrimary)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onExportBackup,
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accentPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("btn_export_backup")
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("تصدير نسخة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onImportBackup,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("btn_import_backup")
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, tint = colors.textPrimary, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("استعادة من ملف", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                    }
                }
            }
        }

        // 5. Methodology & Authentic Sources Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🛡️ منهجية التحقيق والمصادر المعتمدة", style = MaterialTheme.typography.titleSmall, color = colors.accentPrimary)
                Text(
                    text = "تم بناء قاعدة بيانات تطبيق «أذكاري» بالاقتصار الصارم على آيات القرآن الكريم والأحاديث النبوية الثابتة في صحيح البخاري وصحيح مسلم، وما صحّ إسناده في السنن الأربع (أبي داود، الترمذي، النسائي، ابن ماجه) ومسند أحمد، مع مراجعة التحقيق عبر الموسوعة الحديثية واستبعاد الأحاديث الضعيفة والموضوعة، وعدم خلط الروايات الصحيحة عند تعدد صيغ التسبيح.",
                    fontSize = 12.sp,
                    lineHeight = 20.sp,
                    color = colors.textSecondary
                )

                val refs = listOf(
                    "الموسوعة الحديثية - الدرر السنية ↗" to "https://dorar.net/hadith",
                    "تحقيق أذكار الصباح والمساء ↗" to "https://islamqa.info/ar/answers/217496",
                    "صحيح أذكار بعد الصلاة ↗" to "https://www.alqayim.org/ar/fatwa/3119/61",
                    "صحيح أذكار النوم ↗" to "https://www.alqayim.org/ar/fatwa/3182/61"
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    refs.chunked(2).forEach { pair ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            pair.forEach { (title, url) ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                                        .clickable {
                                            try {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                            } catch (_: Throwable) {
                                            }
                                        }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = colors.accentPrimary, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    sub: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = LocalAdhkariColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            Text(sub, fontSize = 11.sp, color = colors.textSecondary)
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = colors.accentPrimary)
        )
    }
}

@Composable
private fun AlarmConfigRow(
    alarm: AlarmConfig,
    onToggle: (Boolean) -> Unit,
    onTimeChanged: (String) -> Unit
) {
    val colors = LocalAdhkariColors.current
    val context = LocalContext.current
    var offsetText by remember(alarm.timeValue) { mutableStateOf(alarm.timeValue) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(alarm.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            Text(alarm.description, fontSize = 11.sp, color = colors.textSecondary)
        }
        Spacer(Modifier.width(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (alarm.alarmType == "fixed_time") {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, colors.borderColor, RoundedCornerShape(8.dp))
                        .clickable {
                            val parts = alarm.timeValue.split(":")
                            val hr = parts.getOrNull(0)?.toIntOrNull() ?: 6
                            val min = parts.getOrNull(1)?.toIntOrNull() ?: 30
                            TimePickerDialog(
                                context,
                                { _, h, m ->
                                    onTimeChanged(String.format(java.util.Locale.US, "%02d:%02d", h, m))
                                },
                                hr,
                                min,
                                true
                            ).show()
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = alarm.timeValue,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            } else if (alarm.id != "alarm_prayer_entry") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = offsetText,
                        onValueChange = { raw ->
                            offsetText = raw
                            val v = raw.toIntOrNull()
                            if (v != null && v in 1..60) {
                                onTimeChanged(v.toString())
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.width(60.dp)
                    )
                    Text("د", fontSize = 11.sp, color = colors.textSecondary)
                }
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.accentPrimary.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("عند الأذان", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = colors.accentPrimary)
                }
            }

            Switch(
                checked = alarm.enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = colors.accentPrimary)
            )
        }
    }
}
