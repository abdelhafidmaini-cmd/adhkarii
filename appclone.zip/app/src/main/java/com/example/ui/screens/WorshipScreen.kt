package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.WbCloudy
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.model.PrayerKey
import com.example.data.model.WorshipSubTab
import com.example.data.seed.AuthenticAdhkarData
import com.example.ui.components.AppCard
import com.example.ui.components.CircularProgressRing
import com.example.ui.theme.LocalAdhkariColors
import com.example.viewmodel.AdhkariUiState
import java.util.Calendar

@Composable
fun WorshipScreen(
    uiState: AdhkariUiState,
    onSelectSubTab: (WorshipSubTab) -> Unit,
    onSelectDate: (String) -> Unit,
    onTogglePrayer: (String, PrayerKey) -> Unit,
    onQuickCompleteAdhkar: (String, String) -> Unit,
    onOpenAdhkarCategory: (String) -> Unit,
    onToggleQuran: (String) -> Unit,
    onToggleNawafil: (String, String) -> Unit,
    onToggleRawatib: (String, String) -> Unit,
    onToggleCustom: (String, String) -> Unit,
    onDeleteCustomDeed: (String) -> Unit,
    onOpenAddCustomDeed: () -> Unit,
    onToggleExcuse: (String, Boolean) -> Unit,
    onOpenWeightsEditor: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    val subTab = uiState.nav.worshipSubTab

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Sub-Tabs: السجل | الإحصائيات
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.bgPrimary)
        ) {
            WorshipTabHeaderButton(
                title = "السجل",
                selected = subTab == WorshipSubTab.TRACK,
                tag = "tab_worship_track",
                modifier = Modifier.weight(1f),
                onClick = { onSelectSubTab(WorshipSubTab.TRACK) }
            )
            WorshipTabHeaderButton(
                title = "الإحصائيات",
                selected = subTab == WorshipSubTab.STATS,
                tag = "tab_worship_stats",
                modifier = Modifier.weight(1f),
                onClick = { onSelectSubTab(WorshipSubTab.STATS) }
            )
        }
        HorizontalDivider(color = colors.borderColor)

        if (subTab == WorshipSubTab.TRACK) {
            WorshipTrackPane(
                uiState = uiState,
                onSelectDate = onSelectDate,
                onTogglePrayer = onTogglePrayer,
                onQuickCompleteAdhkar = onQuickCompleteAdhkar,
                onOpenAdhkarCategory = onOpenAdhkarCategory,
                onToggleQuran = onToggleQuran,
                onToggleNawafil = onToggleNawafil,
                onToggleRawatib = onToggleRawatib,
                onToggleCustom = onToggleCustom,
                onDeleteCustomDeed = onDeleteCustomDeed,
                onOpenAddCustomDeed = onOpenAddCustomDeed,
                onToggleExcuse = onToggleExcuse,
                onOpenWeightsEditor = onOpenWeightsEditor
            )
        } else {
            WorshipStatsPane(
                uiState = uiState,
                onSelectDateAndJumpToTrack = { dk ->
                    onSelectDate(dk)
                    onSelectSubTab(WorshipSubTab.TRACK)
                }
            )
        }
    }
}

@Composable
private fun WorshipTabHeaderButton(
    title: String,
    selected: Boolean,
    tag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(tag),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (selected) colors.goldAccent else colors.textSecondary,
            modifier = Modifier.padding(vertical = 12.dp)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(if (selected) colors.goldAccent else Color.Transparent)
        )
    }
}

@Composable
private fun WorshipTrackPane(
    uiState: AdhkariUiState,
    onSelectDate: (String) -> Unit,
    onTogglePrayer: (String, PrayerKey) -> Unit,
    onQuickCompleteAdhkar: (String, String) -> Unit,
    onOpenAdhkarCategory: (String) -> Unit,
    onToggleQuran: (String) -> Unit,
    onToggleNawafil: (String, String) -> Unit,
    onToggleRawatib: (String, String) -> Unit,
    onToggleCustom: (String, String) -> Unit,
    onDeleteCustomDeed: (String) -> Unit,
    onOpenAddCustomDeed: () -> Unit,
    onToggleExcuse: (String, Boolean) -> Unit,
    onOpenWeightsEditor: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    val selKey = uiState.nav.selectedWorshipDate.ifBlank { uiState.todayDateKey }
    val selCal = PrayerTimeCalculator.calendarFromDateKey(selKey)
    val rec = uiState.worshipRecordFor(selKey)
    val score = uiState.worshipDayScore(selKey)
    val nowCal = Calendar.getInstance().apply { timeInMillis = uiState.nowEpochMillis }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Selected Date Header & 7-Day Interactive Strip
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = PrayerTimeCalculator.weekdayName(selCal),
                            style = MaterialTheme.typography.titleLarge,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "${PrayerTimeCalculator.formatHijriShort(selCal)} • ${PrayerTimeCalculator.formatGregorianShort(selCal)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                    Box(modifier = Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                        CircularProgressRing(
                            progress = score.totalPercent / 100f,
                            strokeWidth = 5.dp,
                            activeColor = colors.goldAccent,
                            modifier = Modifier.fillMaxSize()
                        )
                        Text("${score.totalPercent}%", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = colors.textPrimary)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (i in 6 downTo 0) {
                        val dt = (nowCal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -i) }
                        val dk = PrayerTimeCalculator.dateKeyOf(dt)
                        val st = uiState.worshipDayScore(dk)
                        val isSelected = dk == selKey
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) colors.goldAccent.copy(alpha = 0.16f) else Color.Transparent)
                                .let {
                                    if (isSelected) it.border(1.dp, colors.goldAccent.copy(alpha = 0.6f), RoundedCornerShape(12.dp)) else it
                                }
                                .clickable { onSelectDate(dk) }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = PrayerTimeCalculator.weekdayName(dt),
                                fontSize = 9.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                color = if (isSelected) colors.goldAccent else colors.textSecondary,
                                maxLines = 1
                            )
                            CircularProgressRing(
                                progress = st.totalPercent / 100f,
                                strokeWidth = 2.5.dp,
                                activeColor = if (st.totalPercent >= 80) colors.accentPrimary else colors.goldAccent,
                                modifier = Modifier.size(26.dp)
                            )
                            Text(
                                text = dt.get(Calendar.DAY_OF_MONTH).toString(),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSelected) colors.goldAccent else colors.textPrimary
                            )
                        }
                    }
                }
            }
        }

        // 1. الصلوات المفروضة (5 Prayers)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionCounterHeader("الصلوات", "${score.prayersDone}/5")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val icons = mapOf(
                    PrayerKey.FAJR to Icons.Default.WbTwilight,
                    PrayerKey.DHUHR to Icons.Default.WbSunny,
                    PrayerKey.ASR to Icons.Default.WbCloudy,
                    PrayerKey.MAGHRIB to Icons.Default.WbTwilight,
                    PrayerKey.ISHA to Icons.Default.NightsStay
                )
                PrayerKey.fiveObligatory.forEach { pKey ->
                    val done = rec.excuse || (rec.prayers[pKey] == true)
                    AppCard(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_worship_prayer_${pKey.key}"),
                        borderColor = if (done) colors.accentPrimary else colors.borderColor,
                        backgroundColor = if (done) colors.accentLight.copy(alpha = 0.55f) else colors.bgCard,
                        onClick = { onTogglePrayer(selKey, pKey) }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(pKey.arabicName, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = colors.textPrimary)
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = icons[pKey] ?: Icons.Default.WbSunny,
                                    contentDescription = pKey.arabicName,
                                    tint = if (done) colors.accentPrimary else colors.textSecondary.copy(alpha = 0.55f),
                                    modifier = Modifier.size(22.dp)
                                )
                                if (done) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .size(14.dp)
                                            .clip(CircleShape)
                                            .background(colors.accentPrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. الأذكار اليومية (Morning, Evening, Sleep)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionCounterHeader("الأذكار", "اضغط للقراءة أو الإتمام")
            listOf(
                Triple("morning", "أذكار الصباح", "🌅" to score.morningPct),
                Triple("evening", "أذكار المساء", "🌇" to score.eveningPct),
                Triple("sleep", "أذكار النوم", "🌙" to score.sleepPct)
            ).forEach { (catId, title, pair) ->
                val (emoji, pct) = pair
                val isDone = pct >= 100
                AppCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (isDone) colors.accentPrimary else colors.borderColor,
                    backgroundColor = if (isDone) colors.accentLight.copy(alpha = 0.55f) else colors.bgCard
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenAdhkarCategory(catId) }
                        ) {
                            Text(emoji, fontSize = 20.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                Text("اضغط لفتح العداد والقراءة المتتابعة", fontSize = 11.sp, color = colors.textSecondary)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .clickable { onQuickCompleteAdhkar(selKey, catId) }
                                .testTag("btn_quick_adhkar_$catId"),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressRing(
                                progress = pct / 100f,
                                strokeWidth = 3.5.dp,
                                activeColor = if (isDone) colors.accentPrimary else colors.goldAccent,
                                modifier = Modifier.fillMaxSize()
                            )
                            Text(
                                text = pct.toString(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isDone) colors.accentPrimary else colors.textPrimary
                            )
                        }
                    }
                }
            }
        }

        // 3. القرآن الكريم (Daily Wird)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionCounterHeader("القرآن الكريم", "${if (rec.quran) 1 else 0}/1")
            WorshipChecklistRow(
                emoji = "📖",
                title = "قراءة القرآن",
                sub = "ورد يومي من القرآن الكريم",
                checked = rec.quran,
                tag = "card_worship_quran",
                onClick = { onToggleQuran(selKey) }
            )
        }

        // 4. عبادات يومية ونوافل
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionCounterHeader("عبادات يومية ونوافل", "${score.nawafilDone}/${AuthenticAdhkarData.NAWAFIL_ITEMS.size}")
            AuthenticAdhkarData.NAWAFIL_ITEMS.forEach { item ->
                val done = item.id in rec.nawafil
                WorshipChecklistRow(
                    emoji = item.emoji,
                    title = item.title,
                    sub = item.sub,
                    checked = done,
                    tag = "card_nawafil_${item.id}",
                    onClick = { onToggleNawafil(selKey, item.id) }
                )
            }
        }

        // 5. السنن الرواتب
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionCounterHeader("سنن رواتب", "${score.rawatibDone}/${AuthenticAdhkarData.RAWATIB_ITEMS.size}")
            AuthenticAdhkarData.RAWATIB_ITEMS.forEach { item ->
                val done = rec.excuse || (item.id in rec.rawatib)
                WorshipChecklistRow(
                    emoji = "🌙",
                    title = item.title,
                    sub = item.sub,
                    checked = done,
                    tag = "card_rawatib_${item.id}",
                    onClick = { onToggleRawatib(selKey, item.id) }
                )
            }
        }

        // 6. أخرى (Custom Worship Deeds)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("أخرى", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(colors.goldAccent)
                        .clickable(onClick = onOpenAddCustomDeed)
                        .testTag("btn_add_custom_deed"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة عبادة", tint = Color.Black, modifier = Modifier.size(18.dp))
                }
            }
            uiState.customDeeds.forEach { deed ->
                val done = deed.id in rec.custom
                AppCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (done) colors.accentPrimary else colors.borderColor,
                    backgroundColor = if (done) colors.accentLight.copy(alpha = 0.55f) else colors.bgCard,
                    onClick = { onToggleCustom(selKey, deed.id) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Text("✨", fontSize = 18.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(deed.title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                if (deed.sub.isNotBlank()) {
                                    Text(deed.sub, fontSize = 11.sp, color = colors.textSecondary)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = { onDeleteCustomDeed(deed.id) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = colors.textSecondary, modifier = Modifier.size(16.dp))
                            }
                            CompletionCheckCircle(checked = done)
                        }
                    }
                }
            }
        }

        // 7. العذر الشرعي / الرخصة
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("العذر الشرعي / رخصة السفر والمرض", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                    Text("إيقاف مؤقت لتتبع الصلاة مع الحفاظ على سلسلة المداومة", fontSize = 11.sp, color = colors.textSecondary)
                }
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = rec.excuse,
                    onCheckedChange = { onToggleExcuse(selKey, it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = colors.goldAccent),
                    modifier = Modifier.testTag("switch_excuse_mode")
                )
            }
        }

        // 8. كيف يُحسب الإنجاز؟
        val w = uiState.prefs.worshipWeights
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("كيف يُحسب الإنجاز؟", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textSecondary)
                    Text(
                        text = "تعديل",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = colors.goldAccent,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier
                            .clickable(onClick = onOpenWeightsEditor)
                            .testTag("btn_edit_weights")
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WeightBadge("الصلوات ${w.prayers}%", Modifier.weight(1f))
                    WeightBadge("الأذكار ${w.adhkar}%", Modifier.weight(1f))
                    WeightBadge("القرآن ${w.quran}%", Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WeightBadge("الرواتب ${w.rawatib}%", Modifier.weight(1f))
                    WeightBadge("النوافل وعبادات يومية ${w.nawafil}%", Modifier.weight(2f))
                }
            }
        }
    }
}

@Composable
private fun SectionCounterHeader(title: String, countLabel: String) {
    val colors = LocalAdhkariColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(countLabel, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textSecondary)
        }
    }
}

@Composable
private fun WorshipChecklistRow(
    emoji: String,
    title: String,
    sub: String,
    checked: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    val colors = LocalAdhkariColors.current
    AppCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag),
        borderColor = if (checked) colors.accentPrimary else colors.borderColor,
        backgroundColor = if (checked) colors.accentLight.copy(alpha = 0.55f) else colors.bgCard,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Text(emoji, fontSize = 19.sp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                    Text(sub, fontSize = 11.sp, color = colors.textSecondary)
                }
            }
            Spacer(Modifier.width(8.dp))
            CompletionCheckCircle(checked = checked)
        }
    }
}

@Composable
private fun CompletionCheckCircle(checked: Boolean) {
    val colors = LocalAdhkariColors.current
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(if (checked) colors.accentPrimary else Color.Transparent)
            .border(
                width = 2.dp,
                color = if (checked) colors.accentPrimary else colors.borderColor,
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (checked) {
            Icon(Icons.Default.Check, contentDescription = "مكتمل", tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun WeightBadge(text: String, modifier: Modifier = Modifier) {
    val colors = LocalAdhkariColors.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(colors.bgSecondary)
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary, textAlign = TextAlign.Center)
    }
}
