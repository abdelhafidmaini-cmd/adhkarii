package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.model.PrayerKey
import com.example.data.seed.AuthenticAdhkarData
import com.example.ui.components.AppCard
import com.example.ui.theme.LocalAdhkariColors
import com.example.viewmodel.AdhkariUiState
import java.util.Calendar
import kotlin.math.roundToInt

@Composable
fun WorshipStatsPane(
    uiState: AdhkariUiState,
    onSelectDateAndJumpToTrack: (String) -> Unit
) {
    val colors = LocalAdhkariColors.current
    val nowCal = Calendar.getInstance().apply { timeInMillis = uiState.nowEpochMillis }
    val streaks = uiState.computeCategoryStreaks(30)

    // Collect last 14 days
    val last14 = (13 downTo 0).map { daysAgo ->
        val dt = (nowCal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -daysAgo) }
        val dk = PrayerTimeCalculator.dateKeyOf(dt)
        Triple(dt, dk, uiState.worshipDayScore(dk))
    }
    val prev7Avg = (last14.take(7).sumOf { it.third.totalPercent } / 7.0).roundToInt()
    val curr7 = last14.drop(7)
    val curr7Avg = (curr7.sumOf { it.third.totalPercent } / 7.0).roundToInt()
    val diff = curr7Avg - prev7Avg

    val bestDay = curr7.maxByOrNull { it.third.totalPercent } ?: curr7.last()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. 6 Streak Cards (2-column grid)
        streaks.chunked(2).forEach { pair ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { st ->
                    AppCard(modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(st.label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colors.textSecondary)
                                Text("🔥", fontSize = 14.sp)
                            }
                            Text(st.currentStreak.toString(), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = colors.textPrimary)
                            Text("🏆 أفضل مداومة : ${st.bestStreak}", fontSize = 11.sp, color = colors.textSecondary)
                        }
                    }
                }
            }
        }

        // 2. Week Comparison & Best Day Row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("مقارنة بالأسبوع الماضي", fontSize = 11.sp, color = colors.textSecondary)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = "${if (diff >= 0) "+" else ""}$diff%",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (diff >= 0) colors.accentPrimary else colors.goldAccent
                        )
                    }
                }
            }
            AppCard(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("أفضل يوم بمعدل ${bestDay.third.totalPercent}%", fontSize = 11.sp, color = colors.textSecondary)
                    Text(
                        text = PrayerTimeCalculator.weekdayName(bestDay.first),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = colors.goldAccent
                    )
                }
            }
        }

        // 3. Daily Achievement Rate Line Chart (Last 7 days)
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("معدل الإنجاز اليومي", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                    Text("آخر 7 أيام", fontSize = 11.sp, color = colors.textSecondary)
                }
                val dailyPoints = curr7.map { (dt, _, score) ->
                    PrayerTimeCalculator.weekdayName(dt).removePrefix("ال") to score.totalPercent
                }
                GoldAreaLineChart(points = dailyPoints, modifier = Modifier.fillMaxWidth().height(130.dp))
            }
        }

        // 4. Prayers Completion Breakdown Bars
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("نسبة إتمام الصلوات", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                val todayRec = uiState.worshipRecordFor(uiState.todayDateKey)
                PrayerKey.fiveObligatory.forEach { pKey ->
                    val activeCount = curr7.count { (_, dk, _) ->
                        val r = uiState.worshipRecordFor(dk)
                        r.excuse || (r.prayers[pKey] == true)
                    }
                    val pct = if ((todayRec.excuse || todayRec.prayers[pKey] == true) && activeCount == 1) {
                        maxOf(14, ((activeCount / 7.0) * 100.0).roundToInt())
                    } else {
                        ((activeCount / 7.0) * 100.0).roundToInt()
                    }
                    HorizontalGoldBar(pKey.arabicName, pct)
                }
            }
        }

        // 5. Adhkar Completion Breakdown Bars
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("نسبة إتمام الأذكار", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                val todayScore = uiState.worshipDayScore(uiState.todayDateKey)
                val morningAvg = (curr7.sumOf { it.third.morningPct } / 7.0).roundToInt()
                val eveningAvg = (curr7.sumOf { it.third.eveningPct } / 7.0).roundToInt()
                val sleepAvg = (curr7.sumOf { it.third.sleepPct } / 7.0).roundToInt()
                HorizontalGoldBar("أذكار الصباح", maxOf(todayScore.morningPct, morningAvg))
                HorizontalGoldBar("أذكار المساء", maxOf(todayScore.eveningPct, eveningAvg))
                HorizontalGoldBar("أذكار النوم", maxOf(todayScore.sleepPct, sleepAvg))
            }
        }

        // 6. Quran & Nawafil & Rawatib Completion Bars
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("نسبة المداومة على القرآن والنوافل والرواتب", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                val todayScore = uiState.worshipDayScore(uiState.todayDateKey)
                val quranPct = maxOf(
                    if (todayScore.quranDone) 100 else 0,
                    ((curr7.count { it.third.quranDone } / 7.0) * 100.0).roundToInt()
                )
                val rawatibCount = AuthenticAdhkarData.RAWATIB_ITEMS.size.coerceAtLeast(1)
                val rawatibPct = maxOf(
                    ((todayScore.rawatibDone.toDouble() / rawatibCount) * 100.0).roundToInt(),
                    (curr7.sumOf { (it.third.rawatibDone.toDouble() / rawatibCount) * 100.0 } / 7.0).roundToInt()
                )
                val nawafilCount = AuthenticAdhkarData.NAWAFIL_ITEMS.size.coerceAtLeast(1)
                val nawafilPct = maxOf(
                    ((todayScore.nawafilDone.toDouble() / nawafilCount) * 100.0).roundToInt(),
                    (curr7.sumOf { (it.third.nawafilDone.toDouble() / nawafilCount) * 100.0 } / 7.0).roundToInt()
                )
                HorizontalGoldBar("قراءة القرآن الكريم", quranPct)
                HorizontalGoldBar("سنن رواتب", rawatibPct)
                HorizontalGoldBar("عبادات يومية ونوافل", nawafilPct)
            }
        }

        // 7. 14-Day Achievement Heatmap
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("خريطة الإنجاز", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                        Text("آخر أسبوعين (14 يوماً) — مفتوح بالكامل مجاناً", fontSize = 11.sp, color = colors.textSecondary)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(colors.accentLight)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("شامل ومجاني ✓", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = colors.accentPrimary)
                    }
                }

                last14.chunked(7).forEach { week ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        week.forEach { (dt, dk, score) ->
                            val pct = score.totalPercent
                            val isToday = dk == uiState.todayDateKey
                            val cellBg = when {
                                pct >= 75 -> Color(0x5910B981)
                                pct > 0 -> Color(0x47C59B27)
                                else -> colors.bgSecondary
                            }
                            val cellBorder = when {
                                isToday -> colors.goldAccent
                                pct >= 75 -> Color(0xFF10B981)
                                pct > 0 -> Color(0xFFC59B27)
                                else -> colors.borderColor
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(cellBg)
                                    .border(if (isToday) 2.dp else 1.dp, cellBorder, RoundedCornerShape(12.dp))
                                    .clickable { onSelectDateAndJumpToTrack(dk) }
                                    .padding(vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(dt.get(Calendar.DAY_OF_MONTH).toString(), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = colors.textPrimary)
                                Text("$pct%", fontSize = 10.sp, color = colors.textSecondary)
                            }
                        }
                    }
                }
            }
        }

        // 8. Average by Weekday Line Chart
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("المعدل حسب اليوم", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                val weekdayOrder = listOf(
                    Calendar.SATURDAY to "السبت",
                    Calendar.SUNDAY to "الأحد",
                    Calendar.MONDAY to "الاثنين",
                    Calendar.TUESDAY to "الثلاثاء",
                    Calendar.WEDNESDAY to "الأربعاء",
                    Calendar.THURSDAY to "الخميس",
                    Calendar.FRIDAY to "الجمعة"
                )
                val weekdayPoints = weekdayOrder.map { (wd, label) ->
                    val matching = last14.filter { it.first.get(Calendar.DAY_OF_WEEK) == wd }
                    val avg = if (matching.isNotEmpty()) {
                        (matching.sumOf { it.third.totalPercent }.toDouble() / matching.size).roundToInt()
                    } else 0
                    label to avg
                }
                GoldAreaLineChart(points = weekdayPoints, modifier = Modifier.fillMaxWidth().height(130.dp))
            }
        }
    }
}

@Composable
private fun HorizontalGoldBar(label: String, pct: Int) {
    val colors = LocalAdhkariColors.current
    val clamped = pct.coerceIn(0, 100)
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.width(116.dp)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(10.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(colors.textPrimary.copy(alpha = 0.08f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(clamped / 100f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFC59B27), Color(0xFFE5C158))
                        )
                    )
            )
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
                text = "$clamped%",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = colors.textSecondary,
                modifier = Modifier.width(36.dp)
            )
        }
    }
}

@Composable
private fun GoldAreaLineChart(
    points: List<Pair<String, Int>>,
    modifier: Modifier = Modifier
) {
    val colors = LocalAdhkariColors.current
    if (points.isEmpty()) return

    Column(modifier = modifier, verticalArrangement = Arrangement.SpaceBetween) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            val w = size.width
            val h = size.height
            val coords = points.mapIndexed { idx, (_, value) ->
                val x = if (points.size > 1) (idx.toFloat() / (points.size - 1)) * w else w / 2f
                val y = h - (value.coerceIn(0, 100) / 100f) * h
                Offset(x, y)
            }
            if (coords.size >= 2) {
                val areaPath = Path().apply {
                    moveTo(coords.first().x, h)
                    coords.forEach { lineTo(it.x, it.y) }
                    lineTo(coords.last().x, h)
                    close()
                }
                drawPath(
                    path = areaPath,
                    brush = Brush.verticalGradient(
                        listOf(colors.goldAccent.copy(alpha = 0.35f), Color.Transparent)
                    )
                )
                val linePath = Path().apply {
                    moveTo(coords.first().x, coords.first().y)
                    coords.drop(1).forEach { lineTo(it.x, it.y) }
                }
                drawPath(
                    path = linePath,
                    color = colors.goldAccent,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
            coords.forEach { pt ->
                drawCircle(color = colors.goldAccent, radius = 4.dp.toPx(), center = pt)
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            points.forEach { (label, _) ->
                Text(
                    text = label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textSecondary
                )
            }
        }
    }
}
