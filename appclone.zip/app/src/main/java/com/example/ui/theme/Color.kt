package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Light Ivory & Emerald Palette
val LightBgPrimary = Color(0xFFFAF7F0)
val LightBgSecondary = Color(0xFFF2ECE1)
val LightBgCard = Color(0xFFFFFFFF)
val LightTextPrimary = Color(0xFF1C2822)
val LightTextSecondary = Color(0xFF526358)
val LightAccentPrimary = Color(0xFF1B5E3C)
val LightAccentSecondary = Color(0xFF2E7D52)
val LightAccentLight = Color(0xFFE6F2EC)
val LightBorderColor = Color(0xFFE5DEC9)
val LightGoldAccent = Color(0xFFC59B27)
val LightHeroStart = Color(0xFF13462C)
val LightHeroMid = Color(0xFF1B5E3C)
val LightHeroEnd = Color(0xFF246E48)

// Dark AMOLED & Emerald Palette
val DarkBgPrimary = Color(0xFF000000)
val DarkBgSecondary = Color(0xFF080C0A)
val DarkBgCard = Color(0xFF0D1310)
val DarkTextPrimary = Color(0xFFF0FDF4)
val DarkTextSecondary = Color(0xFF9CA3AF)
val DarkAccentPrimary = Color(0xFF10B981)
val DarkAccentSecondary = Color(0xFF059669)
val DarkAccentLight = Color(0xFF06281E)
val DarkBorderColor = Color(0xFF1A2620)
val DarkGoldAccent = Color(0xFFD4AF37)
val DarkHeroStart = Color(0xFF041B11)
val DarkHeroMid = Color(0xFF09301F)
val DarkHeroEnd = Color(0xFF0D422B)

val AmberStar = Color(0xFFFCD34D)
val AmberBadge = Color(0xFFD97706)
val IndigoEvening = Color(0xFF818CF8)
val DangerRed = Color(0xFFDC2626)

@Immutable
data class AdhkariColorTokens(
    val isDark: Boolean,
    val bgPrimary: Color,
    val bgSecondary: Color,
    val bgCard: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val accentLight: Color,
    val borderColor: Color,
    val goldAccent: Color,
    val heroStart: Color,
    val heroMid: Color,
    val heroEnd: Color
)

val LightAdhkariTokens = AdhkariColorTokens(
    isDark = false,
    bgPrimary = LightBgPrimary,
    bgSecondary = LightBgSecondary,
    bgCard = LightBgCard,
    textPrimary = LightTextPrimary,
    textSecondary = LightTextSecondary,
    accentPrimary = LightAccentPrimary,
    accentSecondary = LightAccentSecondary,
    accentLight = LightAccentLight,
    borderColor = LightBorderColor,
    goldAccent = LightGoldAccent,
    heroStart = LightHeroStart,
    heroMid = LightHeroMid,
    heroEnd = LightHeroEnd
)

val DarkAdhkariTokens = AdhkariColorTokens(
    isDark = true,
    bgPrimary = DarkBgPrimary,
    bgSecondary = DarkBgSecondary,
    bgCard = DarkBgCard,
    textPrimary = DarkTextPrimary,
    textSecondary = DarkTextSecondary,
    accentPrimary = DarkAccentPrimary,
    accentSecondary = DarkAccentSecondary,
    accentLight = DarkAccentLight,
    borderColor = DarkBorderColor,
    goldAccent = DarkGoldAccent,
    heroStart = DarkHeroStart,
    heroMid = DarkHeroMid,
    heroEnd = DarkHeroEnd
)

val LocalAdhkariColors = staticCompositionLocalOf { LightAdhkariTokens }
