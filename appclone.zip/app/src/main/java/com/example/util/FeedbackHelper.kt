package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object FeedbackHelper {
    private val soundScope = CoroutineScope(Dispatchers.Default)

    fun trigger(context: Context, vibrationEnabled: Boolean, soundEnabled: Boolean, isComplete: Boolean) {
        if (vibrationEnabled) {
            vibrate(context, isComplete)
        }
        if (soundEnabled) {
            playGentleTone(isComplete)
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrate(context: Context, isComplete: Boolean) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            } ?: return

            if (!vibrator.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (isComplete) {
                    val timings = longArrayOf(0, 35, 45, 65)
                    val amplitudes = intArrayOf(0, 120, 0, 180)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    vibrator.vibrate(VibrationEffect.createOneShot(18L, 80))
                }
            } else {
                vibrator.vibrate(if (isComplete) 60L else 18L)
            }
        } catch (_: Throwable) {
        }
    }

    private fun playGentleTone(isComplete: Boolean) {
        soundScope.launch {
            try {
                val sampleRate = 22050
                val durationMs = if (isComplete) 170 else 55
                val numSamples = (sampleRate * durationMs) / 1000
                val buffer = ShortArray(numSamples)
                val freq = if (isComplete) 660.0 else 440.0

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val env = exp(-t * if (isComplete) 14.0 else 35.0)
                    val sample = sin(2.0 * PI * freq * t) * env * 0.18
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                Thread.sleep(durationMs.toLong() + 40L)
                track.release()
            } catch (_: Throwable) {
            }
        }
    }
}
