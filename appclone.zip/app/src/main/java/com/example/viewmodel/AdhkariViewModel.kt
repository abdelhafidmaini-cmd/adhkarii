package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.location.Location
import android.location.LocationManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.local.AdhkariDatabase
import com.example.data.model.AdhanSettings
import com.example.data.model.AdhanVoice
import com.example.data.model.AlarmConfig
import com.example.data.model.AppTab
import com.example.data.model.AsrJuristic
import com.example.data.model.CalculationMethod
import com.example.data.model.CategoryProgressStats
import com.example.data.model.CategoryStreak
import com.example.data.model.CustomDeed
import com.example.data.model.DayWorshipRecord
import com.example.data.model.DhikrItem
import com.example.data.model.FreeTasbihState
import com.example.data.model.LocationSettings
import com.example.data.model.NextPrayerInfo
import com.example.data.model.PrayerKey
import com.example.data.model.PrayerOffsets
import com.example.data.model.TasbihVariant
import com.example.data.model.ThemeMode
import com.example.data.model.WorshipDayScore
import com.example.data.model.WorshipSubTab
import com.example.data.model.WorshipWeights
import com.example.data.repository.AdhkariRepository
import com.example.data.repository.AppPreferencesBundle
import com.example.data.seed.AuthenticAdhkarData
import com.example.notifications.AdhanPlaybackService
import com.example.notifications.AdhanPlaybackStatus
import com.example.notifications.AlarmScheduler
import com.example.util.FeedbackHelper
import com.example.widget.AdhkariWidgetUpdater
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

data class NavUiState(
    val currentTab: AppTab = AppTab.HOME,
    val currentCategory: String = "morning",
    val sequentialIndex: Int = 0,
    val worshipSubTab: WorshipSubTab = WorshipSubTab.TRACK,
    val selectedWorshipDate: String = PrayerTimeCalculator.dateKeyOf(),
    val searchQuery: String = "",
    val toastMessage: String? = null,
    val toastTick: Long = 0L,
    val gpsStatusMessage: String = ""
)

data class AdhkariUiState(
    val nav: NavUiState = NavUiState(),
    val prefs: AppPreferencesBundle = AppPreferencesBundle(),
    val dailyProgress: Map<String, Map<String, Int>> = emptyMap(),
    val dailyTotals: Map<String, Int> = emptyMap(),
    val worshipLogs: Map<String, DayWorshipRecord> = emptyMap(),
    val customDeeds: List<CustomDeed> = emptyList(),
    val alarms: List<AlarmConfig> = emptyList(),
    val adhanPlayback: AdhanPlaybackStatus = AdhanPlaybackStatus(),
    val nowEpochMillis: Long = System.currentTimeMillis()
) {
    val todayDateKey: String
        get() = PrayerTimeCalculator.dateKeyOf(Calendar.getInstance().apply { timeInMillis = nowEpochMillis })

    val nextPrayerInfo: NextPrayerInfo
        get() = PrayerTimeCalculator.getNextPrayerInfo(
            Calendar.getInstance().apply { timeInMillis = nowEpochMillis },
            prefs.location
        )

    fun activeAdhkarForCategory(categoryId: String = nav.currentCategory): List<DhikrItem> {
        return if (categoryId == "post_prayer") {
            val vKey = prefs.tasbihVariant.key
            AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter {
                it.categoryId == "post_prayer" && (it.variantGroup == "common" || it.variantGroup == vKey)
            }
        } else {
            AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter { it.categoryId == categoryId }
        }
    }

    fun counterKeyFor(dhikr: DhikrItem): String {
        return if (dhikr.categoryId == "post_prayer") {
            "pp_${prefs.currentPostPrayerTab.key}_${dhikr.id}"
        } else {
            dhikr.id
        }
    }

    fun currentCountFor(dhikr: DhikrItem, dateKey: String = todayDateKey): Int {
        val dayMap = dailyProgress[dateKey] ?: return 0
        return dayMap[counterKeyFor(dhikr)] ?: 0
    }

    fun categoryStats(
        categoryId: String,
        prayerKeyOverride: PrayerKey? = null,
        dateKey: String = todayDateKey
    ): CategoryProgressStats {
        val dayMap = dailyProgress[dateKey] ?: emptyMap()
        return if (categoryId == "post_prayer") {
            val pKey = prayerKeyOverride ?: prefs.currentPostPrayerTab
            val vKey = prefs.tasbihVariant.key
            val list = AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter {
                it.categoryId == "post_prayer" && (it.variantGroup == "common" || it.variantGroup == vKey)
            }
            val done = list.count { d -> (dayMap["pp_${pKey.key}_${d.id}"] ?: 0) >= d.targetCount }
            val pct = if (list.isNotEmpty()) Math.round((done.toFloat() / list.size) * 100f) else 0
            CategoryProgressStats(done, list.size, pct)
        } else {
            val list = AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter { it.categoryId == categoryId }
            val done = list.count { d -> (dayMap[d.id] ?: 0) >= d.targetCount }
            val pct = if (list.isNotEmpty()) Math.round((done.toFloat() / list.size) * 100f) else 0
            CategoryProgressStats(done, list.size, pct)
        }
    }

    fun worshipRecordFor(dateKey: String): DayWorshipRecord {
        return worshipLogs[dateKey] ?: DayWorshipRecord(dateKey = dateKey)
    }

    fun worshipDayScore(dateKey: String): WorshipDayScore {
        val rec = worshipRecordFor(dateKey)
        val w = prefs.worshipWeights
        val totalWeight = (w.prayers + w.adhkar + w.quran + w.rawatib + w.nawafil).coerceAtLeast(1)

        val prayersDone = if (rec.excuse) 5 else PrayerKey.fiveObligatory.count { rec.prayers[it] == true }
        val prayersRatio = prayersDone / 5.0

        val mSt = categoryStats("morning", dateKey = dateKey)
        val eSt = categoryStats("evening", dateKey = dateKey)
        val sSt = categoryStats("sleep", dateKey = dateKey)
        val adhkarRatio = ((mSt.percent / 100.0) + (eSt.percent / 100.0) + (sSt.percent / 100.0)) / 3.0

        val quranRatio = if (rec.quran) 1.0 else 0.0

        val rawatibCount = AuthenticAdhkarData.RAWATIB_ITEMS.size
        val rawatibDone = if (rec.excuse) rawatibCount else AuthenticAdhkarData.RAWATIB_ITEMS.count { it.id in rec.rawatib }
        val rawatibRatio = rawatibDone.toDouble() / rawatibCount.coerceAtLeast(1)

        val totalNawafilAndCustom = AuthenticAdhkarData.NAWAFIL_ITEMS.size + customDeeds.size
        val nawafilDone = AuthenticAdhkarData.NAWAFIL_ITEMS.count { it.id in rec.nawafil }
        val customDone = customDeeds.count { it.id in rec.custom }
        val nawafilRatio = if (totalNawafilAndCustom > 0) {
            (nawafilDone + customDone).toDouble() / totalNawafilAndCustom
        } else 0.0

        val weightedSum =
            prayersRatio * w.prayers +
                adhkarRatio * w.adhkar +
                quranRatio * w.quran +
                rawatibRatio * w.rawatib +
                nawafilRatio * w.nawafil

        val totalPct = Math.round((weightedSum / totalWeight) * 100.0).toInt().coerceIn(0, 100)
        return WorshipDayScore(
            totalPercent = totalPct,
            prayersDone = prayersDone,
            rawatibDone = rawatibDone,
            nawafilDone = nawafilDone,
            customDone = customDone,
            quranDone = rec.quran,
            morningPct = mSt.percent,
            eveningPct = eSt.percent,
            sleepPct = sSt.percent
        )
    }

    fun activeCommitmentDays(): Int {
        val activeFromProgress = dailyProgress.count { (_, map) -> map.values.any { it > 0 } }
        val activeFromWorship = worshipLogs.count { (_, rec) ->
            rec.quran || rec.prayers.values.any { it } || rec.rawatib.isNotEmpty() || rec.nawafil.isNotEmpty()
        }
        return maxOf(1, activeFromProgress, activeFromWorship)
    }

    fun lifetimeTasbihat(): Int {
        return prefs.freeTasbih.lifetime + dailyTotals.values.sum()
    }

    fun computeCategoryStreaks(daysWindow: Int = 30): List<CategoryStreak> {
        val now = Calendar.getInstance().apply { timeInMillis = nowEpochMillis }
        val defs: List<Pair<String, Pair<String, (String) -> Boolean>>> = listOf(
            "prayers" to ("الصلوات" to { dk -> worshipDayScore(dk).prayersDone > 0 }),
            "adhkar" to ("الأذكار" to { dk ->
                val s = worshipDayScore(dk)
                s.morningPct > 0 || s.eveningPct > 0 || s.sleepPct > 0
            }),
            "quran" to ("القرآن" to { dk -> worshipRecordFor(dk).quran }),
            "nawafil" to ("النوافل" to { dk ->
                val s = worshipDayScore(dk)
                s.rawatibDone > 0 || s.nawafilDone > 0
            }),
            "fasting" to ("الصيام" to { dk -> "nf_fasting" in worshipRecordFor(dk).nawafil }),
            "custom" to ("أخرى" to { dk -> worshipDayScore(dk).customDone > 0 })
        )

        return defs.map { (key, pair) ->
            val (label, check) = pair
            var bestStreak = 0
            var running = 0
            for (i in (daysWindow - 1) downTo 0) {
                val cal = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, -i) }
                val dk = PrayerTimeCalculator.dateKeyOf(cal)
                if (check(dk)) {
                    running++
                    if (running > bestStreak) bestStreak = running
                } else {
                    running = 0
                }
            }
            CategoryStreak(key, label, running, bestStreak)
        }
    }
}

class AdhkariViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AdhkariRepository(
        AdhkariDatabase.getInstance(application).adhkariDao()
    )

    private val navState = MutableStateFlow(NavUiState())
    private val clockTick = MutableStateFlow(System.currentTimeMillis())
    private var lastTriggeredMinuteKey = ""

    private val baseDataFlow = combine(
        navState,
        repository.preferencesFlow,
        repository.progressFlow,
        repository.dailyTotalsFlow,
        repository.worshipLogsFlow
    ) { nav, prefs, progress, totals, worship ->
        AdhkariUiState(
            nav = nav,
            prefs = prefs,
            dailyProgress = progress,
            dailyTotals = totals,
            worshipLogs = worship
        )
    }

    val uiState: StateFlow<AdhkariUiState> = combine(
        baseDataFlow,
        repository.customDeedsFlow,
        repository.alarmsFlow,
        AdhanPlaybackService.playbackStatus,
        clockTick
    ) { base, deeds, alarms, adhanPlayback, tick ->
        base.copy(
            customDeeds = deeds,
            alarms = alarms,
            adhanPlayback = adhanPlayback,
            nowEpochMillis = tick
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AdhkariUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            val alarms = repository.getAlarmsOnce()
            val prefs = repository.getPreferencesOnce()
            AlarmScheduler.scheduleAllAlarms(getApplication(), alarms, prefs.location, prefs.adhan)
            AdhkariWidgetUpdater.updateAllWidgets(getApplication())
        }
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                val nowMs = System.currentTimeMillis()
                clockTick.value = nowMs
                checkInAppMinuteAlarms(nowMs)
            }
        }
    }

    private fun checkInAppMinuteAlarms(nowMs: Long) {
        val state = uiState.value
        if (state.alarms.isEmpty()) return
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs }
        val curHM = String.format(
            Locale.US,
            "%02d:%02d",
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE)
        )
        if (curHM == lastTriggeredMinuteKey) return

        val times = PrayerTimeCalculator.computePrayerTimesForDate(cal, state.prefs.location)
        val curTotalMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

        for (al in state.alarms) {
            if (!al.enabled && !(al.id == "alarm_prayer_entry" && state.prefs.adhan.enabled)) continue
            if (al.alarmType == "fixed_time" && al.timeValue == curHM) {
                lastTriggeredMinuteKey = curHM
                showToast("🔔 تذكير أذكاري: حان الآن موعد ${al.title}")
                FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, true)
                break
            } else if (al.id == "alarm_prayer_entry") {
                for (pk in PrayerKey.fiveObligatory) {
                    if (times.byKey(pk).timeStr == curHM) {
                        lastTriggeredMinuteKey = curHM
                        if (state.prefs.adhan.isPrayerEnabled(pk)) {
                            AdhanPlaybackService.startAdhan(
                                context = getApplication(),
                                prayerKey = pk,
                                locationName = state.prefs.location.shortName,
                                isPreview = false
                            )
                            showToast("🕌 حان الآن وقت صلاة ${pk.arabicName} — يرفع الآن الأذان")
                        } else {
                            showToast("🕌 حان الآن وقت صلاة ${pk.arabicName} حسب توقيت ${state.prefs.location.shortName}")
                            FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, true)
                        }
                        AdhkariWidgetUpdater.updateAllWidgetsAsync(getApplication())
                        return
                    }
                }
            } else if (al.id == "alarm_before_prayer") {
                val offset = al.timeValue.toIntOrNull() ?: 15
                for (pk in PrayerKey.fiveObligatory) {
                    if (times.byKey(pk).totalMinutes - offset == curTotalMin) {
                        lastTriggeredMinuteKey = curHM
                        showToast("⏳ متبقي $offset دقيقة على صلاة ${pk.arabicName}")
                        return
                    }
                }
            } else if (al.id == "alarm_after_prayer") {
                val offset = al.timeValue.toIntOrNull() ?: 20
                for (pk in PrayerKey.fiveObligatory) {
                    if (times.byKey(pk).totalMinutes + offset == curTotalMin) {
                        lastTriggeredMinuteKey = curHM
                        showToast("📿 تذكير بأذكار بعد صلاة ${pk.arabicName}")
                        return
                    }
                }
            }
        }
    }

    fun showToast(message: String) {
        navState.update { it.copy(toastMessage = message, toastTick = System.currentTimeMillis()) }
    }

    fun clearToast() {
        navState.update { it.copy(toastMessage = null) }
    }

    fun switchTab(tab: AppTab) {
        navState.update { it.copy(currentTab = tab) }
    }

    fun openCategoryReader(categoryId: String) {
        navState.update {
            it.copy(
                currentTab = AppTab.READER,
                currentCategory = categoryId,
                sequentialIndex = 0
            )
        }
    }

    fun openPostPrayer(prayerKey: PrayerKey? = null) {
        if (prayerKey != null) {
            viewModelScope.launch {
                repository.saveSetting("post_prayer_tab", prayerKey.key)
            }
        }
        openCategoryReader("post_prayer")
    }

    fun selectPostPrayerTab(prayerKey: PrayerKey) {
        viewModelScope.launch {
            repository.saveSetting("post_prayer_tab", prayerKey.key)
        }
        navState.update { it.copy(sequentialIndex = 0) }
    }

    fun changeTasbihVariant(variant: TasbihVariant) {
        viewModelScope.launch {
            repository.saveSetting("tasbih_variant", variant.key)
        }
        navState.update { it.copy(sequentialIndex = 0) }
        showToast("تم تحديث صيغة التسبيح حسب الرواية الصحيحة المختارة")
    }

    fun navigateSeqIndex(delta: Int) {
        val list = uiState.value.activeAdhkarForCategory()
        if (list.isEmpty()) return
        navState.update {
            val nextIdx = (it.sequentialIndex + delta).let { raw ->
                when {
                    raw < 0 -> list.lastIndex
                    raw >= list.size -> 0
                    else -> raw
                }
            }
            it.copy(sequentialIndex = nextIdx)
        }
    }

    fun setSeqIndex(index: Int) {
        val list = uiState.value.activeAdhkarForCategory()
        if (list.isEmpty()) return
        navState.update { it.copy(sequentialIndex = index.coerceIn(0, list.lastIndex)) }
    }

    fun incrementSequentialDhikr() {
        val state = uiState.value
        val list = state.activeAdhkarForCategory()
        if (list.isEmpty()) return
        val idx = state.nav.sequentialIndex.coerceIn(0, list.lastIndex)
        val item = list[idx]
        val cur = state.currentCountFor(item)

        if (cur >= item.targetCount) {
            if (idx + 1 < list.size) {
                navState.update { it.copy(sequentialIndex = idx + 1) }
            } else {
                showToast("تم بحمد الله إكمال جميع أذكار هذا القسم ✓")
            }
            return
        }

        val key = state.counterKeyFor(item)
        val dateKey = state.todayDateKey
        viewModelScope.launch {
            val nextVal = repository.setDhikrCount(
                dateKey = dateKey,
                counterKey = key,
                prevCount = cur,
                targetCount = item.targetCount,
                newCount = cur + 1
            )
            val justFinished = nextVal >= item.targetCount
            FeedbackHelper.trigger(
                getApplication(),
                state.prefs.vibrationEnabled,
                state.prefs.soundEnabled,
                justFinished
            )
            if (justFinished) {
                AdhkariWidgetUpdater.updateAllWidgetsAsync(getApplication())
            }
            if (justFinished && state.prefs.autoAdvance) {
                delay(350L)
                if (idx + 1 < list.size) {
                    navState.update { it.copy(sequentialIndex = idx + 1) }
                } else {
                    showToast("تقبل الله طاعتكم! اكتملت أذكار القسم ✓")
                }
            }
        }
    }

    fun decrementSequentialDhikr() {
        val state = uiState.value
        val list = state.activeAdhkarForCategory()
        if (list.isEmpty()) return
        val idx = state.nav.sequentialIndex.coerceIn(0, list.lastIndex)
        val item = list[idx]
        val cur = state.currentCountFor(item)
        if (cur <= 0) return

        val key = state.counterKeyFor(item)
        val dateKey = state.todayDateKey
        viewModelScope.launch {
            repository.setDhikrCount(dateKey, key, cur, item.targetCount, cur - 1)
        }
    }

    fun resetCurrentDhikr() {
        val state = uiState.value
        val list = state.activeAdhkarForCategory()
        if (list.isEmpty()) return
        val idx = state.nav.sequentialIndex.coerceIn(0, list.lastIndex)
        val item = list[idx]
        val cur = state.currentCountFor(item)
        val key = state.counterKeyFor(item)
        val dateKey = state.todayDateKey
        viewModelScope.launch {
            repository.setDhikrCount(dateKey, key, cur, item.targetCount, 0)
            showToast("تم تصفير عداد الذكر")
        }
    }

    // Theme & Display Settings
    fun cycleTheme() {
        val next = if (uiState.value.prefs.themeMode == ThemeMode.LIGHT) ThemeMode.DARK else ThemeMode.LIGHT
        setThemeMode(next)
        showToast(if (next == ThemeMode.DARK) "تم تفعيل الوضع الداكن (AMOLED)" else "تم تفعيل الوضع الفاتح العاجي")
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.saveSetting("theme_mode", mode.key)
        }
    }

    fun setFontSize(sizeSp: Int) {
        viewModelScope.launch {
            repository.saveSetting("font_size", sizeSp.coerceIn(18, 32).toString())
        }
    }

    fun setVibrationEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.saveSetting("vibration_enabled", enabled.toString())
            showToast("تم حفظ الإعدادات")
        }
    }

    fun setSoundEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.saveSetting("sound_enabled", enabled.toString())
            if (enabled) {
                FeedbackHelper.trigger(getApplication(), uiState.value.prefs.vibrationEnabled, true, false)
            }
            showToast("تم حفظ الإعدادات")
        }
    }

    fun setAutoAdvance(enabled: Boolean) {
        viewModelScope.launch {
            repository.saveSetting("auto_advance", enabled.toString())
            showToast("تم حفظ الإعدادات")
        }
    }

    fun setReadOnlyMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.saveSetting("read_only_mode", enabled.toString())
        }
    }

    // Location & Prayer Settings
    fun saveLocation(loc: LocationSettings) {
        viewModelScope.launch {
            repository.saveLocation(loc)
            AlarmScheduler.scheduleAllAlarms(getApplication(), uiState.value.alarms, loc, uiState.value.prefs.adhan)
            AdhkariWidgetUpdater.updateAllWidgets(getApplication())
            showToast("تم تحديث الموقع إلى: ${loc.shortName}")
        }
    }

    fun updatePrayerCalculation(method: CalculationMethod, asr: AsrJuristic, offsets: PrayerOffsets) {
        val updated = uiState.value.prefs.location.copy(
            method = method,
            asrJuristic = asr,
            offsets = offsets
        )
        viewModelScope.launch {
            repository.saveLocation(updated)
            AlarmScheduler.scheduleAllAlarms(getApplication(), uiState.value.alarms, updated, uiState.value.prefs.adhan)
            AdhkariWidgetUpdater.updateAllWidgets(getApplication())
            showToast("تم تحديث إعدادات حساب مواقيت الصلاة")
        }
    }

    fun resetPrayerOffsets() {
        val cur = uiState.value.prefs.location
        updatePrayerCalculation(cur.method, cur.asrJuristic, PrayerOffsets())
        showToast("تم تصفير فروق الدقائق اليدوية")
    }

    @Suppress("MissingPermission")
    fun detectLocationFromDevice(): LocationSettings? {
        return try {
            val lm = getApplication<Application>().getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            var bestLoc: Location? = null
            for (p in providers) {
                val loc = try { lm?.getLastKnownLocation(p) } catch (_: SecurityException) { null }
                if (loc != null) {
                    bestLoc = loc
                    break
                }
            }
            if (bestLoc != null) {
                val tzHours = TimeZone.getDefault().rawOffset / 3600000.0
                val lat = Math.round(bestLoc.latitude * 10000.0) / 10000.0
                val lng = Math.round(bestLoc.longitude * 10000.0) / 10000.0
                val updated = uiState.value.prefs.location.copy(
                    cityName = String.format(Locale.US, "موقعي الحالي (%.2f°, %.2f°)", lat, lng),
                    shortName = "موقعي الحالي (GPS)",
                    lat = lat,
                    lng = lng,
                    tz = tzHours
                )
                viewModelScope.launch {
                    repository.saveLocation(updated)
                    AlarmScheduler.scheduleAllAlarms(getApplication(), uiState.value.alarms, updated, uiState.value.prefs.adhan)
                    AdhkariWidgetUpdater.updateAllWidgets(getApplication())
                }
                navState.update { it.copy(gpsStatusMessage = "تم تحديد الموقع بنجاح وحفظه للعمل دون إنترنت ✓") }
                updated
            } else {
                navState.update { it.copy(gpsStatusMessage = "تعذر الحصول على آخر موقع مسجل، يمكنك اختيار مدينتك يدوياً بالأسفل.") }
                null
            }
        } catch (_: Throwable) {
            navState.update { it.copy(gpsStatusMessage = "تعذر الوصول للموقع تلقائياً، يرجى اختيار المدينة يدوياً.") }
            null
        }
    }

    fun setGpsStatusMessage(msg: String) {
        navState.update { it.copy(gpsStatusMessage = msg) }
    }

    // Search
    fun updateSearchQuery(q: String) {
        navState.update { it.copy(searchQuery = q) }
    }

    // Free Tasbih
    fun incrementFreeTasbih() {
        val cur = uiState.value.prefs.freeTasbih
        val next = cur.copy(current = cur.current + 1, lifetime = cur.lifetime + 1)
        FeedbackHelper.trigger(
            getApplication(),
            uiState.value.prefs.vibrationEnabled,
            uiState.value.prefs.soundEnabled,
            next.current % 33 == 0
        )
        viewModelScope.launch { repository.saveFreeTasbih(next) }
    }

    fun resetFreeTasbih() {
        val next = uiState.value.prefs.freeTasbih.copy(current = 0)
        viewModelScope.launch { repository.saveFreeTasbih(next) }
    }

    fun updateFreeTasbihPhrase(phrase: String) {
        val next = uiState.value.prefs.freeTasbih.copy(phrase = phrase)
        viewModelScope.launch { repository.saveFreeTasbih(next) }
    }

    // Worship Tracker Actions
    fun setWorshipSubTab(sub: WorshipSubTab) {
        navState.update { it.copy(worshipSubTab = sub) }
    }

    fun selectWorshipDate(dateKey: String) {
        navState.update { it.copy(selectedWorshipDate = dateKey) }
    }

    fun toggleWorshipPrayer(dateKey: String, prayerKey: PrayerKey) {
        val state = uiState.value
        val rec = state.worshipRecordFor(dateKey)
        val newVal = !(rec.prayers[prayerKey] ?: false)
        val updated = rec.copy(prayers = rec.prayers.toMutableMap().apply { put(prayerKey, newVal) })
        FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, newVal)
        viewModelScope.launch { repository.saveWorshipLog(updated) }
    }

    fun toggleWorshipQuran(dateKey: String) {
        val state = uiState.value
        val rec = state.worshipRecordFor(dateKey)
        val updated = rec.copy(quran = !rec.quran)
        FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, updated.quran)
        viewModelScope.launch { repository.saveWorshipLog(updated) }
    }

    fun toggleWorshipRawatib(dateKey: String, id: String) {
        val state = uiState.value
        val rec = state.worshipRecordFor(dateKey)
        val nextSet = rec.rawatib.toMutableSet()
        val added = if (id in nextSet) { nextSet.remove(id); false } else { nextSet.add(id); true }
        FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, added)
        viewModelScope.launch { repository.saveWorshipLog(rec.copy(rawatib = nextSet)) }
    }

    fun toggleWorshipNawafil(dateKey: String, id: String) {
        val state = uiState.value
        val rec = state.worshipRecordFor(dateKey)
        val nextSet = rec.nawafil.toMutableSet()
        val added = if (id in nextSet) { nextSet.remove(id); false } else { nextSet.add(id); true }
        FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, added)
        viewModelScope.launch { repository.saveWorshipLog(rec.copy(nawafil = nextSet)) }
    }

    fun toggleWorshipCustom(dateKey: String, id: String) {
        val state = uiState.value
        val rec = state.worshipRecordFor(dateKey)
        val nextSet = rec.custom.toMutableSet()
        val added = if (id in nextSet) { nextSet.remove(id); false } else { nextSet.add(id); true }
        FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, added)
        viewModelScope.launch { repository.saveWorshipLog(rec.copy(custom = nextSet)) }
    }

    fun quickCompleteAdhkarCategory(dateKey: String, categoryId: String) {
        val state = uiState.value
        val st = state.categoryStats(categoryId, dateKey = dateKey)
        val markDone = st.percent < 100
        val dayMap = state.dailyProgress[dateKey] ?: emptyMap()
        val list = AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter { it.categoryId == categoryId }
        val updates = list.map { d ->
            val prev = dayMap[d.id] ?: 0
            val next = if (markDone) d.targetCount else 0
            Triple(d.id, prev, next)
        }
        FeedbackHelper.trigger(getApplication(), state.prefs.vibrationEnabled, state.prefs.soundEnabled, markDone)
        viewModelScope.launch {
            repository.setCategoryProgressBatch(dateKey, updates)
            AdhkariWidgetUpdater.updateAllWidgetsAsync(getApplication())
            showToast(if (markDone) "تم تسجيل إتمام القسم كاملاً ✓" else "تمت إعادة ضبط عداد القسم لهذا اليوم")
        }
    }

    fun toggleExcuseMode(dateKey: String, enabled: Boolean) {
        val rec = uiState.value.worshipRecordFor(dateKey)
        viewModelScope.launch {
            repository.saveWorshipLog(rec.copy(excuse = enabled))
            showToast(if (enabled) "تم تفعيل وضع العذر الشرعي / الرخصة لهذا اليوم" else "تم إيقاف وضع العذر الشرعي")
        }
    }

    fun addCustomDeed(title: String, sub: String) {
        if (title.isBlank()) {
            showToast("يرجى كتابة اسم العبادة أولاً")
            return
        }
        viewModelScope.launch {
            repository.addCustomDeed(title, sub)
            showToast("تمت إضافة العبادة بنجاح ✓")
        }
    }

    fun deleteCustomDeed(id: String) {
        viewModelScope.launch {
            repository.deleteCustomDeed(id)
            showToast("تم حذف العبادة")
        }
    }

    fun saveWorshipWeights(weights: WorshipWeights) {
        viewModelScope.launch {
            repository.saveWorshipWeights(weights)
            showToast("تم تحديث أوزان حساب الإنجاز")
        }
    }

    // Alarms & Adhan Audio
    fun toggleAlarm(alarm: AlarmConfig, enabled: Boolean) {
        val updated = alarm.copy(enabled = enabled)
        viewModelScope.launch {
            repository.updateAlarm(updated)
            val newAlarms = uiState.value.alarms.map { if (it.id == alarm.id) updated else it }
            var adhan = uiState.value.prefs.adhan
            if (alarm.id == "alarm_prayer_entry") {
                adhan = adhan.copy(enabled = enabled)
                repository.saveAdhanSettings(adhan)
            }
            AlarmScheduler.scheduleAllAlarms(getApplication(), newAlarms, uiState.value.prefs.location, adhan)
            showToast(if (enabled) "تم تفعيل: ${alarm.title}" else "تم إيقاف: ${alarm.title}")
        }
    }

    fun updateAlarmTime(alarm: AlarmConfig, timeValue: String) {
        val updated = alarm.copy(timeValue = timeValue)
        viewModelScope.launch {
            repository.updateAlarm(updated)
            val newAlarms = uiState.value.alarms.map { if (it.id == alarm.id) updated else it }
            AlarmScheduler.scheduleAllAlarms(getApplication(), newAlarms, uiState.value.prefs.location, uiState.value.prefs.adhan)
            showToast("تم تحديث توقيت التنبيه وحفظه")
        }
    }

    fun setAdhanEnabled(enabled: Boolean) {
        val updated = uiState.value.prefs.adhan.copy(enabled = enabled)
        viewModelScope.launch {
            repository.saveAdhanSettings(updated)
            val prayerAlarm = uiState.value.alarms.firstOrNull { it.id == "alarm_prayer_entry" }
            val newAlarms = if (prayerAlarm != null && prayerAlarm.enabled != enabled) {
                val up = prayerAlarm.copy(enabled = enabled)
                repository.updateAlarm(up)
                uiState.value.alarms.map { if (it.id == up.id) up else it }
            } else {
                uiState.value.alarms
            }
            AlarmScheduler.scheduleAllAlarms(getApplication(), newAlarms, uiState.value.prefs.location, updated)
            showToast(if (enabled) "تم تفعيل الأذان التلقائي عند دخول وقت الصلاة 🕌" else "تم إيقاف الأذان الصوتي التلقائي")
        }
    }

    fun setAdhanVoice(voice: AdhanVoice) {
        val updated = uiState.value.prefs.adhan.copy(voice = voice)
        viewModelScope.launch {
            repository.saveAdhanSettings(updated)
            showToast("تم اختيار: ${voice.arabicName}")
        }
    }

    fun setAdhanAlarmChannel(useAlarmChannel: Boolean) {
        val updated = uiState.value.prefs.adhan.copy(useAlarmChannel = useAlarmChannel)
        viewModelScope.launch {
            repository.saveAdhanSettings(updated)
            showToast(if (useAlarmChannel) "يعمل الأذان عبر قناة المنبه" else "يعمل الأذان عبر قناة الوسائط")
        }
    }

    fun togglePrayerAdhan(prayerKey: PrayerKey) {
        val cur = uiState.value.prefs.adhan
        val curVal = cur.perPrayerEnabled[prayerKey] ?: true
        val nextMap = cur.perPrayerEnabled.toMutableMap().apply { put(prayerKey, !curVal) }
        val updated = cur.copy(perPrayerEnabled = nextMap)
        viewModelScope.launch {
            repository.saveAdhanSettings(updated)
            showToast(
                if (!curVal) "تم تفعيل صوت الأذان لصلاة ${prayerKey.arabicName}"
                else "تم كتم صوت الأذان لصلاة ${prayerKey.arabicName}"
            )
        }
    }

    fun setCustomAdhanAudio(uri: String, displayName: String) {
        val updated = uiState.value.prefs.adhan.copy(
            voice = AdhanVoice.CUSTOM,
            customAudioUri = uri,
            customAudioName = displayName
        )
        viewModelScope.launch {
            repository.saveAdhanSettings(updated)
            showToast("تم تعيين صوت الأذان المخصص: $displayName ✓")
        }
    }

    fun previewAdhan(prayerKey: PrayerKey? = null) {
        AdhanPlaybackService.startAdhan(
            context = getApplication(),
            prayerKey = prayerKey ?: uiState.value.nextPrayerInfo.next.key,
            locationName = uiState.value.prefs.location.shortName,
            isPreview = true
        )
    }

    fun stopAdhan() {
        AdhanPlaybackService.stopAdhan(getApplication())
        showToast("تم إيقاف صوت الأذان")
    }

    fun refreshWidgetsNow() {
        AdhkariWidgetUpdater.updateAllWidgetsAsync(getApplication())
    }

    // Backup / SQL Inspector
    suspend fun buildBackupJson(): String = repository.exportBackupJson()

    fun restoreBackupJson(jsonText: String) {
        viewModelScope.launch {
            val ok = repository.importBackupJson(jsonText)
            showToast(if (ok) "تمت استعادة النسخة الاحتياطية بنجاح ✓" else "ملف النسخة الاحتياطية غير صالح")
        }
    }

    suspend fun getProgressSnapshotJson(): String = repository.getProgressSnapshotJson()
    fun getAdhkarJsonPreview(): String = repository.generateAdhkarJsonPreview()
    fun getCompleteSqlScript(): String = repository.generateCompleteSqlScript()
}
