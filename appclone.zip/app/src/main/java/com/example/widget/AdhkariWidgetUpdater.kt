package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.local.AdhkariDatabase
import com.example.data.model.LocationSettings
import com.example.data.model.PrayerKey
import com.example.data.repository.AdhkariRepository
import com.example.data.seed.AuthenticAdhkarData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

data class WidgetSnapshot(
    val location: LocationSettings,
    val hijriShort: String,
    val nextPrayerKey: PrayerKey,
    val nextPrayerTime: String,
    val countdownShort: String,
    val fajrTime: String,
    val dhuhrTime: String,
    val asrTime: String,
    val maghribTime: String,
    val ishaTime: String,
    val morningPct: Int,
    val eveningPct: Int
)

object AdhkariWidgetUpdater {
    const val ACTION_REFRESH_WIDGET = "com.example.widget.ACTION_REFRESH"
    const val EXTRA_OPEN_TAB = "extra_open_tab"
    const val EXTRA_OPEN_CATEGORY = "extra_open_category"

    fun updateAllWidgetsAsync(context: Context) {
        val appCtx = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            updateAllWidgets(appCtx)
        }
    }

    suspend fun updateAllWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val prayerIds = manager.getAppWidgetIds(ComponentName(context, AdhkariPrayerWidgetProvider::class.java))
        val compactIds = manager.getAppWidgetIds(ComponentName(context, AdhkariCompactWidgetProvider::class.java))
        if (prayerIds.isEmpty() && compactIds.isEmpty()) return

        val snapshot = loadSnapshot(context)
        if (prayerIds.isNotEmpty()) {
            val rv = buildPrayerRemoteViews(context, snapshot)
            prayerIds.forEach { id -> manager.updateAppWidget(id, rv) }
        }
        if (compactIds.isNotEmpty()) {
            val rv = buildCompactRemoteViews(context, snapshot)
            compactIds.forEach { id -> manager.updateAppWidget(id, rv) }
        }
    }

    private suspend fun loadSnapshot(context: Context): WidgetSnapshot {
        val now = Calendar.getInstance()
        val dateKey = PrayerTimeCalculator.dateKeyOf(now)
        val dao = AdhkariDatabase.getInstance(context).adhkariDao()
        val repo = AdhkariRepository(dao)

        val prefs = try {
            repo.getPreferencesOnce()
        } catch (_: Throwable) {
            null
        }
        val location = prefs?.location ?: LocationSettings()
        val nextInfo = PrayerTimeCalculator.getNextPrayerInfo(now, location)

        val progressList = try {
            dao.getAllProgressOnce().filter { it.dateKey == dateKey }
        } catch (_: Throwable) {
            emptyList()
        }
        val dayMap = progressList.associate { it.counterKey to it.currentCount }

        val morningItems = AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter { it.categoryId == "morning" }
        val eveningItems = AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.filter { it.categoryId == "evening" }
        val morningDone = morningItems.count { (dayMap[it.id] ?: 0) >= it.targetCount }
        val eveningDone = eveningItems.count { (dayMap[it.id] ?: 0) >= it.targetCount }
        val morningPct = if (morningItems.isNotEmpty()) (morningDone * 100) / morningItems.size else 0
        val eveningPct = if (eveningItems.isNotEmpty()) (eveningDone * 100) / eveningItems.size else 0

        val totalMin = (nextInfo.diffSeconds / 60).coerceAtLeast(0)
        val hrs = totalMin / 60
        val mins = totalMin % 60
        val countdownStr = String.format(Locale.US, "%02d:%02d", hrs, mins)

        val t = nextInfo.todayTimes
        return WidgetSnapshot(
            location = location,
            hijriShort = PrayerTimeCalculator.formatHijriLong(now),
            nextPrayerKey = nextInfo.next.key,
            nextPrayerTime = nextInfo.next.timeStr,
            countdownShort = countdownStr,
            fajrTime = t.fajr.timeStr,
            dhuhrTime = t.dhuhr.timeStr,
            asrTime = t.asr.timeStr,
            maghribTime = t.maghrib.timeStr,
            ishaTime = t.isha.timeStr,
            morningPct = morningPct,
            eveningPct = eveningPct
        )
    }

    fun buildPrayerRemoteViews(context: Context, s: WidgetSnapshot): RemoteViews {
        val rv = RemoteViews(context.packageName, R.layout.widget_prayer_layout)
        rv.setTextViewText(R.id.widget_hijri_date, s.hijriShort)
        rv.setTextViewText(R.id.widget_city, "📍 ${s.location.shortName}")
        rv.setTextViewText(R.id.widget_next_prayer_name, s.nextPrayerKey.arabicName)
        rv.setTextViewText(R.id.widget_next_prayer_time, s.nextPrayerTime)
        rv.setTextViewText(R.id.widget_countdown, "متبقي ${s.countdownShort}")

        val isEveningWindow = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) >= 14
        val activeAdhkarCat = if (isEveningWindow) "evening" else "morning"
        val activeAdhkarText = if (isEveningWindow) {
            "🌙 المساء: ${s.eveningPct}%"
        } else {
            "☀️ الصباح: ${s.morningPct}%"
        }
        rv.setTextViewText(R.id.widget_adhkar_btn, activeAdhkarText)

        rv.setTextViewText(R.id.val_fajr, s.fajrTime)
        rv.setTextViewText(R.id.val_dhuhr, s.dhuhrTime)
        rv.setTextViewText(R.id.val_asr, s.asrTime)
        rv.setTextViewText(R.id.val_maghrib, s.maghribTime)
        rv.setTextViewText(R.id.val_isha, s.ishaTime)

        val slots = listOf(
            Triple(PrayerKey.FAJR, R.id.slot_fajr, R.id.lbl_fajr to R.id.val_fajr),
            Triple(PrayerKey.DHUHR, R.id.slot_dhuhr, R.id.lbl_dhuhr to R.id.val_dhuhr),
            Triple(PrayerKey.ASR, R.id.slot_asr, R.id.lbl_asr to R.id.val_asr),
            Triple(PrayerKey.MAGHRIB, R.id.slot_maghrib, R.id.lbl_maghrib to R.id.val_maghrib),
            Triple(PrayerKey.ISHA, R.id.slot_isha, R.id.lbl_isha to R.id.val_isha)
        )

        val goldText = Color.parseColor("#FEF08A")
        val labelDefault = Color.parseColor("#D1FAE5")
        val timeDefault = Color.WHITE

        slots.forEach { (key, slotId, textIds) ->
            val isNext = key == s.nextPrayerKey
            rv.setInt(
                slotId,
                "setBackgroundResource",
                if (isNext) R.drawable.widget_pill_gold else R.drawable.widget_pill_glass
            )
            rv.setTextColor(textIds.first, if (isNext) goldText else labelDefault)
            rv.setTextColor(textIds.second, if (isNext) goldText else timeDefault)
        }

        // Click actions
        rv.setOnClickPendingIntent(
            android.R.id.background,
            openAppIntent(context, 701, "prayers", null)
        )
        rv.setOnClickPendingIntent(
            R.id.widget_hero_area,
            openAppIntent(context, 702, "prayers", null)
        )
        rv.setOnClickPendingIntent(
            R.id.widget_adhkar_btn,
            openAppIntent(context, 703, "reader", activeAdhkarCat)
        )

        val refreshIntent = Intent(context, AdhkariPrayerWidgetProvider::class.java).apply {
            action = ACTION_REFRESH_WIDGET
        }
        val refreshPi = PendingIntent.getBroadcast(
            context,
            704,
            refreshIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.widget_btn_refresh, refreshPi)

        return rv
    }

    fun buildCompactRemoteViews(context: Context, s: WidgetSnapshot): RemoteViews {
        val rv = RemoteViews(context.packageName, R.layout.widget_compact_layout)
        rv.setTextViewText(R.id.compact_next_title, "القادمة: ${s.nextPrayerKey.arabicName} • ${s.location.shortName}")
        rv.setTextViewText(R.id.compact_next_time, s.nextPrayerTime)
        rv.setTextViewText(R.id.compact_countdown, s.countdownShort)
        rv.setTextViewText(R.id.compact_btn_morning, "☀️ الصباح ${s.morningPct}%")
        rv.setTextViewText(R.id.compact_btn_evening, "🌙 المساء ${s.eveningPct}%")
        rv.setTextViewText(R.id.compact_btn_prayers, "🕌 المواقيت")

        rv.setOnClickPendingIntent(
            android.R.id.background,
            openAppIntent(context, 710, "home", null)
        )
        rv.setOnClickPendingIntent(
            R.id.compact_header,
            openAppIntent(context, 711, "prayers", null)
        )
        rv.setOnClickPendingIntent(
            R.id.compact_btn_morning,
            openAppIntent(context, 712, "reader", "morning")
        )
        rv.setOnClickPendingIntent(
            R.id.compact_btn_evening,
            openAppIntent(context, 713, "reader", "evening")
        )
        rv.setOnClickPendingIntent(
            R.id.compact_btn_prayers,
            openAppIntent(context, 714, "prayers", null)
        )

        return rv
    }

    private fun openAppIntent(
        context: Context,
        requestCode: Int,
        tabRoute: String,
        categoryId: String?
    ): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_TAB, tabRoute)
            if (categoryId != null) {
                putExtra(EXTRA_OPEN_CATEGORY, categoryId)
            }
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun requestPinPrayerWidget(context: Context): Boolean {
        return requestPin(context, AdhkariPrayerWidgetProvider::class.java)
    }

    fun requestPinCompactWidget(context: Context): Boolean {
        return requestPin(context, AdhkariCompactWidgetProvider::class.java)
    }

    private fun requestPin(context: Context, providerClass: Class<*>): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        val mgr = AppWidgetManager.getInstance(context)
        if (!mgr.isRequestPinAppWidgetSupported) return false
        return try {
            mgr.requestPinAppWidget(ComponentName(context, providerClass), null, null)
        } catch (_: Throwable) {
            false
        }
    }
}
