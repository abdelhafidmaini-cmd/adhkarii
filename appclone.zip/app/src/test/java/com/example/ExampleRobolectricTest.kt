package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.engine.PrayerTimeCalculator
import com.example.data.model.AdhanSettings
import com.example.data.model.AdhanVoice
import com.example.data.model.LocationSettings
import com.example.data.model.PrayerKey
import com.example.data.seed.AuthenticAdhkarData
import com.example.widget.AdhkariWidgetUpdater
import com.example.widget.WidgetSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("أذكاري", appName)
    }

    @Test
    fun `authentic adhkar dataset is populated with all 10 categories`() {
        assertEquals(10, AuthenticAdhkarData.CATEGORIES_META.size)
        assertTrue(AuthenticAdhkarData.AUTHENTIC_ADHKAR_DB.size >= 75)
    }

    @Test
    fun `offline prayer calculator produces chronological prayer times`() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.MARCH, 15, 10, 0, 0)
        }
        val times = PrayerTimeCalculator.computePrayerTimesForDate(cal, LocationSettings())
        assertTrue(times.fajr.totalMinutes < times.sunrise.totalMinutes)
        assertTrue(times.sunrise.totalMinutes < times.dhuhr.totalMinutes)
        assertTrue(times.dhuhr.totalMinutes < times.asr.totalMinutes)
        assertTrue(times.asr.totalMinutes < times.maghrib.totalMinutes)
        assertTrue(times.maghrib.totalMinutes < times.isha.totalMinutes)
    }

    @Test
    fun `adhan settings defaults enable all five obligatory prayers`() {
        val settings = AdhanSettings()
        assertTrue(settings.enabled)
        assertEquals(AdhanVoice.MAKKAH, settings.voice)
        PrayerKey.fiveObligatory.forEach { pk ->
            assertTrue(settings.isPrayerEnabled(pk))
        }
        val mutedAsr = settings.copy(
            perPrayerEnabled = settings.perPrayerEnabled + (PrayerKey.ASR to false)
        )
        assertFalse(mutedAsr.isPrayerEnabled(PrayerKey.ASR))
        assertTrue(mutedAsr.isPrayerEnabled(PrayerKey.MAGHRIB))
    }

    @Test
    fun `prayer and compact widget remote views build cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val snap = WidgetSnapshot(
            location = LocationSettings(),
            hijriShort = "الجمعة ١٤ جمادى الآخرة ١٤٤٨ هـ",
            nextPrayerKey = PrayerKey.ASR,
            nextPrayerTime = "15:42",
            countdownShort = "01:15",
            fajrTime = "05:45",
            dhuhrTime = "12:52",
            asrTime = "15:42",
            maghribTime = "18:05",
            ishaTime = "19:22",
            morningPct = 75,
            eveningPct = 40
        )
        val fullRv = AdhkariWidgetUpdater.buildPrayerRemoteViews(context, snap)
        val compactRv = AdhkariWidgetUpdater.buildCompactRemoteViews(context, snap)
        assertNotNull(fullRv)
        assertNotNull(compactRv)
    }
}
